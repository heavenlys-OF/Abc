export type CalendarReminderInput = {
  title: string;
  notes?: string;
  startDate?: Date;
  durationMinutes?: number;
};

export type CalendarReminderDraft = {
  title: string;
  notes: string;
  startDate: Date;
  endDate: Date;
};

export function suggestedReminderStartDate(
  nowOrDays: Date | number = new Date(),
  daysFromNow = 0,
  preferredHour = 9,
): Date {
  const now = typeof nowOrDays === "number" ? new Date() : nowOrDays;
  const offsetDays = typeof nowOrDays === "number" ? nowOrDays : daysFromNow;
  const start = new Date(now);

  if (offsetDays > 0) {
    start.setDate(start.getDate() + offsetDays);
    start.setHours(preferredHour, 0, 0, 0);
    if (start.getTime() <= now.getTime()) {
      start.setDate(start.getDate() + 1);
    }
    return start;
  }

  start.setMinutes(0, 0, 0);
  start.setHours(start.getHours() + 1);
  if (start.getHours() >= 22) {
    start.setDate(start.getDate() + 1);
    start.setHours(preferredHour, 0, 0, 0);
  }
  return start;
}

export function prepareCalendarReminder(
  input: CalendarReminderInput,
  now = new Date(),
): CalendarReminderDraft {
  const title = input.title.trim().replace(/\s+/g, " ").slice(0, 120);
  const startDate = input.startDate ? new Date(input.startDate) : suggestedReminderStartDate(now);
  const durationMinutes = Math.max(5, Math.min(input.durationMinutes ?? 30, 24 * 60));
  const endDate = new Date(startDate.getTime() + durationMinutes * 60_000);
  const suppliedNotes = input.notes?.trim();
  const notes = suppliedNotes
    ? `${suppliedNotes}\n\nAdded from Heavenly’s ABC+ / Simple Life OS.`
    : "Added from Heavenly’s ABC+ / Simple Life OS. Choose the time and any repeat in your calendar.";

  return { title, notes, startDate, endDate };
}

export function escapeIcsText(value: string): string {
  return value
    .replace(/\\/g, "\\\\")
    .replace(/\r?\n/g, "\\n")
    .replace(/,/g, "\\,")
    .replace(/;/g, "\\;");
}

export function formatIcsUtc(date: Date): string {
  return date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
}

export function buildCalendarIcs(
  draft: CalendarReminderDraft,
  stamp = new Date(),
  uid = `${Date.now()}@simple-life-os`,
): string {
  const summary = escapeIcsText(draft.title);
  const description = escapeIcsText(draft.notes);
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Heavenly’s ABC+//Simple Life OS//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${uid}`,
    `DTSTAMP:${formatIcsUtc(stamp)}`,
    `DTSTART:${formatIcsUtc(draft.startDate)}`,
    `DTEND:${formatIcsUtc(draft.endDate)}`,
    `SUMMARY:${summary}`,
    `DESCRIPTION:${description}`,
    "BEGIN:VALARM",
    "TRIGGER:PT0M",
    "ACTION:DISPLAY",
    `DESCRIPTION:${summary}`,
    "END:VALARM",
    "END:VEVENT",
    "END:VCALENDAR",
  ];
  return `${lines.join("\r\n")}\r\n`;
}
