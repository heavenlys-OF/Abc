import { Platform } from "react-native";
import {
  buildCalendarIcs,
  prepareCalendarReminder,
  type CalendarReminderInput,
} from "./reminder-utils";

export type CalendarReminderOutcome =
  | "saved"
  | "opened"
  | "cancelled"
  | "downloaded"
  | "permission-denied"
  | "unsupported";

function downloadCalendarFile(title: string, content: string): CalendarReminderOutcome {
  if (typeof document === "undefined" || typeof URL === "undefined") return "unsupported";

  const blob = new Blob([content], { type: "text/calendar;charset=utf-8" });
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const filename = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48) || "life-os-reminder";
  link.href = objectUrl;
  link.download = `${filename}.ics`;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  return "downloaded";
}

export async function addCalendarReminder(input: CalendarReminderInput): Promise<CalendarReminderOutcome> {
  const draft = prepareCalendarReminder(input);

  if (!draft.title) return "unsupported";

  if (Platform.OS === "web") {
    return downloadCalendarFile(draft.title, buildCalendarIcs(draft));
  }

  try {
    if (Platform.OS === "ios") {
      const Calendar = await import("expo-calendar");
      const permission = await Calendar.requestCalendarPermissions(true);
      if (!permission.granted) return "permission-denied";

      const calendar = Calendar.getDefaultCalendarSync();
      const result = await calendar.addEventWithForm({
        title: draft.title,
        startDate: draft.startDate,
        endDate: draft.endDate,
        notes: draft.notes,
        alarms: [{ relativeOffset: 0 }],
      });
      if (result.action === "saved") return "saved";
      if (result.action === "canceled") return "cancelled";
      return "opened";
    }

    if (Platform.OS === "android") {
      // This presents Android's own event editor. The app does not query the user's calendars.
      const CalendarLegacy = await import("expo-calendar/legacy");
      const result = await CalendarLegacy.createEventInCalendarAsync({
        title: draft.title,
        startDate: draft.startDate,
        endDate: draft.endDate,
        notes: draft.notes,
        alarms: [{ relativeOffset: 0 }],
      });
      if (result.action === "canceled") return "cancelled";
      return "opened";
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (/unavailable|not available|native module/i.test(message)) return "unsupported";
    throw error;
  }

  return "unsupported";
}

export { suggestedReminderStartDate } from "./reminder-utils";
export type { CalendarReminderInput } from "./reminder-utils";
