import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Image, Text, View } from "react-native";
import { useAuth } from "@/hooks/use-auth";
import { DAILY_HABIT_NAMES } from "@/shared/lifeos";
import { ANONYMOUS_LIFEOS_STORAGE_KEY, LEGACY_LIFEOS_STORAGE_KEY, lifeOSStorageKey } from "./storage-keys";

export type TaskItem = { text: string; done: boolean };
export type BrainDumpItem = { id: string; text: string; createdAt: string; timezoneOffsetMinutes: number };
export type MonthHabit = { id: string; name: string; startDay: number };

export type DailyEntry = {
  focus: string;
  priorities: string[];
  quickTasks: TaskItem[];
  completedHabits: string[];
  notes: string;
  gratitude: string[];
  tomorrow: string;
};

export type WeeklyEntry = {
  goal: string;
  outcomes: string[];
  mustDos: TaskItem[];
  avoiding: string;
  fixing: string;
  drained: string;
  energized: string;
};

export type MonthReview = {
  well: string;
  notWorking: string;
  lesson: string;
  learned: string;
  change: string;
  nextFocus: string;
  rating: number | null;
  gratitude: string[];
};

export type MonthEntry = {
  focus: string;
  habits: MonthHabit[];
  checks: Record<string, boolean>;
  review: MonthReview;
};

export type LifeOSData = {
  days: Record<string, DailyEntry>;
  weeks: Record<string, WeeklyEntry>;
  months: Record<string, MonthEntry>;
  notes: BrainDumpItem[];
};

const emptyLifeOSData = (): LifeOSData => ({ days: {}, weeks: {}, months: {}, notes: [] });

export const dailyHabitNames = DAILY_HABIT_NAMES;

export function localDayKey(date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function localWeekKey(date = new Date()): string {
  const monday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7));
  return localDayKey(monday);
}

export function localMonthKey(date = new Date()): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

export function daysInMonth(date = new Date()): number {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
}

export function makeDailyEntry(): DailyEntry {
  return {
    focus: "",
    priorities: ["", "", ""],
    quickTasks: Array.from({ length: 5 }, () => ({ text: "", done: false })),
    completedHabits: [],
    notes: "",
    gratitude: ["", "", ""],
    tomorrow: "",
  };
}

export function makeWeeklyEntry(): WeeklyEntry {
  return {
    goal: "",
    outcomes: ["", "", ""],
    mustDos: Array.from({ length: 5 }, () => ({ text: "", done: false })),
    avoiding: "",
    fixing: "",
    drained: "",
    energized: "",
  };
}

export function makeMonthEntry(): MonthEntry {
  return {
    focus: "",
    habits: [],
    checks: {},
    review: {
      well: "",
      notWorking: "",
      lesson: "",
      learned: "",
      change: "",
      nextFocus: "",
      rating: null,
      gratitude: ["", "", ""],
    },
  };
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

function restoreStringSlots(value: unknown, defaults: string[]): string[] {
  const slots = Array.isArray(value)
    ? value.slice(0, defaults.length).map((item) => typeof item === "string" ? item : "")
    : [];
  return [...slots, ...defaults.slice(slots.length)];
}

function restoreTaskSlots(value: unknown, defaults: TaskItem[]): TaskItem[] {
  const slots = Array.isArray(value)
    ? value.slice(0, defaults.length).map((item): TaskItem => {
        const task = asRecord(item);
        return { text: typeof task.text === "string" ? task.text : "", done: task.done === true };
      })
    : [];
  return [...slots, ...defaults.slice(slots.length)];
}

function restoreDailyEntry(value: unknown): DailyEntry {
  const saved = asRecord(value);
  const defaults = makeDailyEntry();
  const supportedHabits = new Set<string>(DAILY_HABIT_NAMES);
  const completedHabits = Array.isArray(saved.completedHabits)
    ? [...new Set(saved.completedHabits.filter((habit): habit is string => typeof habit === "string" && supportedHabits.has(habit)))].slice(0, DAILY_HABIT_NAMES.length)
    : [];
  return {
    focus: typeof saved.focus === "string" ? saved.focus : "",
    priorities: restoreStringSlots(saved.priorities, defaults.priorities),
    quickTasks: restoreTaskSlots(saved.quickTasks, defaults.quickTasks),
    completedHabits,
    notes: typeof saved.notes === "string" ? saved.notes : "",
    gratitude: restoreStringSlots(saved.gratitude, defaults.gratitude),
    tomorrow: typeof saved.tomorrow === "string" ? saved.tomorrow : "",
  };
}

function restoreWeeklyEntry(value: unknown): WeeklyEntry {
  const saved = asRecord(value);
  const defaults = makeWeeklyEntry();
  return {
    goal: typeof saved.goal === "string" ? saved.goal : "",
    outcomes: restoreStringSlots(saved.outcomes, defaults.outcomes),
    mustDos: restoreTaskSlots(saved.mustDos, defaults.mustDos),
    avoiding: typeof saved.avoiding === "string" ? saved.avoiding : "",
    fixing: typeof saved.fixing === "string" ? saved.fixing : "",
    drained: typeof saved.drained === "string" ? saved.drained : "",
    energized: typeof saved.energized === "string" ? saved.energized : "",
  };
}

function restoreBrainDumpItem(id: string, text: string, createdAtValue: unknown, timezoneOffsetValue?: unknown): BrainDumpItem {
  const parsedDate = typeof createdAtValue === "string" ? new Date(createdAtValue) : new Date(Number.NaN);
  const createdAt = Number.isNaN(parsedDate.getTime()) ? new Date() : parsedDate;
  const timezoneOffsetMinutes = typeof timezoneOffsetValue === "number" && Number.isInteger(timezoneOffsetValue) && timezoneOffsetValue >= -840 && timezoneOffsetValue <= 840
    ? timezoneOffsetValue
    : createdAt.getTimezoneOffset();
  return { id, text, createdAt: createdAt.toISOString(), timezoneOffsetMinutes };
}

function restoreData(raw: string): LifeOSData {
  const parsed = asRecord(JSON.parse(raw));
  if (parsed.days && parsed.weeks && parsed.months && Array.isArray(parsed.notes)) {
    const months = Object.fromEntries(Object.entries(asRecord(parsed.months)).map(([key, rawMonth]) => {
      const saved = asRecord(rawMonth);
      const defaults = makeMonthEntry();
      const habits = Array.isArray(saved.habits) ? saved.habits.slice(0, 5).map((rawHabit, index): MonthHabit => {
        const habit = asRecord(rawHabit);
        return {
          id: typeof habit.id === "string" ? habit.id : `habit-${index + 1}`,
          name: typeof habit.name === "string" ? habit.name : "",
          startDay: typeof habit.startDay === "number" ? Math.max(1, Math.min(31, habit.startDay)) : 1,
        };
      }) : [];
      const review = asRecord(saved.review);
      const gratitude = Array.isArray(review.gratitude) ? review.gratitude.map(String).slice(0, 3) : defaults.review.gratitude;
      const rating = typeof review.rating === "number" && review.rating >= 1 && review.rating <= 5 ? Math.round(review.rating) : null;
      return [key, {
        focus: typeof saved.focus === "string" ? saved.focus : "",
        habits,
        checks: Object.fromEntries(Object.entries(asRecord(saved.checks)).map(([checkKey, checked]) => [checkKey, Boolean(checked)])),
        review: {
          well: typeof review.well === "string" ? review.well : "",
          notWorking: typeof review.notWorking === "string" ? review.notWorking : "",
          lesson: typeof review.lesson === "string" ? review.lesson : "",
          learned: typeof review.learned === "string" ? review.learned : "",
          change: typeof review.change === "string" ? review.change : "",
          nextFocus: typeof review.nextFocus === "string" ? review.nextFocus : "",
          rating,
          gratitude,
        },
      } as MonthEntry];
    }));
    const notes = parsed.notes.flatMap((rawNote, index) => {
      const note = asRecord(rawNote);
      if (typeof note.text !== "string") return [];
      return [restoreBrainDumpItem(
        typeof note.id === "string" ? note.id : `legacy-${index}`,
        note.text,
        note.createdAt,
        note.timezoneOffsetMinutes,
      )];
    });
    return {
      days: Object.fromEntries(Object.entries(asRecord(parsed.days)).map(([key, value]) => [key, restoreDailyEntry(value)])),
      weeks: Object.fromEntries(Object.entries(asRecord(parsed.weeks)).map(([key, value]) => [key, restoreWeeklyEntry(value)])),
      months,
      notes,
    };
  }

  // Preserve data saved by the first preview build if it already exists on this device.
  const legacyToday = asRecord(parsed.today);
  const legacyWeek = asRecord(parsed.week);
  const legacyMonth = asRecord(parsed.month);
  const legacyHabits = asRecord(parsed.habits);
  const today = restoreDailyEntry(legacyToday);
  const week = restoreWeeklyEntry(legacyWeek);
  const month = makeMonthEntry();
  const legacyHabitNames = Array.isArray(legacyHabits.names) ? legacyHabits.names : [];
  const legacyChecks = asRecord(legacyHabits.checks);
  const legacyGratitude = Array.isArray(legacyMonth.gratitude) ? legacyMonth.gratitude : ["", "", ""];
  month.focus = typeof legacyHabits.focus === "string" ? legacyHabits.focus : "";
  month.habits = legacyHabitNames.slice(0, 5).map((name, index) => ({ id: `habit-${index + 1}`, name: String(name), startDay: 1 }));
  month.checks = Object.fromEntries(Object.entries(legacyChecks).map(([key, value]) => [key, Boolean(value)]));
  month.review = {
    ...month.review,
    well: typeof legacyMonth.well === "string" ? legacyMonth.well : "",
    notWorking: typeof legacyMonth.not === "string" ? legacyMonth.not : "",
    lesson: typeof legacyMonth.lesson === "string" ? legacyMonth.lesson : "",
    change: typeof legacyMonth.change === "string" ? legacyMonth.change : "",
    nextFocus: typeof legacyMonth.focus === "string" ? legacyMonth.focus : "",
    rating: typeof legacyMonth.rating === "number" ? legacyMonth.rating : null,
    gratitude: legacyGratitude.map(String).slice(0, 3),
  };
  const oldNotes = Array.isArray(parsed.notes)
    ? parsed.notes.flatMap((entry) => {
        const item = asRecord(entry);
        return typeof item.text === "string"
          ? [restoreBrainDumpItem(String(item.id ?? Date.now()), item.text, item.date ?? item.createdAt)]
          : [];
      })
    : [];
  return {
    days: Object.fromEntries(Object.keys(legacyToday).length ? [[localDayKey(), today]] : []),
    weeks: Object.fromEntries(Object.keys(legacyWeek).length ? [[localWeekKey(), week]] : []),
    months: Object.fromEntries(Object.keys(legacyHabits).length || Object.keys(legacyMonth).length ? [[localMonthKey(), month]] : []),
    notes: oldNotes,
  };
}

type LifeOSContextValue = {
  ready: boolean;
  today: DailyEntry;
  week: WeeklyEntry;
  month: MonthEntry;
  notes: BrainDumpItem[];
  updateToday: (patch: Partial<DailyEntry>) => void;
  updateWeek: (patch: Partial<WeeklyEntry>) => void;
  updateMonth: (patch: Partial<MonthEntry>) => void;
  updateReview: (patch: Partial<MonthReview>) => void;
  addNote: (text: string) => void;
  removeNote: (id: string) => void;
};

const LifeOSContext = createContext<LifeOSContextValue | null>(null);

export function LifeOSProvider({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const storageKey = authLoading ? null : lifeOSStorageKey(user?.id);
  const [data, setData] = useState<LifeOSData>(emptyLifeOSData);
  const [loadedStorageKey, setLoadedStorageKey] = useState<string | null>(null);
  const ready = storageKey !== null && loadedStorageKey === storageKey;
  const todayKey = localDayKey();
  const weekKey = localWeekKey();
  const monthKey = localMonthKey();

  useEffect(() => {
    if (!storageKey) {
      setLoadedStorageKey(null);
      return undefined;
    }
    let active = true;
    setLoadedStorageKey(null);
    setData(emptyLifeOSData());
    const load = async () => {
      let stored = await AsyncStorage.getItem(storageKey);
      // The previous unscoped draft key is restored only as anonymous device data,
      // never merged into an authenticated account's namespace.
      if (!stored && storageKey === ANONYMOUS_LIFEOS_STORAGE_KEY) {
        stored = await AsyncStorage.getItem(LEGACY_LIFEOS_STORAGE_KEY);
      }
      if (stored && active) setData(restoreData(stored));
    };
    void load().catch(() => undefined).finally(() => {
      if (active) setLoadedStorageKey(storageKey);
    });
    return () => {
      active = false;
    };
  }, [storageKey]);

  useEffect(() => {
    if (!storageKey || loadedStorageKey !== storageKey) return undefined;
    const timer = setTimeout(() => {
      AsyncStorage.setItem(storageKey, JSON.stringify(data)).catch(() => undefined);
    }, 180);
    return () => clearTimeout(timer);
  }, [data, loadedStorageKey, storageKey]);

  const updateToday = useCallback(
    (patch: Partial<DailyEntry>) => {
      setData((previous) => ({
        ...previous,
        days: {
          ...previous.days,
          [todayKey]: { ...makeDailyEntry(), ...previous.days[todayKey], ...patch },
        },
      }));
    },
    [todayKey],
  );

  const updateWeek = useCallback(
    (patch: Partial<WeeklyEntry>) => {
      setData((previous) => ({
        ...previous,
        weeks: {
          ...previous.weeks,
          [weekKey]: { ...makeWeeklyEntry(), ...previous.weeks[weekKey], ...patch },
        },
      }));
    },
    [weekKey],
  );

  const updateMonth = useCallback(
    (patch: Partial<MonthEntry>) => {
      setData((previous) => ({
        ...previous,
        months: {
          ...previous.months,
          [monthKey]: { ...makeMonthEntry(), ...previous.months[monthKey], ...patch },
        },
      }));
    },
    [monthKey],
  );

  const updateReview = useCallback(
    (patch: Partial<MonthReview>) => {
      setData((previous) => {
        const current = { ...makeMonthEntry(), ...previous.months[monthKey] };
        return {
          ...previous,
          months: {
            ...previous.months,
            [monthKey]: { ...current, review: { ...current.review, ...patch } },
          },
        };
      });
    },
    [monthKey],
  );

  const addNote = useCallback((text: string) => {
    const cleaned = text.trim();
    if (!cleaned) return;
    const capturedAt = new Date();
    setData((previous) => ({
      ...previous,
      notes: [{
        id: `${capturedAt.getTime()}-${Math.random().toString(36).slice(2, 7)}`,
        text: cleaned,
        createdAt: capturedAt.toISOString(),
        timezoneOffsetMinutes: capturedAt.getTimezoneOffset(),
      }, ...previous.notes],
    }));
  }, []);

  const removeNote = useCallback((id: string) => {
    setData((previous) => ({ ...previous, notes: previous.notes.filter((note) => note.id !== id) }));
  }, []);

  const value = useMemo<LifeOSContextValue>(
    () => ({
      ready,
      today: { ...makeDailyEntry(), ...data.days[todayKey] },
      week: { ...makeWeeklyEntry(), ...data.weeks[weekKey] },
      month: { ...makeMonthEntry(), ...data.months[monthKey] },
      notes: data.notes,
      updateToday,
      updateWeek,
      updateMonth,
      updateReview,
      addNote,
      removeNote,
    }),
    [ready, data, todayKey, weekKey, monthKey, updateToday, updateWeek, updateMonth, updateReview, addNote, removeNote],
  );

  return (
    <LifeOSContext.Provider value={value}>
      {ready ? (
        children
      ) : (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#F4EFE5" }}>
          <Image source={require("../../assets/images/icon.png")} style={{ width: 82, height: 82, marginBottom: 18 }} resizeMode="contain" />
          <Text style={{ color: "#344B3B", fontFamily: "Georgia", fontSize: 20, marginBottom: 12 }}>Simple Life OS</Text>
          <ActivityIndicator color="#728C74" />
        </View>
      )}
    </LifeOSContext.Provider>
  );
}

export function useLifeOS(): LifeOSContextValue {
  const value = useContext(LifeOSContext);
  if (!value) throw new Error("useLifeOS must be used inside LifeOSProvider");
  return value;
}
