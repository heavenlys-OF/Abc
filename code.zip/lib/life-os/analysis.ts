import type { DailyEntry, MonthEntry, WeeklyEntry } from "./store";
import { DAILY_HABIT_NAMES } from "../../shared/lifeos";

export type InsightMetric = {
  label: string;
  value: string;
  progress: number | null;
};

export type ProductivityInsight = {
  headline: string;
  summary: string;
  metrics: InsightMetric[];
};

export type HabitInsight = {
  name: string;
  complete: number;
  possible: number;
  progress: number | null;
};

const DAILY_HABIT_TOTAL = DAILY_HABIT_NAMES.length;
const DAILY_HABIT_SET = new Set<string>(DAILY_HABIT_NAMES);
const ratio = (numerator: number, denominator: number): number | null =>
  denominator > 0 ? Math.max(0, Math.min(1, numerator / denominator)) : null;
const present = (value: string | null | undefined): boolean => Boolean(value?.trim());

export function analyzeDaily(entry: DailyEntry): ProductivityInsight {
  const planned = entry.quickTasks.filter((task) => present(task.text)).length;
  const completed = entry.quickTasks.filter((task) => present(task.text) && task.done).length;
  const completedHabits = new Set(entry.completedHabits.filter((habit) => DAILY_HABIT_SET.has(habit))).size;
  const priorities = entry.priorities.filter(present).length;
  const gratitude = entry.gratitude.filter(present).length;
  const reflectionPrompts = gratitude + (present(entry.tomorrow) ? 1 : 0);
  const focusSet = present(entry.focus);

  return {
    headline: focusSet ? "Your focus is clear" : "A fresh page for today",
    summary: `Focus ${focusSet ? "set" : "open"} · ${priorities}/3 priorities · ${planned ? `${completed}/${planned} quick tasks` : "no quick tasks yet"} · ${completedHabits}/${DAILY_HABIT_TOTAL} habits · ${reflectionPrompts}/4 reflection cues.`,
    metrics: [
      { label: "Quick tasks", value: `${completed}/${planned}`, progress: ratio(completed, planned) },
      { label: "Habits", value: `${completedHabits}/${DAILY_HABIT_TOTAL}`, progress: ratio(completedHabits, DAILY_HABIT_TOTAL) },
      { label: "Focus", value: focusSet ? "Set" : "Open", progress: focusSet ? 1 : 0 },
      { label: "Priorities", value: `${priorities}/3`, progress: ratio(priorities, 3) },
      { label: "Reflection", value: `${reflectionPrompts}/4`, progress: ratio(reflectionPrompts, 4) },
    ],
  };
}

export function analyzeWeekly(entry: WeeklyEntry): ProductivityInsight {
  const planned = entry.mustDos.filter((task) => present(task.text)).length;
  const completed = entry.mustDos.filter((task) => present(task.text) && task.done).length;
  const outcomes = entry.outcomes.filter(present).length;
  const energyPrompts = Number(present(entry.drained)) + Number(present(entry.energized));
  const goalSet = present(entry.goal);

  return {
    headline: goalSet ? "Your week has a direction" : "Your weekly reset is ready",
    summary: planned
      ? `${completed} of ${planned} must-do tasks marked complete, with ${outcomes} of 3 outcomes written.`
      : `${outcomes} of 3 outcomes written. Add must-dos to see follow-through here.`,
    metrics: [
      { label: "Must-dos", value: `${completed}/${planned}`, progress: ratio(completed, planned) },
      { label: "Outcomes", value: `${outcomes}/3`, progress: ratio(outcomes, 3) },
      { label: "Goal", value: goalSet ? "Set" : "Open", progress: goalSet ? 1 : 0 },
      { label: "Energy notes", value: `${energyPrompts}/2`, progress: ratio(energyPrompts, 2) },
    ],
  };
}

export function analyzeMonth(entry: MonthEntry, today = new Date()): ProductivityInsight & { habits: HabitInsight[]; reflectionAnswered: number; reflectionTotal: number } {
  const elapsedDays = today.getDate();
  const namedHabits = entry.habits.filter((habit) => present(habit.name));
  const habits = namedHabits.map((habit) => {
    const startDay = Math.max(1, Math.min(elapsedDays, habit.startDay ?? 1));
    const possible = habit.startDay > elapsedDays ? 0 : elapsedDays - startDay + 1;
    let complete = 0;
    for (let day = startDay; day <= elapsedDays; day += 1) {
      if (entry.checks[`${habit.id}-${day}`]) complete += 1;
    }
    return { name: habit.name.trim() || "New habit", complete, possible, progress: ratio(complete, possible) };
  });
  const possible = habits.reduce((sum, habit) => sum + habit.possible, 0);
  const complete = habits.reduce((sum, habit) => sum + habit.complete, 0);
  const review = entry.review;
  const reflectionTotal = 10;
  const reflectionAnswered =
    Number(present(review.well)) + Number(present(review.notWorking)) + Number(present(review.lesson)) +
    Number(present(review.learned)) + Number(present(review.change)) + Number(present(review.nextFocus)) +
    Number(review.rating !== null) + review.gratitude.filter(present).length;
  const rating = review.rating === null ? "Not rated" : `${review.rating}/5`;
  const monthLabel = today.toLocaleDateString(undefined, { month: "long" });
  const focusSet = present(entry.focus);

  return {
    headline: namedHabits.length ? `${monthLabel} is taking shape` : "Make room for one small habit",
    summary: namedHabits.length
      ? `${complete} of ${possible} possible habit check-ins marked through day ${elapsedDays}; monthly focus ${focusSet ? "set" : "open"}; your own rating is ${rating.toLowerCase()}.`
      : focusSet
        ? "Your monthly focus is set. Add a named habit to see its month-to-date pattern."
        : "Set a monthly focus and add up to five named habits to see your month-to-date pattern.",
    metrics: [
      { label: "Check-ins", value: `${complete}/${possible}`, progress: ratio(complete, possible) },
      { label: "Month rating", value: rating, progress: review.rating === null ? null : review.rating / 5 },
      { label: "Monthly focus", value: focusSet ? "Set" : "Open", progress: focusSet ? 1 : 0 },
      { label: "Reflection prompts", value: `${reflectionAnswered}/${reflectionTotal}`, progress: ratio(reflectionAnswered, reflectionTotal) },
    ],
    habits,
    reflectionAnswered,
    reflectionTotal,
  };
}
