export const LIFEOS_STORAGE_PREFIX = "simpleos.v2";
export const LEGACY_LIFEOS_STORAGE_KEY = "simpleos.v1";
export const ANONYMOUS_LIFEOS_STORAGE_KEY = `${LIFEOS_STORAGE_PREFIX}.anonymous`;

/** Drafts follow a server-verified database identity; guest work stays separate. */
export function lifeOSStorageKey(userId: number | null | undefined): string {
  return typeof userId === "number" && Number.isSafeInteger(userId) && userId > 0
    ? `${LIFEOS_STORAGE_PREFIX}.user.${userId}`
    : ANONYMOUS_LIFEOS_STORAGE_KEY;
}
