import * as Linking from "expo-linking";
import Constants from "expo-constants";
import * as SecureStore from "expo-secure-store";
import * as ReactNative from "react-native";

// Extract scheme from bundle ID (last segment timestamp, prefixed with "manus")
// e.g., "space.manus.my.app.t20240115103045" -> "manus20240115103045"
const bundleId = "space.manus.simpleos.t279064181439197";
const timestamp = bundleId.split(".").pop()?.replace(/^t/, "") ?? "";
const schemeFromBundleId = `manus${timestamp}`;
const NATIVE_OAUTH_STATE_KEY = "simpleos.oauth.pending_state";
const OAUTH_STATE_TTL_MS = 10 * 60 * 1000;

const extra = (Constants.expoConfig?.extra ?? {}) as Record<string, string | undefined>;
const env = {
  portal: extra.oauthPortalUrl ?? process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL ?? "",
  server: extra.oauthServerUrl ?? process.env.EXPO_PUBLIC_OAUTH_SERVER_URL ?? "",
  appId: extra.appId ?? process.env.EXPO_PUBLIC_APP_ID ?? "",
  ownerId: process.env.EXPO_PUBLIC_OWNER_OPEN_ID ?? "",
  ownerName: process.env.EXPO_PUBLIC_OWNER_NAME ?? "",
  apiBaseUrl: extra.apiBaseUrl ?? process.env.EXPO_PUBLIC_API_BASE_URL ?? "",
  deepLinkScheme: schemeFromBundleId,
};

export const OAUTH_PORTAL_URL = env.portal;
export const OAUTH_SERVER_URL = env.server;
export const APP_ID = env.appId;
export const OWNER_OPEN_ID = env.ownerId;
export const OWNER_NAME = env.ownerName;
export const API_BASE_URL = env.apiBaseUrl;

/** Get the configured API URL, or derive its paired port from the current Expo web origin. */
export function getApiBaseUrl(): string {
  if (API_BASE_URL) return API_BASE_URL.replace(/\/$/, "");
  if (ReactNative.Platform.OS === "web" && typeof window !== "undefined" && window.location) {
    const { protocol, hostname, port } = window.location;
    const apiHostname = hostname.replace(/^8081-/, "3000-");
    if (apiHostname !== hostname) return `${protocol}//${apiHostname}`;
    if (port === "8081") return `${protocol}//${hostname}:3000`;
  }
  return "";
}

export const SESSION_TOKEN_KEY = "app_session_token";
export const USER_INFO_KEY = "manus-runtime-user-info";

/** The web callback remains on the paired API origin; native uses the app's deep link. */
export const getRedirectUri = () => {
  if (ReactNative.Platform.OS === "web") return `${getApiBaseUrl()}/api/oauth/callback`;
  return Linking.createURL("/oauth/callback", { scheme: env.deepLinkScheme });
};

function decodeState(state: string): { redirectUri?: string; nonce?: string } | null {
  try {
    const decoded = typeof globalThis.atob === "function"
      ? globalThis.atob(state)
      : (globalThis as Record<string, any>).Buffer?.from(state, "base64").toString("utf-8");
    if (!decoded) return null;
    const parsed: unknown = JSON.parse(decoded);
    if (!parsed || typeof parsed !== "object") return null;
    return parsed as { redirectUri?: string; nonce?: string };
  } catch {
    return null;
  }
}

/** Check and consume the one-use state stored locally before an Expo deep-link exchange. */
export async function verifyNativeOAuthState(state: string): Promise<boolean> {
  try {
    const storedValue = await SecureStore.getItemAsync(NATIVE_OAUTH_STATE_KEY);
    const parsed = decodeState(state);
    await SecureStore.deleteItemAsync(NATIVE_OAUTH_STATE_KEY);
    if (!storedValue || !parsed) return false;
    const stored = JSON.parse(storedValue) as { nonce?: string; redirectUri?: string; createdAt?: number };
    return Boolean(
      stored.nonce &&
      stored.nonce === parsed.nonce &&
      stored.redirectUri &&
      stored.redirectUri === parsed.redirectUri &&
      typeof stored.createdAt === "number" &&
      Date.now() - stored.createdAt >= 0 &&
      Date.now() - stored.createdAt <= OAUTH_STATE_TTL_MS,
    );
  } catch {
    return false;
  }
}

async function requestAuthorizationUrl(): Promise<string> {
  if (!env.appId || !env.portal) throw new Error("Manus login configuration is unavailable.");
  const apiBaseUrl = getApiBaseUrl();
  if (!apiBaseUrl) throw new Error("The app's API address is unavailable.");

  const endpoint = new URL(`${apiBaseUrl}/api/oauth/start`);
  const native = ReactNative.Platform.OS !== "web";
  const redirectUri = native ? getRedirectUri() : undefined;
  endpoint.searchParams.set("platform", native ? "native" : "web");
  if (redirectUri) endpoint.searchParams.set("redirectUri", redirectUri);
  const response = await fetch(endpoint.toString(), { method: "GET", credentials: "include" });
  const result = await response.json() as { authorizationUrl?: string; nonce?: string; error?: string };
  if (!response.ok || !result.authorizationUrl) {
    throw new Error(result.error || "Could not start Manus sign-in.");
  }
  const authorizationUrl = new URL(result.authorizationUrl);
  if (authorizationUrl.origin !== new URL(env.portal).origin || authorizationUrl.pathname !== "/app-auth") {
    throw new Error("The sign-in response used an unexpected destination.");
  }
  if (native) {
    if (!result.nonce || !redirectUri) throw new Error("The native sign-in response was incomplete.");
    await SecureStore.setItemAsync(NATIVE_OAUTH_STATE_KEY, JSON.stringify({
      nonce: result.nonce,
      redirectUri,
      createdAt: Date.now(),
    }));
  }
  return authorizationUrl.toString();
}

/** Open the server-issued OAuth authorization URL; callback state is one-use on web and native. */
export async function startOAuthLogin(): Promise<string | null> {
  const loginUrl = await requestAuthorizationUrl();
  if (ReactNative.Platform.OS === "web") {
    if (typeof window !== "undefined") window.location.href = loginUrl;
    return null;
  }
  try {
    const supported = await Linking.canOpenURL(loginUrl);
    if (!supported) throw new Error("This device cannot open the sign-in page.");
    await Linking.openURL(loginUrl);
  } catch (error) {
    await SecureStore.deleteItemAsync(NATIVE_OAUTH_STATE_KEY);
    throw error;
  }
  return null;
}
