# Heavenly’s ABC+ — product-first mobile app plan

## Product direction

Keep ABC+ at the front of the app; Life OS tools support a simple breakfast and healthy routine. The app is a customer-facing brand/product guide, not a checkout or a substitute for the package label. Preserve existing sign-in, account isolation, analytics and Life OS workflows.

The latest user-approved formulation supersedes previous 13- and 14-ingredient versions. Use the corrected supplied ABC+ hero artwork exactly as delivered; it depicts seven 50 g sachets (350 g pack). The latest listed batch line items total 47.57 kg. Normalize their weights to 100 g blend and a 50 g sachet. The formula excludes peanuts and sesame.

## Product specification

**Formula line items:** apple powder 3.00 kg; beetroot powder 3.00 kg; carrot powder 3.00 kg; Bengal gram 17.00 kg; oats 8.00 kg; ragi flakes 5.00 kg; samai flakes 1.50 kg; Kuthiraivali flakes 1.50 kg; sunflower seeds 3.00 kg; cocoa powder 2.00 kg; palm sugar 0.50 kg; cardamom powder 0.07 kg. Total 47.57 kg. Category shares calculated from these line items are fruit/root powders 18.92%, grains/millets 33.63%, pulses 35.74%, seeds 6.31%, and natural flavour/sweetener 5.40%. App quantities are recipe weights, not nutrient amounts.

**Serving and preparation:** one 50 g sachet mixed with 200 ml warm water or warm/cold milk. Stir or shake until blended. Ready in about three minutes.

**Nutrition display:** use the latest brand-supplied per-50-g panel: 219 kcal; protein 8.5 g; total fat 5.1 g (saturated 0.9 g, MUFA+PUFA 4.0 g); carbohydrate 33.0 g; naturally occurring sugars 9.6 g; added sugar from palm sugar 0.53 g; dietary fibre 4.8 g; sodium 22 mg; calcium 82 mg; iron 3.2 mg; magnesium 96 mg; phosphorus 208 mg; potassium 310 mg; zinc 1.9 mg; vitamin A 410 μg; folate 54 μg; vitamin E 3.8 mg; B1 0.31 mg; B3 3.4 mg; B6 0.28 mg. Show supplied RDA percentages and the approximate-value/natural-variation note. Do not revert to older nutrition values or say the blend has no added sugar.

Use transparent product language from the latest approved artwork: plant protein, high fibre, vitamins/minerals, and no artificial flavours or sweeteners; palm sugar remains present. Avoid transferring product-specific health promises from the older engineering PDF or previous artwork.

## Implementation approach

- Continue the existing Expo Router / React Native / TypeScript mobile stack; do not regenerate it.
- Bundle the corrected customer-supplied hero without cropping, using accessible image text and responsive sizing.
- Keep formula and source-backed general ingredient context in `shared/abcplus-ingredients.ts`; derive per-100-g and per-50-g amounts and category shares from the 47.57-kg line items. Ingredient taps open a source-linked modal for each of the 12 ingredients.
- Keep current brand-supplied nutrition data in `shared/abcplus-nutrition.ts`, with selected highlights on the landing page and an accessible detailed nutrition modal.
- Place “How the blend is designed,” approximate per-sachet food comparisons, micronutrient/body-role explanations and the breakfast reminder directly below the hero. Explain generally that starch is digested into glucose for energy, fibre is not digested like starch, protein is digested into amino acids, dietary fat supplies energy and helps absorb some vitamins, and listed micronutrients have normal roles. Food comparisons are approximate illustrations, not substitute meals or equal overall nutrition.
- Preserve source links and distinguish general nutrient physiology from measured ABC+ effects. Do not promise specific skin or hair results, disease treatment/prevention, satiety, focus, glycaemic control, heart protection, increased iron absorption, clinical validation or a shelf-life claim. Do not transfer PDF-specific claims about a superseded formula/process.
- Preserve Today/Week/Notes/Habits/Month screens, repository submissions, local drafts, account isolation, analytics, auth and DB structure. Calendar data stays on the device; no backend schema or account data change is required.

## Calendar reminder experience

Add an explicit reminder action to actionable Today items (focus, priorities, quick tasks, daily habits, notes, gratitude and tomorrow’s first step), Week items (goal, outcomes, must-do tasks, fixing/energy prompts), Brain Dump drafts and each saved note, monthly focus and each named habit, actionable Month review reflections, and the ABC+ breakfast routine. Prefill a sensible local date/time, event title/context and an event-start alert; let the user change date/time, set recurrence and save or cancel in the operating-system calendar form. Never create events when a user types, checks a habit or opens a screen.

Use `expo-calendar` installed for SDK 57. On iOS request write-only calendar access only after a reminder tap; do not read existing event details. On Android open the system event form without requesting calendar-read/write permissions. On Web download a valid `.ics` file for the user to import. Handle permission denial, cancel and unsupported preview without losing the source entry. Explain that events belong to the device calendar, not ABC+/Life OS storage.

Native `expo-calendar` is not included in Expo Go. The Web `.ics` path is verified in Preview; native event forms require a custom development or production build and a device smoke check before claiming native runtime verification.

## Project structure

- `assets/images/heavenlys-abcplus-hero.png`: exact rectified customer-supplied artwork.
- `app/(tabs)/index.tsx`: product-first ABC+ landing page and quick Life OS links.
- `app/(tabs)/today.tsx`, `week.tsx`, `capture.tsx`, `habits.tsx`, `month.tsx`: reminder actions attached to current user entries while preserving each existing screen’s state/submit behavior.
- `components/abcplus/`: ingredient details, nutrition details and sourced body-mechanism/food-comparison content.
- `components/life-os/calendar-reminder-action.tsx`: reusable opt-in reminder action and status feedback.
- `components/life-os/remindable-field.tsx`: action wrapper for non-empty text fields.
- `components/life-os/ui.tsx`: optional reminder hooks on task and habit/check rows.
- `components/life-os/note-archive.tsx`: per-saved-note reminder action alongside, not replacing, submit/delete controls.
- `lib/calendar/reminder.ts`: platform-aware native calendar / Web `.ics` behavior.
- `lib/calendar/reminder-utils.ts`: pure date, event and ICS helpers.
- `tests/calendar-reminder.test.ts`: date defaults, event duration, escaping and ICS payload behavior.
- `app.config.ts`: Expo Calendar plugin with iOS write-only permission disclosures and unused Android calendar permissions blocked.
- `docs/engineering/calendar-integration.md`: SDK/privacy research notes; `docs/abcplus-ingredient-research/`: product formula and evidence notes.

## Design system

**Movement:** warm pantry editorial with contemporary botanical packaging cues. **Principles:** product-first, calm and readable, ingredient transparency, practical micro-interactions. **Palette:** cream and oat neutrals suggest food and clarity; cocoa-brown grounds the brand; deep forest and muted sage communicate botanical warmth without medicalizing the product. **Layout:** a single-column mobile story led by the supplied hero, then short explanatory panels, followed by ingredient and nutrition details and finally optional Life OS tools. **Signature elements:** ingredient-weight rows with clear sachet equivalents, small rounded evidence/source chips, and thin botanical accents. **Interaction:** tap an ingredient to see general context and citations; open full nutrition values only when wanted; use reminders only by explicit user action. **Animation:** understated modal fade and native press feedback only. **Typography:** retain the existing Georgia editorial headline with a clean sans-serif for factual data, labels and controls; use tabular alignment for nutrient quantities. **Brand essence:** a quick, grain-forward breakfast for busy mornings that pairs practical preparation with transparent product details. **Personality:** grounded, warm, considered. **Voice:** concise and food-first; examples: “Goodness in every sachet.” and “Mix warm or cold. Ready in about three minutes.” **Wordmark:** preserve supplied Heavenly’s/ABC+ artwork. **Signature colour:** deep forest green.

## Evidence and customer-claim limits

Ingredient facts are generic food context; formula weights do not establish each ingredient’s nutrient contribution. Nutrition figures and food comparisons are supplied by the brand, approximate and not independently verified in the app. General nutrient roles do not prove finished-product skin/hair results or other health outcomes. Refer customers to the final pack for full nutrition and allergen/cross-contact statements.
