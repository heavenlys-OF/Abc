from math import ceil
from pathlib import Path
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parents[1] / "assets" / "images"
OUT.mkdir(parents=True, exist_ok=True)
SCALE = 3
SIZE = 1024
OAT = "#F4EFE5"
DARK = "#344B3B"
SAGE = "#728C74"
SUN = "#D99B67"


def bezier(points, steps=60):
    p0, p1, p2, p3 = points
    path = []
    for i in range(steps + 1):
        t = i / steps
        u = 1 - t
        x = u**3 * p0[0] + 3 * u**2 * t * p1[0] + 3 * u * t**2 * p2[0] + t**3 * p3[0]
        y = u**3 * p0[1] + 3 * u**2 * t * p1[1] + 3 * u * t**2 * p2[1] + t**3 * p3[1]
        path.append((round(x * SCALE), round(y * SCALE)))
    return path


def draw_icon(size=SIZE, transparent=False, monochrome=False):
    scale = size / SIZE
    ss = max(1, round(3 * scale))
    s = round(SIZE * scale)
    bg = (0, 0, 0, 0) if transparent else OAT
    image = Image.new("RGBA", (s * SCALE, s * SCALE), bg)
    d = ImageDraw.Draw(image)

    def xy(v):
        return round(v * scale * SCALE)

    def line(points, fill, width=22):
        d.line([(xy(x), xy(y)) for x, y in points], fill=fill, width=max(1, xy(width)), joint="curve")

    if monochrome:
        dark, sage, sun, bg_fill = "#25362B", "#25362B", "#25362B", (0, 0, 0, 0)
    else:
        dark, sage, sun, bg_fill = DARK, SAGE, SUN, OAT

    cx, baseline, radius = 512, 602, 176
    # A rising sun: a clean arc, interrupted at the horizon to remain legible when tiny.
    d.arc((xy(cx - radius), xy(baseline - radius), xy(cx + radius), xy(baseline + radius)), 180, 360, fill=sun, width=xy(38))
    # Three quiet rays reinforce the sunrise without adding visual clutter.
    line([(512, 338), (512, 278)], sun, 24)
    line([(365, 397), (322, 354)], sun, 24)
    line([(659, 397), (702, 354)], sun, 24)
    # A single sprouting leaf grows from the horizon on the right side of the sun.
    stem = bezier([(510, 606), (535, 546), (604, 479), (673, 427)])
    d.line(stem, fill=dark, width=xy(26), joint="curve")
    leaf_a = bezier([(650, 449), (632, 391), (672, 354), (751, 351)])
    leaf_b = bezier([(751, 351), (751, 419), (718, 456), (650, 449)])
    leaf_shape = leaf_a + leaf_b[1:]
    d.polygon(leaf_shape, fill=sage)
    vein = bezier([(666, 438), (686, 408), (716, 380), (741, 360)])
    d.line(vein, fill=dark if monochrome else OAT, width=xy(11), joint="curve")
    # Paper-like horizon anchors the symbol; keep the silhouette square, never pre-rounded.
    line([(291, 608), (733, 608)], dark, 27)
    # A tiny ground curve suggests forward growth and echoes a notebook underline.
    line([(375, 666), (512, 682), (650, 666)], sage, 16)
    image = image.resize((size, size), Image.Resampling.LANCZOS)
    return image


# Full-bleed square launcher/splash art; platform-native launchers apply their own masks.
draw_icon(1024).save(OUT / "icon.png")
draw_icon(1024).save(OUT / "splash-icon.png")
draw_icon(64).save(OUT / "favicon.png")

# Android adaptive-icon layers: transparent mark foreground and a solid oat backing.
draw_icon(432, transparent=True).save(OUT / "android-icon-foreground.png")
Image.new("RGBA", (432, 432), OAT).save(OUT / "android-icon-background.png")
draw_icon(432, transparent=True, monochrome=True).save(OUT / "android-icon-monochrome.png")
