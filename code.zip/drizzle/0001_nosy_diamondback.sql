CREATE TABLE `productivity_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`entryType` enum('daily','weekly','brain_dump','habit_month','month_review') NOT NULL,
	`recordKey` varchar(64) NOT NULL,
	`periodKey` varchar(10) NOT NULL,
	`payload` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `productivity_entries_id` PRIMARY KEY(`id`),
	CONSTRAINT `productivity_entries_owner_type_key_uq` UNIQUE(`userId`,`entryType`,`recordKey`)
);
--> statement-breakpoint
ALTER TABLE `productivity_entries` ADD CONSTRAINT `productivity_entries_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `productivity_entries_owner_type_period_idx` ON `productivity_entries` (`userId`,`entryType`,`periodKey`);