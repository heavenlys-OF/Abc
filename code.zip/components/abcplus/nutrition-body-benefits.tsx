import React from "react";
import { Linking, Text, TouchableOpacity, View } from "react-native";
import { C, Section } from "@/components/life-os/ui";
import { CalendarReminderAction } from "@/components/life-os/calendar-reminder-action";
import { suggestedReminderStartDate } from "@/lib/calendar/reminder";

type BenefitSource = { title: string; url: string };
type EducationCard = {
  title: string;
  eyebrow: string;
  detail: string;
  sources: readonly BenefitSource[];
};

const BLEND_MECHANISM: readonly EducationCard[] = [
  {
    title: "Complex carbohydrates for everyday fuel",
    eyebrow: "GRAINS · MILLETS · BENGAL GRAM",
    detail:
      "These foods supply carbohydrate, including starch. During digestion, most starch is broken down into glucose that the body can use for energy. The glucose response depends on the finished recipe, processing, serving and the rest of the meal; ABC+ has no product-specific glycaemic test shown here.",
    sources: [
      { title: "MedlinePlus — Carbohydrates", url: "https://medlineplus.gov/ency/article/002469.htm" },
    ],
  },
  {
    title: "Fibre as part of a varied meal",
    eyebrow: "4.8 G DIETARY FIBRE PER 50 G · BRAND-SUPPLIED",
    detail:
      "Dietary fibre is not digested like starch. Fibre-rich foods and enough liquids can support normal bowel habits. This explains a general role of fibre; it does not show that ABC+ treats constipation or creates a specific digestive outcome.",
    sources: [
      { title: "NIDDK — Eating, Diet, and Nutrition for Constipation", url: "https://www.niddk.nih.gov/health-information/digestive-diseases/constipation/eating-diet-nutrition" },
    ],
  },
  {
    title: "Plant protein and amino acids",
    eyebrow: "8.5 G PROTEIN PER 50 G · BRAND-SUPPLIED",
    detail:
      "Food protein is digested into amino acids. The body uses amino acids to maintain and repair cells and make new proteins. One serving is only part of daily protein needs and does not demonstrate a muscle-building or recovery result.",
    sources: [
      { title: "MedlinePlus — Protein in diet", url: "https://medlineplus.gov/ency/article/002467.htm" },
    ],
  },
  {
    title: "Dietary fats have everyday roles",
    eyebrow: "5.1 G TOTAL FAT · 4.0 G MUFA + PUFA PER 50 G · BRAND-SUPPLIED",
    detail:
      "Dietary fat supplies energy and helps the body absorb some vitamins. The panel lists total fat and its unsaturated-fat subtotal. These general roles do not mean ABC+ is heart-protective or that its fat profile has been independently analysed in this app.",
    sources: [
      { title: "MedlinePlus — Dietary fats", url: "https://medlineplus.gov/dietaryfats.html" },
      { title: "NIH NIGMS — What Do Fats Do in the Body?", url: "https://nigms.nih.gov/biobeat/2024/01/what-do-fats-do-in-the-body" },
    ],
  },
  {
    title: "A mix of naturally occurring nutrients",
    eyebrow: "VITAMINS · MINERALS · SEED FOODS",
    detail:
      "The latest supplied panel lists iron, calcium, magnesium, phosphorus, potassium, zinc and vitamins A, E, B1, B3, B6 and folate. These nutrients have ordinary roles across body systems. The listed values are brand-supplied estimates, not independent testing in this app.",
    sources: [
      { title: "NIH ODS — Iron", url: "https://ods.od.nih.gov/factsheets/Iron-HealthProfessional/" },
      { title: "NIH ODS — Calcium", url: "https://ods.od.nih.gov/factsheets/Calcium-HealthProfessional/" },
    ],
  },
];

const BODY_ROLES: readonly EducationCard[] = [
  {
    title: "Energy metabolism",
    eyebrow: "THIAMIN B1 · NIACIN B3 · VITAMIN B6",
    detail:
      "B vitamins take part in normal cellular processes that release or use energy from food. Their presence is not a promise of an instant energy boost or improved focus.",
    sources: [
      { title: "NIH ODS — Thiamin", url: "https://ods.od.nih.gov/factsheets/Thiamin-HealthProfessional/" },
      { title: "NIH ODS — Niacin", url: "https://ods.od.nih.gov/factsheets/Niacin-HealthProfessional/" },
      { title: "NIH ODS — Vitamin B6", url: "https://ods.od.nih.gov/factsheets/VitaminB6-HealthProfessional/" },
    ],
  },
  {
    title: "Iron and oxygen transport",
    eyebrow: "IRON · 3.2 MG PER 50 G · BRAND-SUPPLIED",
    detail:
      "Iron is needed to make haemoglobin, the red-blood-cell protein that carries oxygen from the lungs to body tissues. The amount in a sachet does not diagnose or treat iron deficiency.",
    sources: [
      { title: "NIH ODS — Iron", url: "https://ods.od.nih.gov/factsheets/Iron-HealthProfessional/" },
    ],
  },
  {
    title: "Bones, muscles and nerves",
    eyebrow: "CALCIUM · MAGNESIUM · PHOSPHORUS",
    detail:
      "These minerals participate in normal bone structure and in functions such as muscle contraction, nerve signalling and cellular energy. One food cannot replace a varied diet or medical care.",
    sources: [
      { title: "NIH ODS — Calcium", url: "https://ods.od.nih.gov/factsheets/Calcium-HealthProfessional/" },
      { title: "NIH ODS — Magnesium", url: "https://ods.od.nih.gov/factsheets/Magnesium-HealthProfessional/" },
      { title: "NIH ODS — Phosphorus", url: "https://ods.od.nih.gov/factsheets/Phosphorus-HealthProfessional/" },
    ],
  },
  {
    title: "Skin and tissue function",
    eyebrow: "VITAMIN A · ZINC · VITAMIN E",
    detail:
      "Vitamin A supports normal cell differentiation; zinc is involved in protein synthesis and cell division; vitamin E has antioxidant functions. Those roles do not show that ABC+ improves skin appearance, heals a condition or prevents skin ageing.",
    sources: [
      { title: "NIH ODS — Vitamin A", url: "https://ods.od.nih.gov/factsheets/VitaminA-HealthProfessional/" },
      { title: "NIH ODS — Zinc", url: "https://ods.od.nih.gov/factsheets/Zinc-HealthProfessional/" },
      { title: "NIH ODS — Vitamin E", url: "https://ods.od.nih.gov/factsheets/VitaminE-HealthProfessional/" },
    ],
  },
  {
    title: "Hair: a careful note",
    eyebrow: "NO HAIR-GROWTH RESULT IS ESTABLISHED",
    detail:
      "The supplied nutrition panel does not establish that the mix grows hair or prevents hair loss. Biotin is not listed, and evidence that biotin supplements improve hair in people without deficiency is limited.",
    sources: [
      { title: "NIH ODS — Biotin", url: "https://ods.od.nih.gov/factsheets/Biotin-HealthProfessional/" },
      { title: "NIH ODS — Zinc", url: "https://ods.od.nih.gov/factsheets/Zinc-HealthProfessional/" },
    ],
  },
  {
    title: "Normal immune function",
    eyebrow: "VITAMIN A · ZINC",
    detail:
      "Vitamin A and zinc are involved in normal immune-system function. Listing these nutrients does not mean ABC+ prevents infections or replaces vaccination, medical advice or a balanced diet.",
    sources: [
      { title: "NIH ODS — Vitamin A", url: "https://ods.od.nih.gov/factsheets/VitaminA-HealthProfessional/" },
      { title: "NIH ODS — Zinc", url: "https://ods.od.nih.gov/factsheets/Zinc-HealthProfessional/" },
    ],
  },
];

function EducationCards({ items }: { items: readonly EducationCard[] }) {
  return (
    <View style={{ gap: 9 }}>
      {items.map((item) => (
        <View key={item.title} style={{ padding: 12, borderRadius: 14, backgroundColor: C.card, borderWidth: 1, borderColor: C.line }}>
          <Text style={{ color: C.sage, fontSize: 8, letterSpacing: 1.1, fontWeight: "900" }}>{item.eyebrow}</Text>
          <Text style={{ color: C.ink, fontSize: 13, fontWeight: "800", marginTop: 4 }}>{item.title}</Text>
          <Text style={{ color: C.muted, fontSize: 10, lineHeight: 15, marginTop: 5 }}>{item.detail}</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
            {item.sources.map((source) => (
              <TouchableOpacity
                key={source.url}
                accessibilityRole="link"
                accessibilityLabel={`Open source: ${source.title}`}
                onPress={() => void Linking.openURL(source.url)}
                style={{ minHeight: 34, justifyContent: "center", paddingHorizontal: 9, paddingVertical: 6, borderRadius: 10, backgroundColor: "#F7F8F3", borderWidth: 1, borderColor: C.line }}
              >
                <Text style={{ color: C.forest, fontSize: 9, fontWeight: "700" }}>{source.title} ↗</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      ))}
    </View>
  );
}

function NutrientComparisons() {
  const comparisons = [
    ["8.5 g protein", "about 1.5 eggs"],
    ["4.8 g fibre", "about 1.5 bowls of oats"],
    ["3.2 mg iron", "about 2 cups of spinach"],
    ["82 mg calcium", "about 80 ml of milk"],
    ["96 mg magnesium", "about 12 almonds"],
    ["310 mg potassium", "about 1 banana"],
    ["410 μg vitamin A", "about 1 large carrot"],
    ["54 μg folate", "about 1 cup cooked greens"],
    ["3.8 mg vitamin E", "about 1 tablespoon sunflower seeds"],
  ] as const;

  return (
    <Section
      title="Approximate food comparisons"
      caption="Everyday references shown in the supplied per-sachet product panel."
      color={C.wash}
    >
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
        {comparisons.map(([nutrient, food]) => (
          <View key={nutrient} style={{ width: "48.5%", minHeight: 58, padding: 10, borderRadius: 12, backgroundColor: C.card, borderWidth: 1, borderColor: C.line }}>
            <Text style={{ color: C.forest, fontSize: 11, lineHeight: 15, fontWeight: "900" }}>{nutrient}</Text>
            <Text style={{ color: C.muted, fontSize: 10, lineHeight: 14, marginTop: 3 }}>{food}</Text>
          </View>
        ))}
      </View>
      <Text style={{ color: C.muted, fontSize: 9, lineHeight: 14, marginTop: 9 }}>
        These approximate comparisons are supplied by the brand for scale only. They are not interchangeable foods, equal full-meal nutrition, or proof of a specific health result.
      </Text>
    </Section>
  );
}

export function NutritionBodyBenefits() {
  return (
    <>
      <Section
        title="How the blend is designed"
        caption="A simple look at the food groups and the way their nutrients are generally used by the body."
        color={C.wash}
      >
        <EducationCards items={BLEND_MECHANISM} />
        <Text style={{ color: C.muted, fontSize: 9, lineHeight: 14, marginTop: 10 }}>
          These are general nutrition mechanisms, not a clinical study of ABC+. No glycaemic, satiety, focus, iron-absorption or disease-treatment outcome is established here.
        </Text>
      </Section>
      <NutrientComparisons />
      <Section
        title="Micronutrients and body roles"
        caption="Normal nutrient functions from authoritative references—not guaranteed results from ABC+."
      >
        <EducationCards items={BODY_ROLES} />
        <Text style={{ color: C.muted, fontSize: 9, lineHeight: 14, marginTop: 10 }}>
          Brand-supplied values are approximate. A nutrient’s role in the body does not establish that this finished blend prevents deficiency or produces a specific skin, hair or other health outcome. ABC+ is a food, not a treatment.
        </Text>
      </Section>
      <Section title="Make breakfast easy" caption="Choose the time in your calendar; set a repeat if you like." color={C.wash}>
        <CalendarReminderAction
          title="Heavenly’s ABC+ breakfast"
          notes="Prepare one 50 g sachet using the ABC+ directions. Choose warm water or warm/cold milk."
          defaultStartDate={suggestedReminderStartDate(1)}
          label="Remind me at breakfast"
        />
      </Section>
    </>
  );
}
