import React from "react";
import {
  Linking,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { C } from "@/components/life-os/ui";
import type { AbcPlusIngredientItem } from "@/shared/abcplus-ingredients";

type IngredientDetailsProps = {
  ingredient: AbcPlusIngredientItem | null;
  onClose: () => void;
};

function formatGrams(value: number) {
  return `${value.toFixed(2)} g`;
}

export function IngredientDetailsModal({ ingredient, onClose }: IngredientDetailsProps) {
  return (
    <Modal
      visible={ingredient !== null}
      transparent
      animationType="fade"
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <View style={styles.overlay}>
        <TouchableOpacity
          accessibilityRole="button"
          accessibilityLabel="Close ingredient details"
          activeOpacity={1}
          onPress={onClose}
          style={styles.backdrop}
        />
        {ingredient ? (
          <View style={styles.sheet}>
            <View style={styles.handle} />
            <ScrollView
              contentContainerStyle={styles.content}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
            >
              <View style={styles.eyebrowRow}>
                <Text style={styles.eyebrow}>INGREDIENT NOTE</Text>
                <TouchableOpacity
                  accessibilityRole="button"
                  accessibilityLabel="Close ingredient details"
                  onPress={onClose}
                  hitSlop={10}
                  style={styles.closeButton}
                >
                  <Text style={styles.closeText}>×</Text>
                </TouchableOpacity>
              </View>
              <Text style={styles.title}>{ingredient.name}</Text>
              <Text style={styles.category}>{ingredient.noteTitle}</Text>

              <View style={styles.amountCard}>
                <View>
                  <Text style={styles.amountLabel}>IN ONE 50 G SACHET</Text>
                  <Text style={styles.amountValue}>{formatGrams(ingredient.amountPer100g / 2)}</Text>
                </View>
                <Text style={styles.amountDetail}>
                  {formatGrams(ingredient.amountPer100g)} per 100 g blend
                </Text>
              </View>

              <Text style={styles.body}>{ingredient.generalContext}</Text>
              {ingredient.sourceContextNote ? (
                <Text style={styles.sourceContext}>{ingredient.sourceContextNote}</Text>
              ) : null}
              <View style={styles.noteBox}>
                <Text style={styles.noteText}>
                  The amounts shown are formula weights, not nutrient weights. General ingredient references do not measure the finished ABC+ blend or establish product-specific health outcomes.
                </Text>
              </View>
              <Text style={styles.sourceHeading}>Explore the sources</Text>
              <View style={styles.sourceList}>
                {ingredient.sources.map((source) => (
                  <TouchableOpacity
                    key={source.url}
                    accessibilityRole="link"
                    accessibilityLabel={`Open source: ${source.title}`}
                    onPress={() => void Linking.openURL(source.url)}
                    style={styles.sourceButton}
                  >
                    <Text style={styles.sourceTitle}>{source.title}</Text>
                    <Text style={styles.sourceArrow}>↗</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
            <TouchableOpacity
              accessibilityRole="button"
              onPress={onClose}
              style={styles.doneButton}
            >
              <Text style={styles.doneText}>Done</Text>
            </TouchableOpacity>
          </View>
        ) : null}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 18,
    backgroundColor: "rgba(31, 43, 35, 0.58)",
  },
  backdrop: { position: "absolute", top: 0, right: 0, bottom: 0, left: 0 },
  sheet: {
    width: "100%",
    maxWidth: 520,
    maxHeight: "88%",
    borderRadius: 24,
    overflow: "hidden",
    backgroundColor: C.card,
    borderWidth: 1,
    borderColor: C.line,
  },
  handle: {
    width: 38,
    height: 4,
    borderRadius: 4,
    alignSelf: "center",
    marginTop: 10,
    backgroundColor: "#D9D5CA",
  },
  content: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 16 },
  eyebrowRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  eyebrow: { color: C.sage, fontSize: 9, letterSpacing: 1.5, fontWeight: "800" },
  closeButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: C.wash,
  },
  closeText: { color: C.forest, fontSize: 23, lineHeight: 25, fontWeight: "400" },
  title: { color: C.ink, fontFamily: "Georgia", fontSize: 25, lineHeight: 30, marginTop: 7 },
  category: { color: C.sage, fontSize: 11, fontWeight: "700", marginTop: 4 },
  amountCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 10,
    marginTop: 15,
    padding: 12,
    borderRadius: 13,
    backgroundColor: C.wash,
  },
  amountLabel: { color: C.forest, fontSize: 8, letterSpacing: 1, fontWeight: "800" },
  amountValue: { color: C.ink, fontSize: 19, fontWeight: "900", marginTop: 2 },
  amountDetail: { color: C.muted, fontSize: 10, lineHeight: 15, textAlign: "right", flex: 1 },
  body: { color: C.ink, fontSize: 13, lineHeight: 20, marginTop: 14 },
  allergenBox: { marginTop: 12, padding: 11, borderRadius: 12, backgroundColor: "#F8E9E2" },
  allergenText: { color: "#713D2B", fontSize: 11, lineHeight: 16, fontWeight: "800" },
  sourceContext: { color: C.muted, fontSize: 10, lineHeight: 15, marginTop: 11, fontStyle: "italic" },
  noteBox: { marginTop: 13, padding: 11, borderRadius: 12, backgroundColor: "#F7F1E4" },
  noteText: { color: "#665F51", fontSize: 10, lineHeight: 15 },
  sourceHeading: { color: C.ink, fontSize: 12, fontWeight: "800", marginTop: 18, marginBottom: 7 },
  sourceList: { gap: 7 },
  sourceButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 10,
    minHeight: 44,
    paddingHorizontal: 11,
    paddingVertical: 8,
    borderRadius: 11,
    backgroundColor: "#F7F8F3",
    borderWidth: 1,
    borderColor: C.line,
  },
  sourceTitle: { flex: 1, color: C.forest, fontSize: 10, lineHeight: 14, fontWeight: "700" },
  sourceArrow: { color: C.sage, fontSize: 15, fontWeight: "800" },
  doneButton: {
    minHeight: 48,
    marginHorizontal: 18,
    marginBottom: 16,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: C.forest,
  },
  doneText: { color: "#FFFCF6", fontSize: 13, fontWeight: "800" },
});
