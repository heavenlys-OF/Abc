import React from "react";
import {
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { C } from "@/components/life-os/ui";
import { ABC_PLUS_NUTRITION, type NutritionFact } from "@/shared/abcplus-nutrition";

type NutritionDetailsProps = {
  visible: boolean;
  onClose: () => void;
};

function FactRows({ facts }: { facts: readonly NutritionFact[] }) {
  return (
    <View>
      {facts.map((fact) => (
        <View key={fact.label} style={[styles.factRow, fact.indent && styles.indentedRow]}>
          <Text style={[styles.factLabel, fact.indent && styles.subFact]}>{fact.label}</Text>
          <Text style={styles.factAmount}>{fact.amount}</Text>
          <Text style={styles.factRda}>{fact.rda ?? "—"}</Text>
        </View>
      ))}
    </View>
  );
}

export function NutritionDetailsModal({ visible, onClose }: NutritionDetailsProps) {
  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <View style={styles.overlay}>
        <TouchableOpacity
          accessibilityRole="button"
          accessibilityLabel="Close nutrition details"
          activeOpacity={1}
          onPress={onClose}
          style={styles.backdrop}
        />
        <View style={styles.sheet}>
          <View style={styles.handle} />
          <ScrollView
            contentContainerStyle={styles.content}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <View style={styles.eyebrowRow}>
              <Text style={styles.eyebrow}>PER {ABC_PLUS_NUTRITION.servingGrams} G SACHET</Text>
              <TouchableOpacity
                accessibilityRole="button"
                accessibilityLabel="Close nutrition details"
                onPress={onClose}
                hitSlop={10}
                style={styles.closeButton}
              >
                <Text style={styles.closeText}>×</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.title}>Nutrition highlights</Text>
            <Text style={styles.subtitle}>Selected values supplied with the product formulation.</Text>

            <View style={styles.energyCard}>
              <Text style={styles.energyLabel}>ENERGY</Text>
              <Text style={styles.energyValue}>{ABC_PLUS_NUTRITION.energyKcal} kcal</Text>
              <Text style={styles.energyRda}>{ABC_PLUS_NUTRITION.energyRda} RDA</Text>
            </View>

            <View style={styles.tableHeader}>
              <Text style={[styles.tableHeading, styles.nutrientHeading]}>Nutrient</Text>
              <Text style={[styles.tableHeading, styles.amountHeading]}>Per 50 g</Text>
              <Text style={[styles.tableHeading, styles.rdaHeading]}>% RDA</Text>
            </View>
            <FactRows facts={ABC_PLUS_NUTRITION.macros} />

            <Text style={styles.sectionHeading}>Vitamins & minerals</Text>
            <View style={styles.tableHeader}>
              <Text style={[styles.tableHeading, styles.nutrientHeading]}>Nutrient</Text>
              <Text style={[styles.tableHeading, styles.amountHeading]}>Per 50 g</Text>
              <Text style={[styles.tableHeading, styles.rdaHeading]}>% RDA</Text>
            </View>
            <FactRows facts={ABC_PLUS_NUTRITION.vitaminsAndMinerals} />

            <View style={styles.noteBox}>
              <Text style={styles.noteText}>{ABC_PLUS_NUTRITION.sugarNote}</Text>
            </View>
            <Text style={styles.footnote}>{ABC_PLUS_NUTRITION.note}</Text>
          </ScrollView>
          <TouchableOpacity
            accessibilityRole="button"
            accessibilityLabel="Done viewing nutrition highlights"
            onPress={onClose}
            style={styles.doneButton}
          >
            <Text style={styles.doneText}>Done</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 18,
    backgroundColor: "rgba(31, 43, 35, 0.58)",
  },
  backdrop: { position: "absolute", top: 0, right: 0, bottom: 0, left: 0 },
  sheet: {
    width: "100%",
    maxWidth: 520,
    maxHeight: "88%",
    borderRadius: 24,
    overflow: "hidden",
    backgroundColor: C.card,
    borderWidth: 1,
    borderColor: C.line,
  },
  handle: {
    width: 38,
    height: 4,
    borderRadius: 4,
    alignSelf: "center",
    marginTop: 10,
    backgroundColor: "#D9D5CA",
  },
  content: { paddingHorizontal: 18, paddingTop: 8, paddingBottom: 18 },
  eyebrowRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  eyebrow: { color: C.sage, fontSize: 9, letterSpacing: 1.4, fontWeight: "800" },
  closeButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: C.wash,
  },
  closeText: { color: C.forest, fontSize: 23, lineHeight: 25, fontWeight: "400" },
  title: { color: C.ink, fontFamily: "Georgia", fontSize: 24, lineHeight: 30, marginTop: 7 },
  subtitle: { color: C.muted, fontSize: 11, lineHeight: 16, marginTop: 2, marginBottom: 14 },
  energyCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 13,
    paddingVertical: 12,
    borderRadius: 13,
    backgroundColor: C.wash,
    marginBottom: 12,
  },
  energyLabel: { color: C.forest, fontSize: 9, fontWeight: "800", letterSpacing: 1.2 },
  energyValue: { color: C.ink, fontSize: 18, fontWeight: "900" },
  energyRda: { color: C.muted, fontSize: 10, fontWeight: "700" },
  tableHeader: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 7,
    borderBottomWidth: 1,
    borderColor: C.line,
  },
  tableHeading: { color: C.muted, fontSize: 9, fontWeight: "800" },
  nutrientHeading: { flex: 1.55 },
  amountHeading: { flex: 0.85, textAlign: "right" },
  rdaHeading: { flex: 0.55, textAlign: "right" },
  factRow: {
    flexDirection: "row",
    alignItems: "center",
    minHeight: 36,
    borderBottomWidth: 1,
    borderColor: "#EEE8DE",
  },
  indentedRow: { paddingLeft: 9 },
  factLabel: { flex: 1.55, color: C.ink, fontSize: 10, lineHeight: 14 },
  subFact: { color: C.muted, fontSize: 9 },
  factAmount: { flex: 0.85, color: C.ink, textAlign: "right", fontSize: 10, fontWeight: "700" },
  factRda: { flex: 0.55, color: C.muted, textAlign: "right", fontSize: 9 },
  sectionHeading: { color: C.ink, fontFamily: "Georgia", fontSize: 17, marginTop: 18, marginBottom: 4 },
  noteBox: { marginTop: 14, padding: 11, borderRadius: 12, backgroundColor: "#F7F1E4" },
  noteText: { color: "#665F51", fontSize: 10, lineHeight: 15, fontWeight: "600" },
  footnote: { color: C.muted, fontSize: 9, lineHeight: 14, marginTop: 10 },
  doneButton: {
    minHeight: 48,
    marginHorizontal: 18,
    marginBottom: 16,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: C.forest,
  },
  doneText: { color: "#FFFCF6", fontSize: 13, fontWeight: "800" },
});
