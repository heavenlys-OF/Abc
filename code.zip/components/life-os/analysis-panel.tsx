import React from "react";
import { Text, View } from "react-native";
import { C, Section } from "@/components/life-os/ui";
import type { ProductivityInsight } from "@/lib/life-os/analysis";

export function AnalysisPanel({ title, insight }: { title: string; insight: ProductivityInsight }) {
  return (
    <Section title={title} caption={insight.summary} color="#F7F4ED">
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 9 }}>
        {insight.metrics.map((metric) => (
          <View key={metric.label} style={{ width: "48%", minWidth: 110, flexGrow: 1, padding: 10, borderRadius: 12, backgroundColor: "#FFFCF6" }}>
            <Text style={{ color: C.muted, fontSize: 9, letterSpacing: 0.8, fontWeight: "800" }}>{metric.label.toUpperCase()}</Text>
            <Text style={{ color: C.ink, fontSize: 18, fontWeight: "700", marginTop: 4 }}>{metric.value}</Text>
            {metric.progress !== null ? (
              <View style={{ height: 4, borderRadius: 3, backgroundColor: "#E9E8DF", marginTop: 8, overflow: "hidden" }}>
                <View style={{ width: `${Math.round(metric.progress * 100)}%`, height: "100%", borderRadius: 3, backgroundColor: C.sage }} />
              </View>
            ) : <Text style={{ color: C.muted, fontSize: 10, marginTop: 7 }}>Waiting for a response</Text>}
          </View>
        ))}
      </View>
      <Text style={{ color: C.muted, fontSize: 10, lineHeight: 15, marginTop: 9 }}>A descriptive read of your entries, not a grade.</Text>
    </Section>
  );
}
