import React from "react";
import { View } from "react-native";
import { CalendarReminderAction } from "@/components/life-os/calendar-reminder-action";
import { Field } from "@/components/life-os/ui";
import { suggestedReminderStartDate } from "@/lib/calendar/reminder";

export function RemindableField({
  reminderPrefix,
  defaultStartDate,
  ...fieldProps
}: React.ComponentProps<typeof Field> & {
  reminderPrefix: string;
  defaultStartDate?: Date;
}) {
  const value = fieldProps.value?.trim() ?? "";
  const shortValue = value.replace(/\s+/g, " ").slice(0, 72);

  return (
    <View style={{ marginBottom: 4 }}>
      <Field {...fieldProps} />
      {value ? (
        <CalendarReminderAction
          title={`${reminderPrefix}: ${shortValue}`}
          notes={`${reminderPrefix}\n${value}`}
          defaultStartDate={defaultStartDate ?? suggestedReminderStartDate()}
          compact
        />
      ) : null}
    </View>
  );
}
