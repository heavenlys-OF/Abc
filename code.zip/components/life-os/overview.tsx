import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useRef, useState } from "react";
import { ScrollView, Text, TouchableOpacity, useWindowDimensions, View } from "react-native";
import { C, Section } from "@/components/life-os/ui";
import type { ProductivityInsight, InsightMetric } from "@/lib/life-os/analysis";

type OverviewPage = {
  key: string;
  label: string;
  insight: ProductivityInsight;
  tint: string;
  icon: React.ComponentProps<typeof Feather>["name"];
  actions: { label: string; route: "/today" | "/week" | "/habits" | "/month" }[];
};

function SmallMetric({ metric }: { metric: InsightMetric }) {
  return (
    <View style={{ flex: 1, minWidth: 100, backgroundColor: "rgba(255,255,255,0.48)", borderRadius: 12, paddingHorizontal: 11, paddingVertical: 9 }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "baseline" }}>
        <Text style={{ color: C.muted, fontSize: 10, fontWeight: "700", letterSpacing: 0.35 }}>{metric.label.toUpperCase()}</Text>
        <Text style={{ color: C.forest, fontSize: 13, fontWeight: "800" }}>{metric.value}</Text>
      </View>
      {metric.progress !== null ? (
        <View style={{ height: 4, borderRadius: 3, backgroundColor: "rgba(82,111,86,0.12)", marginTop: 8, overflow: "hidden" }}>
          <View style={{ width: `${Math.round(metric.progress * 100)}%`, height: "100%", backgroundColor: C.sage, borderRadius: 3 }} />
        </View>
      ) : <Text style={{ color: C.muted, fontSize: 10, marginTop: 7 }}>No responses yet</Text>}
    </View>
  );
}

export function OverviewCarousel({ daily, weekly, monthly }: {
  daily: ProductivityInsight;
  weekly: ProductivityInsight;
  monthly: ProductivityInsight;
}) {
  const router = useRouter();
  const { width: screenWidth } = useWindowDimensions();
  const scrollRef = useRef<ScrollView>(null);
  const [carouselWidth, setCarouselWidth] = useState(0);
  const cardWidth = carouselWidth || Math.min(Math.max(screenWidth - 76, 220), 544);
  const [active, setActive] = useState(0);
  const pages: OverviewPage[] = [
    { key: "daily", label: "DAILY PULSE", insight: daily, tint: C.wash, icon: "sun", actions: [{ label: "Open today", route: "/today" }] },
    { key: "weekly", label: "WEEKLY RHYTHM", insight: weekly, tint: "#F2EDE3", icon: "calendar", actions: [{ label: "Open weekly reset", route: "/week" }] },
    { key: "monthly", label: "MONTHLY GARDEN", insight: monthly, tint: C.lilac, icon: "activity", actions: [{ label: "Track habits", route: "/habits" }, { label: "Review month", route: "/month" }] },
  ];

  return (
    <Section title="Your rhythm" caption="Swipe for a live read of today's, this week's, and this month's responses — no opaque score.">
      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        onLayout={(event) => {
          const measuredWidth = event.nativeEvent.layout.width;
          if (measuredWidth > 0 && measuredWidth !== carouselWidth) setCarouselWidth(measuredWidth);
        }}
        decelerationRate="fast"
        showsHorizontalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onMomentumScrollEnd={(event) => setActive(Math.max(0, Math.min(pages.length - 1, Math.round(event.nativeEvent.contentOffset.x / cardWidth))))}
        accessibilityLabel="Daily, weekly and monthly productivity overview. Swipe horizontally to change summary."
      >
        {pages.map((page, index) => (
          <View key={page.key} style={{ width: cardWidth, backgroundColor: page.tint, borderRadius: 15, padding: 14, minHeight: 220 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 7 }}>
              <Feather name={page.icon} size={14} color={C.sage} />
              <Text style={{ color: C.sage, fontSize: 9, fontWeight: "800", letterSpacing: 1.2 }}>{page.label}</Text>
            </View>
            <Text style={{ fontFamily: "Georgia", color: C.ink, fontSize: 22, lineHeight: 28, marginTop: 8 }}>{page.insight.headline}</Text>
            <Text style={{ color: C.muted, fontSize: 12, lineHeight: 18, marginTop: 4, minHeight: 36 }}>{page.insight.summary}</Text>
            <View style={{ flexDirection: "row", gap: 8, marginTop: 10 }}>
              {page.insight.metrics.slice(0, 2).map((metric) => <SmallMetric key={metric.label} metric={metric} />)}
            </View>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 10 }}>
              {page.actions.map((action) => (
                <TouchableOpacity
                  key={action.route}
                  accessibilityRole="button"
                  accessibilityLabel={action.label}
                  onPress={() => router.push(action.route)}
                  style={{ minHeight: 35, paddingHorizontal: 11, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.7)", flexDirection: "row", alignItems: "center", gap: 6 }}
                >
                  <Text style={{ color: C.forest, fontSize: 11, fontWeight: "700" }}>{action.label}</Text>
                  <Feather name="arrow-up-right" size={12} color={C.forest} />
                </TouchableOpacity>
              ))}
            </View>
            <Text accessibilityLabel={`Summary ${index + 1} of ${pages.length}`} style={{ position: "absolute", top: 13, right: 14, color: C.muted, fontSize: 9 }}>{index + 1} / {pages.length}</Text>
          </View>
        ))}
      </ScrollView>
      <View style={{ flexDirection: "row", justifyContent: "center", gap: 8, marginTop: 12 }}>
        {pages.map((page, index) => (
          <TouchableOpacity
            key={page.key}
            accessibilityRole="button"
            accessibilityLabel={`Show ${page.label.toLowerCase()} overview`}
            accessibilityState={{ selected: active === index }}
            onPress={() => {
              setActive(index);
              scrollRef.current?.scrollTo({ x: cardWidth * index, animated: true });
            }}
            style={{ padding: 4 }}
          >
            <View style={{ width: active === index ? 18 : 6, height: 6, borderRadius: 4, backgroundColor: active === index ? C.sage : "#C9C6BB" }} />
          </TouchableOpacity>
        ))}
      </View>
    </Section>
  );
}
