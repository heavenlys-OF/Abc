import React, { useState } from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { C } from "@/components/life-os/ui";
import { addCalendarReminder, type CalendarReminderOutcome } from "@/lib/calendar/reminder";

export function reminderOutcomeMessage(outcome: CalendarReminderOutcome): string {
  switch (outcome) {
    case "saved":
      return "Added to your calendar.";
    case "opened":
      return "Calendar form closed. If you saved, the reminder is in your calendar; if you canceled, no reminder was added.";
    case "cancelled":
      return "No reminder added; your Life OS entry is unchanged.";
    case "downloaded":
      return "Calendar file downloaded. Open it to import; set any repeat in your calendar.";
    case "permission-denied":
      return "Calendar access wasn't granted. Your entry is unchanged; you can change access in device settings.";
    case "unsupported":
      return "Calendar isn't available in this preview. Use a native development/production build, or open the Web .ics download.";
  }
}

export function CalendarReminderAction({
  title,
  notes,
  defaultStartDate,
  label = "Add reminder",
  compact = false,
}: {
  title: string;
  notes?: string;
  defaultStartDate?: Date;
  label?: string;
  compact?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  if (!title.trim()) return null;

  const onPress = async () => {
    if (busy) return;
    setBusy(true);
    setMessage("");
    try {
      const outcome = await addCalendarReminder({ title, notes, startDate: defaultStartDate });
      setMessage(reminderOutcomeMessage(outcome));
    } catch {
      setMessage("Calendar could not open. Your Life OS entry is still safe; try again on a supported app build.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ alignSelf: "flex-start", maxWidth: "100%", marginTop: compact ? 3 : 7 }}>
      <TouchableOpacity
        accessibilityRole="button"
        accessibilityLabel={`${label}: ${title}`}
        accessibilityHint="Opens a calendar form with this item prefilled. Choose the date, time, repeat and whether to save."
        accessibilityState={{ disabled: busy }}
        disabled={busy}
        onPress={() => void onPress()}
        style={{ minHeight: compact ? 32 : 38, paddingHorizontal: compact ? 9 : 12, borderRadius: 12, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, justifyContent: "center", opacity: busy ? 0.65 : 1 }}
      >
        <Text style={{ color: C.forest, fontSize: compact ? 10 : 11, lineHeight: 15, fontWeight: "800" }}>{busy ? "Opening calendar…" : `＋ ${label}`}</Text>
      </TouchableOpacity>
      {message ? (
        <Text accessibilityLiveRegion="polite" style={{ color: message.includes("unchanged") || message.includes("wasn't") || message.includes("could not") ? C.muted : C.forest, fontSize: 10, lineHeight: 15, marginTop: 4, maxWidth: 280 }}>
          {message}
        </Text>
      ) : null}
    </View>
  );
}
