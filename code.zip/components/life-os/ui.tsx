import React from "react";
import {
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import type { TaskItem } from "@/lib/life-os/store";

export const C = {
  paper: "#F4EFE5",
  card: "#FFFCF6",
  ink: "#25352D",
  forest: "#344B3B",
  sage: "#728C74",
  muted: "#788078",
  line: "#E7E0D4",
  apricot: "#D99570",
  lilac: "#EEE9F3",
  wash: "#E8EDE3",
};

export function Page({
  title,
  kicker,
  subtitle,
  brandName = "SIMPLE LIFE OS",
  brandMarkText,
  footerText = "FOCUS  ·  PLAN  ·  TAKE ACTION  ·  GROW",
  children,
}: {
  title: string;
  kicker?: string;
  subtitle?: string;
  brandName?: string;
  brandMarkText?: string;
  footerText?: string;
  children: React.ReactNode;
}) {
  return (
    <SafeAreaView edges={["top"]} style={styles.page}>
      <ScrollView
        contentContainerStyle={styles.pageContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.brandRow}>
          {brandMarkText ? (
            <View style={styles.brandMonogram}>
              <Text style={styles.brandMonogramText}>{brandMarkText}</Text>
            </View>
          ) : (
            <Image source={require("../../assets/images/icon.png")} style={styles.brandMark} resizeMode="contain" />
          )}
          <View>
            <Text style={styles.brand}>{brandName}</Text>
            <Text style={styles.kicker}>{kicker ?? "A GENTLER WAY TO PLAN"}</Text>
          </View>
        </View>
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
        {children}
        <Text style={styles.footer}>{footerText}</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

export function Section({
  title,
  children,
  caption,
  color = C.card,
}: {
  title: string;
  children: React.ReactNode;
  caption?: string;
  color?: string;
}) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {caption ? <Text style={styles.caption}>{caption}</Text> : null}
      <View style={[styles.card, { backgroundColor: color }]}>{children}</View>
    </View>
  );
}

export function Field({
  label,
  value,
  onChange,
  placeholder = "",
  multiline = false,
  accessibilityLabel,
}: {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  multiline?: boolean;
  accessibilityLabel?: string;
}) {
  return (
    <View style={styles.fieldWrap}>
      {label ? <Text style={styles.label}>{label}</Text> : null}
      <TextInput
        accessibilityLabel={accessibilityLabel ?? label ?? placeholder}
        value={value ?? ""}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor="#A39F95"
        multiline={multiline}
        textAlignVertical={multiline ? "top" : "center"}
        selectionColor={C.sage}
        style={[styles.input, multiline && styles.multiline]}
      />
    </View>
  );
}

export function Checks({
  items,
  values,
  onToggle,
  renderReminder,
}: {
  items: readonly string[];
  values: string[];
  onToggle: (value: string) => void;
  renderReminder?: (item: string) => React.ReactNode;
}) {
  return (
    <View>
      {items.map((item) => {
        const checked = values.includes(item);
        return (
          <View key={item} style={{ flexDirection: "row", alignItems: "center", gap: 7 }}>
            <TouchableOpacity
              accessibilityRole="checkbox"
              accessibilityLabel={item}
              accessibilityState={{ checked }}
              onPress={() => onToggle(item)}
              style={[styles.checkRow, { flex: 1 }]}
            >
              <View style={[styles.checkCircle, checked && styles.checkedCircle]}>
                <Text style={styles.checkGlyph}>{checked ? "✓" : ""}</Text>
              </View>
              <Text style={[styles.body, checked && styles.checkedText]}>{item}</Text>
            </TouchableOpacity>
            {renderReminder?.(item)}
          </View>
        );
      })}
    </View>
  );
}

export function TaskRows({
  items,
  onChange,
  label,
  placeholders,
  renderReminder,
}: {
  items: TaskItem[];
  onChange: (items: TaskItem[]) => void;
  label: string;
  placeholders: string[];
  renderReminder?: (item: TaskItem, index: number) => React.ReactNode;
}) {
  return (
    <View>
      {items.map((item, index) => (
        <View key={index} style={styles.taskRow}>
          <TouchableOpacity
            accessibilityRole="checkbox"
            accessibilityLabel={item.text.trim() || `${label} ${index + 1}`}
            accessibilityState={{ checked: item.done }}
            onPress={() => onChange(items.map((task, taskIndex) => taskIndex === index ? { ...task, done: !task.done } : task))}
            style={styles.taskToggle}
          >
            <View style={[styles.checkCircle, item.done && styles.checkedCircle]}>
              <Text style={styles.checkGlyph}>{item.done ? "✓" : ""}</Text>
            </View>
          </TouchableOpacity>
          <TextInput
            accessibilityLabel={`${label} ${index + 1}`}
            value={item.text}
            onChangeText={(text) => onChange(items.map((task, taskIndex) => taskIndex === index ? { ...task, text } : task))}
            placeholder={placeholders[index] ?? `${label} ${index + 1}`}
            placeholderTextColor="#A39F95"
            selectionColor={C.sage}
            style={[styles.taskInput, item.done && styles.taskDone]}
          />
          {renderReminder?.(item, index)}
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.paper },
  pageContent: { paddingHorizontal: 22, paddingTop: 14, paddingBottom: 38, width: "100%", maxWidth: 620, alignSelf: "center" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandMark: { width: 34, height: 34, borderRadius: 10 },
  brandMonogram: { width: 34, height: 34, borderRadius: 12, backgroundColor: C.forest, alignItems: "center", justifyContent: "center" },
  brandMonogramText: { color: "#FFFCF6", fontSize: 7, fontWeight: "900", letterSpacing: 0.2 },
  brand: { color: C.forest, fontSize: 10, letterSpacing: 2.2, fontWeight: "800" },
  kicker: { color: C.sage, fontSize: 9, letterSpacing: 1.45, fontWeight: "700", marginTop: 3 },
  title: { fontFamily: "Georgia", fontSize: 36, lineHeight: 42, color: C.ink, marginTop: 12, letterSpacing: -0.7 },
  subtitle: { color: C.muted, fontSize: 14, lineHeight: 20, marginTop: 2 },
  section: { marginTop: 20 },
  sectionTitle: { fontFamily: "Georgia", fontSize: 19, lineHeight: 24, color: C.ink, marginBottom: 7 },
  caption: { fontSize: 13, lineHeight: 19, color: C.muted, marginTop: -3, marginBottom: 8 },
  card: { borderRadius: 19, borderWidth: 1, borderColor: "#ECE5DA", paddingHorizontal: 16, paddingVertical: 13, boxShadow: "0px 3px 8px rgba(110, 101, 87, 0.04)" },
  fieldWrap: { marginVertical: 4 },
  label: { fontSize: 10, fontWeight: "800", color: C.muted, letterSpacing: 1, marginTop: 5, marginBottom: 1 },
  input: { minHeight: 43, fontSize: 15, color: C.ink, paddingVertical: 9, paddingHorizontal: 1, borderBottomWidth: 1, borderColor: C.line },
  multiline: { minHeight: 82, lineHeight: 22, paddingTop: 10 },
  checkRow: { minHeight: 46, flexDirection: "row", alignItems: "center", gap: 12 },
  checkCircle: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.5, borderColor: "#C8C7B9", alignItems: "center", justifyContent: "center" },
  checkedCircle: { backgroundColor: C.sage, borderColor: C.sage },
  checkGlyph: { color: "white", fontSize: 13, fontWeight: "800", lineHeight: 16 },
  body: { fontSize: 15, lineHeight: 21, color: C.ink },
  checkedText: { color: C.sage },
  taskRow: { minHeight: 48, flexDirection: "row", alignItems: "center", borderBottomWidth: 1, borderColor: "#EEE8DE" },
  taskToggle: { width: 40, minHeight: 46, alignItems: "flex-start", justifyContent: "center", paddingLeft: 1 },
  taskInput: { flex: 1, minHeight: 43, fontSize: 15, color: C.ink, paddingVertical: 9 },
  taskDone: { color: C.muted, textDecorationLine: "line-through" },
  footer: { textAlign: "center", color: C.muted, fontSize: 9, letterSpacing: 1.5, marginTop: 30, marginBottom: 4 },
});
