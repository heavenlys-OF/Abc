import React, { useLayoutEffect, useRef, useState } from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { CalendarReminderAction } from "@/components/life-os/calendar-reminder-action";
import { C } from "@/components/life-os/ui";
import { startOAuthLogin } from "@/constants/oauth";
import { useSubmissionAccount, SubmissionButton } from "@/components/life-os/submission";
import { monthKeyAtOffset } from "@/shared/lifeos";
import type { BrainDumpItem } from "@/lib/life-os/store";
import { suggestedReminderStartDate } from "@/lib/calendar/reminder";
import { trpc } from "@/lib/trpc";

type ArchiveMessage = { owner: string; text: string };
type ActiveRequest = { id: number; owner: string };

export function NoteArchive({ notes, onRemove }: { notes: BrainDumpItem[]; onRemove: (id: string) => void }) {
  const auth = useSubmissionAccount();
  const { loading, checking, error, isAuthenticated, refresh } = auth;
  const accountId = isAuthenticated ? auth.user?.id ?? null : null;
  const accountKey = accountId === null ? "signed-out" : `user:${accountId}`;
  const accountKeyRef = useRef(accountKey);
  useLayoutEffect(() => {
    accountKeyRef.current = accountKey;
  }, [accountKey]);
  const [messages, setMessages] = useState<Record<string, ArchiveMessage>>({});
  const [pendingOwner, setPendingOwner] = useState<string | null>(null);
  const requestCounter = useRef(0);
  const activeRequest = useRef<ActiveRequest | null>(null);
  const recent = trpc.productivity.listMine.useQuery(
    { accountId: accountId ?? -1, type: "brain_dump", limit: 200 },
    { enabled: accountId !== null, retry: false },
  );
  const submit = trpc.productivity.submit.useMutation();
  const submittedKeys = new Set(recent.data?.map((item) => item.recordKey) ?? []);
  const accountBusy = loading || checking;
  const submittingForAccount = pendingOwner === accountKey;

  const setOwnedMessage = (noteId: string, text: string, owner = accountKey) => {
    setMessages((previous) => ({ ...previous, [noteId]: { owner, text } }));
  };

  const submitNote = async (note: BrainDumpItem) => {
    const requestedOwner = accountKey;
    const requestedAccountId = accountId;
    if (!isAuthenticated || requestedAccountId === null) {
      if (error) {
        setOwnedMessage(note.id, "We couldn't verify your account. Retry when connected; the note stays on this device.", requestedOwner);
        void refresh();
        return;
      }
      setOwnedMessage(note.id, "Sign in with Manus to submit this thought to your private archive.", requestedOwner);
      auth.beginSignIn();
      try {
        await startOAuthLogin();
      } catch {
        if (accountKeyRef.current === requestedOwner) {
          setOwnedMessage(note.id, "Sign-in could not open. The note is still saved on this device.", requestedOwner);
        }
      }
      return;
    }

    const parsedDate = new Date(note.createdAt);
    const createdAt = Number.isNaN(parsedDate.getTime()) ? new Date() : parsedDate;
    const timezoneOffsetMinutes = Number.isInteger(note.timezoneOffsetMinutes)
      ? note.timezoneOffsetMinutes
      : createdAt.getTimezoneOffset();
    const periodKey = monthKeyAtOffset(createdAt, timezoneOffsetMinutes);
    const requestId = ++requestCounter.current;
    activeRequest.current = { id: requestId, owner: requestedOwner };
    setPendingOwner(requestedOwner);
    setOwnedMessage(note.id, "", requestedOwner);
    try {
      await submit.mutateAsync({
        type: "brain_dump",
        periodKey,
        recordKey: note.id,
        payload: { text: note.text, createdAt: createdAt.toISOString(), timezoneOffsetMinutes },
      });
      if (accountKeyRef.current !== requestedOwner) return;
      setOwnedMessage(note.id, "Submitted to your Brain-dump archive.", requestedOwner);
      void recent.refetch();
    } catch {
      if (accountKeyRef.current === requestedOwner) {
        setOwnedMessage(note.id, "Couldn't submit. The on-device note is safe; retry when connected.", requestedOwner);
      }
    } finally {
      if (activeRequest.current?.id === requestId) {
        activeRequest.current = null;
        setPendingOwner(null);
      }
    }
  };

  if (!notes.length) {
    return <Text style={{ color: C.muted, fontSize: 14, lineHeight: 22, paddingVertical: 10 }}>This space is quiet for now. Add a thought whenever you need room.</Text>;
  }

  return (
    <View>
      {notes.map((note) => {
        const submitted = accountId !== null && submittedKeys.has(note.id);
        const storedMessage = messages[note.id];
        const message = storedMessage?.owner === accountKey ? storedMessage.text : "";
        const shortNote = note.text.trim().replace(/\s+/g, " ").slice(0, 72);
        return (
          <View key={note.id} style={{ paddingVertical: 13, borderBottomWidth: 1, borderColor: C.line }}>
            <Text style={{ fontSize: 15, color: C.ink, lineHeight: 23 }}>{note.text}</Text>
            <Text style={{ color: C.muted, fontSize: 11, marginTop: 7 }}>{new Date(note.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })} · saved on this device</Text>
            <CalendarReminderAction
              title={`Brain dump: ${shortNote}`}
              notes={`Saved thought:\n${note.text}`}
              defaultStartDate={suggestedReminderStartDate(1)}
              compact
            />
            <View style={{ marginTop: 10 }}>
              <SubmissionButton
                label={loading || checking ? "Checking account…" : error && !isAuthenticated ? "Retry account check" : submittingForAccount ? "Submitting…" : !isAuthenticated ? "Sign in and submit this thought" : submitted ? "Submit update to Brain-dump archive" : "Submit this thought to archive"}
                busy={submittingForAccount || accountBusy}
                disabled={accountBusy}
                onPress={() => void submitNote(note)}
              />
              {message ? <Text accessibilityLiveRegion="polite" style={{ color: message.startsWith("Couldn't") || message.startsWith("We couldn't") || message.startsWith("Sign-in could") ? C.apricot : C.forest, fontSize: 11, lineHeight: 16, marginTop: 6 }}>{message}</Text> : null}
              {submitted ? <Text style={{ color: C.sage, fontSize: 10, marginTop: 5 }}>A copy is in your account archive.</Text> : null}
            </View>
            <TouchableOpacity
              accessibilityRole="button"
              accessibilityLabel="Remove this note from this device"
              onPress={() => onRemove(note.id)}
              style={{ alignSelf: "flex-end", paddingHorizontal: 9, paddingVertical: 7 }}
            >
              <Text style={{ color: C.apricot, fontSize: 12, fontWeight: "700" }}>Remove from this device</Text>
            </TouchableOpacity>
            {submitted ? <Text style={{ color: C.muted, fontSize: 10, textAlign: "right" }}>Removing here won&apos;t delete the account copy.</Text> : null}
          </View>
        );
      })}
    </View>
  );
}
