import { useFocusEffect } from "expo-router";
import React, { useCallback, useLayoutEffect, useRef, useState } from "react";
import { ActivityIndicator, Text, TouchableOpacity, View } from "react-native";
import { C } from "@/components/life-os/ui";
import { startOAuthLogin } from "@/constants/oauth";
import { useAuth } from "@/hooks/use-auth";
import { trpc } from "@/lib/trpc";
import type { SubmitProductivityEntry } from "@/shared/productivity";

const REPOSITORIES: Record<SubmitProductivityEntry["type"], string> = {
  daily: "Daily journal",
  weekly: "Weekly reset archive",
  brain_dump: "Brain-dump archive",
  habit_month: "Monthly habit tracker",
  month_review: "Monthly reflection archive",
};

type OwnedMessage = { owner: string; fingerprint: string; text: string };

type ActiveRequest = { id: number; owner: string };

export function SubmissionButton({
  label,
  busy,
  disabled,
  onPress,
}: {
  label: string;
  busy?: boolean;
  disabled?: boolean;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled: Boolean(disabled), busy: Boolean(busy) }}
      disabled={disabled || busy}
      onPress={onPress}
      style={{ minHeight: 46, borderRadius: 14, paddingHorizontal: 15, paddingVertical: 11, backgroundColor: disabled ? "#AAB5A9" : C.forest, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9 }}
    >
      {busy ? <ActivityIndicator size="small" color="white" /> : null}
      <Text style={{ color: "white", fontSize: 13, fontWeight: "700", textAlign: "center" }}>{label}</Text>
    </TouchableOpacity>
  );
}

export function useSubmissionAccount() {
  const auth = useAuth({ autoFetch: false });
  const refresh = auth.refresh;
  useFocusEffect(useCallback(() => {
    void refresh();
  }, [refresh]));
  return auth;
}

export function EntrySubmissionCard({ entry }: { entry: SubmitProductivityEntry }) {
  const auth = useSubmissionAccount();
  const { loading, checking, error, isAuthenticated, refresh } = auth;
  const accountId = isAuthenticated ? auth.user?.id ?? null : null;
  const accountKey = accountId === null ? "signed-out" : `user:${accountId}`;
  const accountKeyRef = useRef(accountKey);
  const fingerprint = JSON.stringify(entry);
  const currentFingerprint = useRef(fingerprint);
  useLayoutEffect(() => {
    accountKeyRef.current = accountKey;
    currentFingerprint.current = fingerprint;
  }, [accountKey, fingerprint]);
  const [message, setMessage] = useState<OwnedMessage | null>(null);
  const [pendingOwner, setPendingOwner] = useState<string | null>(null);
  const requestCounter = useRef(0);
  const activeRequest = useRef<ActiveRequest | null>(null);
  const saved = trpc.productivity.getOne.useQuery(
    { accountId: accountId ?? -1, type: entry.type, recordKey: entry.recordKey },
    { enabled: accountId !== null, retry: false },
  );
  const submit = trpc.productivity.submit.useMutation();
  const accountBusy = loading || checking;
  const submittingForAccount = pendingOwner === accountKey;
  const messageText = message?.owner === accountKey && message.fingerprint === fingerprint ? message.text : "";
  const repository = REPOSITORIES[entry.type];

  const handlePress = async () => {
    const requestedOwner = accountKey;
    const requestedAccountId = accountId;
    const requestedFingerprint = fingerprint;
    if (!isAuthenticated || requestedAccountId === null) {
      if (error) {
        setMessage({ owner: requestedOwner, fingerprint: requestedFingerprint, text: "We couldn't verify your account. Your local draft is safe; retry when connected." });
        void refresh();
        return;
      }
      setMessage({ owner: requestedOwner, fingerprint: requestedFingerprint, text: "Sign in to submit this entry to your private repository." });
      auth.beginSignIn();
      try {
        await startOAuthLogin();
      } catch {
        if (accountKeyRef.current === requestedOwner) {
          setMessage({ owner: requestedOwner, fingerprint: currentFingerprint.current, text: "Sign-in could not open. Your local draft is still safe; try again." });
        }
      }
      return;
    }

    const requestId = ++requestCounter.current;
    activeRequest.current = { id: requestId, owner: requestedOwner };
    setPendingOwner(requestedOwner);
    setMessage({ owner: requestedOwner, fingerprint: requestedFingerprint, text: "" });
    try {
      const result = await submit.mutateAsync(entry);
      if (accountKeyRef.current !== requestedOwner) return;
      const changedWhileSubmitting = requestedFingerprint !== currentFingerprint.current;
      setMessage({
        owner: requestedOwner,
        fingerprint: currentFingerprint.current,
        text: changedWhileSubmitting
          ? `An earlier version was submitted to ${repository}. Submit again to update it.`
          : `Submitted to ${repository} · ${new Date(result.updatedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`,
      });
      void saved.refetch();
    } catch {
      if (accountKeyRef.current === requestedOwner) {
        setMessage({ owner: requestedOwner, fingerprint: currentFingerprint.current, text: "Couldn't submit just now. Your local draft is safe; check your connection and retry." });
      }
    } finally {
      if (activeRequest.current?.id === requestId) {
        activeRequest.current = null;
        setPendingOwner(null);
      }
    }
  };

  return (
    <View style={{ marginTop: 22, padding: 15, borderRadius: 18, backgroundColor: C.wash, borderWidth: 1, borderColor: "#DCE4D9" }}>
      <Text style={{ color: C.sage, fontSize: 9, fontWeight: "800", letterSpacing: 1.2 }}>YOUR PRIVATE REPOSITORY</Text>
      <Text style={{ color: C.ink, fontFamily: "Georgia", fontSize: 18, marginTop: 4 }}>{repository}</Text>
      <Text style={{ color: C.muted, fontSize: 12, lineHeight: 18, marginTop: 4, marginBottom: 12 }}>
        {error && !isAuthenticated
          ? "We couldn't verify the current account. Your local draft stays on this device; retry the account check when connected."
          : isAuthenticated
            ? saved.data
              ? "A record for this period is already here. Submit again to update it."
              : "Your edits stay on this device until you choose to submit."
            : "Sign in with Manus to submit this entry securely to your account."}
      </Text>
      <SubmissionButton
        label={accountBusy ? "Checking account…" : error && !isAuthenticated ? "Retry account check" : submittingForAccount ? "Submitting…" : saved.data ? "Submit update" : isAuthenticated ? `Submit to ${repository}` : "Sign in and submit"}
        busy={submittingForAccount || accountBusy}
        disabled={accountBusy}
        onPress={() => void handlePress()}
      />
      {messageText ? <Text accessibilityLiveRegion="polite" style={{ color: messageText.startsWith("Couldn't") || messageText.startsWith("We couldn't") || messageText.startsWith("Sign-in could") ? C.apricot : C.forest, fontSize: 12, lineHeight: 18, marginTop: 9 }}>{messageText}</Text> : null}
    </View>
  );
}
