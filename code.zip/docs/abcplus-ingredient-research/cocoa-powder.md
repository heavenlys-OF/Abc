# Cocoa powder

## Identity

The supplied ingredient name is cocoa powder. The Norwegian Food Composition Table provides a generic “Cocoa powder” entry; it does not identify the cocoa powder used in ABC+ or its processing details.

## Nutrient context

A national food-composition database entry describes cocoa powder as containing protein, fat, carbohydrate and dietary fibre; its generic entry also lists total sugar as zero. This is general ingredient-level reference information, not a measurement of the ABC+ formula. [1]

## Cautious customer-facing copy

“Cocoa powder is an ingredient that contains dietary fibre, protein, fat and carbohydrate.”

## Product claim limit

A powder-specific amount or effect in ABC+ cannot be inferred without the final formula and serving composition. This ingredient-level context does not establish that ABC+ prevents, treats or reduces the risk of any health condition, or delivers a health outcome.

## References

[1]: https://www.matvaretabellen.no/en/cocoa-powder/ "Matvaretabellen: Cocoa powder"
