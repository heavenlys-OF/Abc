## Samai flakes

“Samai” is listed as little millet (*Panicum miliare*) in India’s National Institute of Nutrition food composition tables. Those tables describe raw foods; their Samai entry is not a flakes or finished-product analysis. [1] A peer-reviewed study specifically examined ready-to-cook little-millet flakes and reports dietary fibre as well as carbohydrate and protein in the studied flakes. Its findings concern that study product and process, not every product called samai flakes. [2]

**Customer-facing context:** Samai (little millet) flakes are a cereal ingredient. Published analyses of little millet and of a particular ready-to-cook little-millet flake product report nutrients including carbohydrate, protein and dietary fibre; values can vary with the ingredient and processing. These general ingredient facts do not establish a health outcome for ABC+.

**Product claim limit:** A powder/flakes-specific amount and effect in ABC+ cannot be inferred without the final formula and serving composition. No amount, proportion, species beyond the documented samai/little-millet identity, or ABC+ nutrient contribution is established here.

### References

[1]: https://www.nin.res.in/ebooks/IFCT2017.pdf "Indian Food Composition Tables 2017"
[2]: https://pmc.ncbi.nlm.nih.gov/articles/PMC4554602/ "Glycemic index and quality evaluation of little millet (Panicum miliare) flakes with enhanced shelf life"
