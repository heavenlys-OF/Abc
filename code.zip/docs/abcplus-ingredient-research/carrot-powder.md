# Carrot powder

Carrot powder is dried carrot, but its composition depends on the starting carrot and processing. A peer-reviewed study of its own whole-carrot powders reported dietary fibre and naturally occurring sugars, and measured β-carotene; the authors also note variation with season, agronomic conditions, variety, storage, and processing. Those study results describe the powders tested, not every commercial carrot powder. [1]

The USDA FoodData Central carrot search page lists raw and frozen carrot entries, not a powder entry among the results shown. Fresh-carrot data therefore should not be represented as a nutrient amount for carrot powder. [2]

**Customer-facing copy:** Carrot powder is made from dried carrot. Its nutrient composition can vary with the carrots and processing used.

**Product-claim limit:** A powder-specific amount or any effect in ABC+ cannot be inferred without the final formula and serving composition. No ABC+ health outcome is claimed.

## References

[1]: https://pmc.ncbi.nlm.nih.gov/articles/PMC8535146/ "Nutrient-Dense Shelf-Stable Vegetable Powders and Their Use in Food Products"
[2]: https://fdc.nal.usda.gov/food-search?query=carrot "USDA FoodData Central Food Search: carrot"
