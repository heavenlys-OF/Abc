# ABC+ formulation — current research index

> The contents of the earlier ingredient summary are superseded by the latest user-confirmed formulation. Do not use the old peanut/sesame roster, ingredient weights, 50 g nutrition values, or serving copy.

The current 12-ingredient batch, normalized per-100-g and per-50-g formula amounts, user-supplied nutrition panel, preparation directions, ingredient-level source links and cautious physiology notes are in [updated-summary.md](./updated-summary.md).

The current formula excludes peanuts and sesame. It totals 47.57 kg from the provided line items, and the customer serving is one 50 g sachet. The corrected artwork shows a 7 × 50 g pack. The latest nutrition panel includes 0.53 g added sugar from palm sugar per 50 g serving; the app does not describe the product as having no added sugar.

The supporting review of the previously supplied engineering PDF and the mechanism copy appropriate to the current recipe are in [engineering-mechanism.md](./engineering-mechanism.md). FSSAI claim wording is discussed in [label-claims.md](./label-claims.md). Ingredient and nutrient references provide general context only; they are not ABC+-specific laboratory or clinical validation.