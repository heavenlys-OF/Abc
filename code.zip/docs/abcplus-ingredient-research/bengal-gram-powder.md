Bengal gram powder is understood here as flour made from Bengal gram/chickpea (*Cicer arietinum*). The ICMR–NIN Indian Food Composition Tables identify Bengal gram dal and whole Bengal gram as *Cicer arietinum* and publish nutrient data for those forms, but do not provide a directly matching powder entry in the cited table excerpt. Chickpea flour literature describes it as containing protein and carbohydrate; values vary with chickpea type, growing conditions, and analytical methods, so those data should not be treated as the composition of this ABC+ product. [1] [2]

**Customer-facing wording:** “Bengal gram (chickpea) powder is a pulse-derived ingredient. Chickpea flour can contribute protein and carbohydrate, but the amount in this product depends on its final recipe and serving.” [2]

A powder-specific amount or effect in ABC+ cannot be inferred without the final formula and serving composition. This ingredient-level note does not establish any health outcome for ABC+.

**References**
[1]: https://www.nin.res.in/ebooks/IFCT2017.pdf "Indian Food Composition Tables 2017"
[2]: https://pmc.ncbi.nlm.nih.gov/articles/PMC10580981/ "Nutritional composition, health benefits and bio-active compounds of chickpea: a review"