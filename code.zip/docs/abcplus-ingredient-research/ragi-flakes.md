Ragi is identified as finger millet (*Eleusine coracana*) in India’s official food-composition tables. Those tables describe raw ragi grain as containing carbohydrate, dietary fibre, protein and minerals; FAO likewise describes finger millet as a source of dietary fibre and protein and notes several minerals. These are general grain-level observations, not measurements of flakes or of ABC+.[1] [2]

**Customer-facing note:** Ragi (finger millet) is a millet grain that contributes carbohydrate, dietary fibre, protein and minerals. The nutrient amount in ragi flakes, and their contribution in ABC+, cannot be inferred without the final formula and serving composition.

**References**
[1]: https://www.nin.res.in/ebooks/IFCT2017_16122024.pdf "Indian Food Composition Tables 2017"
[2]: https://www.fao.org/millets-2023/about/en "International Year of Millets 2023: About"