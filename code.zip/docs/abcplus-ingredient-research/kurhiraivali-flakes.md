# Kurhiraivali flakes — ingredient note

## Identity

The supplied name “kurhiraivali flakes” could not be reliably matched to an authoritative food-composition entry. FSSAI’s millet guidance lists barnyard millet and gives “Kuthiraivolly” as a Tamil name, but that does not establish that the supplied spelling “kurhiraivali” identifies the same ingredient. Do not assign a species or use barnyard-millet nutrient values for this ingredient until its identity is confirmed from the supplier or product specification. [1]

## Nutrient context

No nutrient profile specific to “kurhiraivali flakes” can be substantiated from the sources reviewed. FSSAI gives general nutrient context for millets and a comparative grain chart, but those are not specific to this supplied-name flakes ingredient. A peer-reviewed review describes barnyard millet grain as containing carbohydrate and dietary fibre, among other nutrients, but this information applies to barnyard millet grain as identified in that source—not to an unconfirmed name or processed flakes. [1] [2]

## Customer-facing wording

“Kurhiraivali flakes are listed as an ingredient. The ingredient identity and a flakes-specific nutrient profile have not yet been confirmed.”

## Product claim limit

A powder/flakes-specific amount and effect in ABC+ cannot be inferred without the final formula and serving composition. No ABC+ health outcome or nutrient contribution should be claimed from the ingredient name alone.

## References

[1]: https://www.fssai.gov.in/upload/uploadfiles/files/Guidance_Notes_Version_2_Millets_29_01_2020.pdf "FSSAI Guidance Note: Millets - The Nutri-cereals"
[2]: https://pmc.ncbi.nlm.nih.gov/articles/PMC10497464/ "Nutritional advantages of barnyard millet and opportunities for its processing as value added foods—a review"
