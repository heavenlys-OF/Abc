# Roasted peanuts

**Confirmed identity and form:** Roasted peanuts (groundnuts; *Arachis hypogaea*). USDA FoodData Central identifies an exact matching food-composition entry as “Peanuts, all types, dry-roasted, without salt” (FDC ID 173806), with nutrient information per 100 g available from the food record. This confirms a dry-roasted, unsalted food-level reference, not this blend’s formulation or lab analysis. [1]

**Safe customer copy (general ingredient context):** Peanuts provide plant protein, fat and dietary fibre as a food. Peanuts are a major food allergen; people with peanut allergy should avoid them. [2] [3]

**Blend amount supplied by user:** 6 g per 100 g blend, or 3 g per 50 g sachet. These are formulation amounts, not measured nutrient amounts. Do not use the food-level composition reference to state this blend’s nutrient content or a health outcome.

## References

[1]: https://fdc.nal.usda.gov/food-details/173806/nutrients "USDA FoodData Central: Peanuts, all types, dry-roasted, without salt"
[2]: https://pmc.ncbi.nlm.nih.gov/articles/PMC4711439/ "Peanuts as functional food: a review"
[3]: https://www.fda.gov/food/nutrition-food-labeling-and-critical-foods/food-allergies "Food Allergies"
