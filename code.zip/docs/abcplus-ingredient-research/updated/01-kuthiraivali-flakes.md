# Kuthiraivali flakes — ingredient research

**Identity:** High confidence that “Kuthiraivali” (also spelled Kudiraivali/Kudiraivalli) refers to barnyard millet. Tamil Nadu Agricultural University labels “KUDIRAIVALI” as barnyard millet (*Echinochloa frumentacea*) and describes its grain as a food [1]. A peer-reviewed review likewise concerns barnyard millet grain and summarizes its general composition [2].

**Form and amount:** The sources confirm the grain identity, not the specific processed form “flakes.” The supplied formulation amount is 4.5 g per 100 g blend (2.25 g per 50 g sachet); neither amount is a laboratory-measured nutrient value. Do not infer the composition of this product’s flakes from whole-grain literature.

**Cautious customer copy:** “Kuthiraivali is barnyard millet, a traditional grain. Barnyard millet grain generally provides carbohydrate and dietary fibre, along with protein; the nutrition of this product depends on its processing and full blend.” [1] [2]

**Sources**

[1] Tamil Nadu Agricultural University, “KUDIRAIVALI (Barnyard Millet) *Echinochloa frumentacea*.” Supports the common-name identity and that the described food is grain; does not establish flakes. http://www.agritech.tnau.ac.in/agriculture/millets_kudiraivali.html

[2] Bhatt et al., “Nutritional advantages of barnyard millet and opportunities for its processing as a value-added food product,” *Journal of Food Science and Technology* (2023; online 2022). Supports general barnyard-millet grain nutrient context; its cited values vary by study/sample and are not values for this product or its flakes. https://pmc.ncbi.nlm.nih.gov/articles/PMC10497464/

**Limitations:** No authoritative source reviewed here verified a particular flaking process, or nutrient values for Kuthiraivali flakes as used in this blend. Avoid numerical nutrient, health-outcome, or product-specific nutrition claims based on these sources.