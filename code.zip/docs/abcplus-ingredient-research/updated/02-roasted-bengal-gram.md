# Roasted Bengal gram

**Specified amount:** 9 g per 100 g blend; 4.5 g per 50 g sachet (user-specified). These are recipe quantities, not nutrient measurements.

**Identity and form:** The supplied ingredient name is Roasted Bengal gram, commonly referring to roasted chickpea/gram. The requested form is whole roasted gram, not gram flour (besan or sattu). The consulted sources do not independently confirm the actual product's variety, whether it is whole or split, or whether the skin is retained. The Indian Food Composition Tables identify Bengal gram as *Cicer arietinum*, but list whole and dal entries as separate foods and explain that their analyzed values generally concern raw foods; they do not provide a directly matching whole roasted entry in the inspected material. [1]

**Cautious customer copy:** “Roasted Bengal gram is a chickpea-based legume ingredient. Chickpeas are naturally a source of plant protein and dietary fibre; the amount in this blend has not been measured from the ingredient name or its inclusion level alone.” [1] [2]

Do not use nutrient values for chickpea flour as values for whole roasted gram. A peer-reviewed study discusses chickpeas eaten roasted or milled and specifically analyzes flours made from roasted chickpeas, demonstrating that roasted flour is a distinct processed form. [2]

**References**
[1]: https://www.nin.res.in/ebooks/IFCT2017.pdf "Indian Food Composition Tables 2017"
[2]: https://pmc.ncbi.nlm.nih.gov/articles/PMC8774402/ "Impact of Raw, Roasted and Dehulled Chickpea Flours on the Technological and Nutritional Quality of Gluten-Free Bread"
