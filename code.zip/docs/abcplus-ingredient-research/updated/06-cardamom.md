# Cardamom

**Identity and form.** Cardamom here is confirmed at the ingredient-name level as the culinary spice cardamom (Hindi: elaichi); the exact species/color and whether it is pod, seed, or ground powder are not specified in the provided ingredient entry. Green cardamom (*Elettaria cardamomum*) is the “true” cardamom; black cardamom is a distinct species. It is used in sweet and savory foods in India, and recipes may use pods, seeds, or seed powder. [1]

**Customer-facing copy (cautious):** “Cardamom is an aromatic culinary spice used to add flavor to foods and drinks. This blend contains 2 g per 100 g (1 g in a 50 g sachet); no product-specific nutrient amount or health outcome is established by that ingredient amount alone.” [1]

**Amount and evidence limits.** The stated amounts are user-provided, not independently tested: 2 g/100 g blend equals 1 g/50 g sachet. USDA FoodData Central is a source for food nutrient data, but the exact cardamom entry could not be read in this check; therefore no nutrient values are attributed to this ingredient or product. Species, color, and physical form remain unspecified; do not imply green cardamom, ground cardamom, a measured nutrient amount, or a health benefit.

## References

[1]: https://www.mccormickscienceinstitute.com/resources/culinary-spices/herbs-spices/cardamom "Cardamom"
[2]: https://fdc.nal.usda.gov/food-search "Food Search | USDA FoodData Central"
