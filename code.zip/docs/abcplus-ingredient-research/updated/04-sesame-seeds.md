# Sesame seeds — ingredient research

## Identity and customer copy

**Confirmed identity:** Sesame seeds (*Sesamum indicum*), whole seed form (not sesame powder). USDA FoodData Central distinguishes “Seeds, sesame seeds, whole, dried” (FDC 170150) from sesame kernels, paste, and flours. The requested formulation amount is 1.5 g per 100 g blend and 0.75 g per 50 g sachet; these are user-specified inclusion weights, not measured nutrient amounts for the finished blend.

**Safe customer copy (general nutrition):** Whole sesame seeds are a seed ingredient that contains fats, protein, and dietary fiber, along with minerals. Sesame is a major food allergen; people with sesame allergy should avoid it.

## Key facts and caveats

- USDA SR Legacy food search lists “Seeds, sesame seeds, whole, dried,” NDB 12023 / FDC ID 170150, separately from decorticated kernels, toasted seeds, sesame butter, and sesame flour. This supports the identity and form distinction; it is a historical composition record and not a laboratory analysis of this product.[1]
- FDA identifies sesame as the ninth major food allergen under the FASTER Act and says packaged foods containing sesame must declare sesame as an allergen as of January 1, 2023.[2]
- No product-specific nutrient quantity or health outcome is claimed. The requested ingredient weight does not establish the finished blend’s nutrient values. Sesame allergy is a material safety fact, not a nutrition claim.

## References

[1]: https://fdc.nal.usda.gov/food-search?type=SR%20Legacy&query=sesame%20seed "USDA FoodData Central Food Search — sesame seed records"
[2]: https://www.fda.gov/food/food-allergies/faster-act-sesame-ninth-major-food-allergen "The FASTER Act: Sesame Is the Ninth Major Food Allergen"
