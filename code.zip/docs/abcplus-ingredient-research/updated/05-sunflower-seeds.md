# Sunflower seeds

**Confirmed identity and form:** The Indian National Institute of Nutrition’s Indian Food Composition Tables (IFCT) identify sunflower seeds as *Helianthus annuus*. USDA FoodData Central lists both “Seeds, sunflower seed, kernel, raw” and a separate dry-roasted, salted kernel entry. The ingredient description supplied here does not specify whether the seeds are hulled, roasted, or salted, so those details cannot be confirmed. [1] [2]

**Safe customer copy:** Sunflower seeds are a source of plant protein and contain fat and dietary fibre. Their composition varies with the specific form and preparation, and this general ingredient context is not a measurement of the sunflower seeds or nutrients in this blend. [1]

**Reference context:** IFCT Table 1 reports, for its sunflower-seed entry per 100 g, protein 23.53 g, total fat 51.85 g, dietary fibre 10.80 g, and energy 2453 kJ; these are reference food-composition values, not values for this blend or its 1.5 g/100 g inclusion. [1] USDA’s search record independently confirms the distinction between raw kernels and dry-roasted salted kernels. [2]

## References

[1]: https://www.nin.res.in/ebooks/IFCT2017_16122024.pdf "Indian Food Composition Tables 2017"
[2]: https://fdc.nal.usda.gov/food-search?query=sunflower%20seeds "USDA FoodData Central Food Search: sunflower seeds"
