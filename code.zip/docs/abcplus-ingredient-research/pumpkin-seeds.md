# Pumpkin seeds

## Identity and nutrient context

“Pumpkin seeds” identifies the general ingredient, but does not establish a specific cultivar, preparation, or processing state. USDA FoodData Central lists “Seeds, pumpkin seeds (pepitas), raw” as a Foundation Food record. Its Foundation Foods data are based on analyses of individual samples, with information about sample variability; a food database entry is a reference for that food, not a measurement of ABC+.[1] A peer-reviewed review describes pumpkin seeds as containing protein, lipids, dietary fiber, and minerals, while its compiled values refer to a particular cited food reference and serving basis rather than this product.[2]

## Cautious customer-facing copy

Pumpkin seeds are a food ingredient that contains protein, fats, fiber, and minerals. The nutrient profile of a finished product depends on its recipe and serving size.[1][2]

## Product-claim limit

These sources support general ingredient-level context only. They do not establish the amount or nutrient contribution of pumpkin seeds in ABC+, or any health effect from consuming ABC+. A powder- or flakes-specific amount and effect in ABC+ cannot be inferred without the final formula and serving composition.

## References

[1]: https://fdc.nal.usda.gov/food-search?query=pumpkin%20seeds "USDA FoodData Central Food Search: Seeds, pumpkin seeds (pepitas), raw"
[2]: https://pmc.ncbi.nlm.nih.gov/articles/PMC9182978/ "Nutritional Value, Phytochemical Potential, and Therapeutic Benefits of Pumpkin"
