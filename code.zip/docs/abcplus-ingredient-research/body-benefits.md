# ABC+ nutrient roles and customer wording — current formula

The current user-supplied panel is per 50 g sachet: protein 8.5 g, total fat 5.1 g, MUFA + PUFA 4.0 g, dietary fibre 4.8 g, iron 3.2 mg, calcium 82 mg, magnesium 96 mg, phosphorus 208 mg, zinc 1.9 mg, vitamin A 410 μg, vitamin E 3.8 mg, thiamine (B1) 0.31 mg, niacin (B3) 3.4 mg, vitamin B6 0.28 mg, and folate 54 μg. These figures are approximate brand inputs, not independent analysis of the finished blend.

## General physiology suitable for the app

Grains, millets and Bengal gram supply carbohydrate, including starch. MedlinePlus explains that most starch is digested into glucose that the body can use for energy. Actual glucose response depends on the complete recipe, processing, serving and meal; the app does not claim a measured glycaemic response for ABC+. [1]

Fibre is not digested like starch. Fibre-rich foods plus adequate liquids can support normal bowel habits. This is not evidence that ABC+ treats constipation or produces a specific digestive outcome. [2]

Dietary protein is digested into amino acids that the body uses to maintain and repair cells. This does not establish muscle gain or faster recovery from one serving. [3]

Dietary fats provide energy and help the body absorb some vitamins. The app shows the brand-supplied fat figures but does not imply a heart-protection result or independently analyse the fat profile. [4] [5]

## Body-role notes

- **Energy metabolism:** B1, B3 and B6 participate in normal cellular processes that release or use energy from food. Their presence does not promise an instant energy boost or better focus.
- **Oxygen transport:** iron is needed to make haemoglobin, which carries oxygen from the lungs to tissues. The serving does not diagnose or treat deficiency.
- **Bones, muscles and nerves:** calcium, magnesium and phosphorus participate in normal bone structure and related muscle, nerve and cellular functions. A food is not a substitute for varied dietary intake or medical care.
- **Skin and tissue:** vitamin A supports normal cell differentiation; zinc is involved in protein synthesis and cell division; vitamin E has antioxidant functions. These roles do not establish improved appearance, wound healing or treatment of a skin condition.
- **Hair:** no hair-growth or hair-loss result is established by the supplied panel. Biotin is not listed, and evidence that biotin improves hair in people without deficiency is limited.
- **Immune function:** vitamin A and zinc are involved in normal immune function; this does not mean the product prevents infection.

## Approximate food comparisons

The product artwork compares the supplied per-sachet amounts approximately with everyday foods: protein with eggs, fibre with oats, iron with spinach, calcium with milk, magnesium with almonds, potassium with a banana, vitamin A with a carrot, folate with cooked greens, and vitamin E with sunflower seeds. The app labels these as brand-provided scale illustrations only. They are not interchangeable foods, equal full-meal nutrition or proof of health benefit.

FSSAI’s advertising and claims rules require truthfulness and scientific substantiation for nutrient-function and health claims. A known nutrient role alone does not prove a specific effect of ABC+. The app avoids guaranteed cosmetic, satiety, glycaemic, focus, disease-prevention or treatment results. [6]

## References

[1]: https://medlineplus.gov/ency/article/002469.htm "MedlinePlus Carbohydrates"
[2]: https://www.niddk.nih.gov/health-information/digestive-diseases/constipation/eating-diet-nutrition "NIDDK Fibre and Digestion"
[3]: https://medlineplus.gov/ency/article/002467.htm "MedlinePlus Protein in Diet"
[4]: https://medlineplus.gov/dietaryfats.html "MedlinePlus Dietary Fats"
[5]: https://nigms.nih.gov/biobeat/2024/01/what-do-fats-do-in-the-body "NIH NIGMS What Do Fats Do in the Body"
[6]: https://fssai.gov.in/docs/food-law/regulations/Compendium_Advertising_Claims_Regulations_14_12_2022.pdf "FSSAI Advertising and Claims Regulations Version IV"

Micronutrient sources are detailed in [the formulation evidence summary](./updated-summary.md).