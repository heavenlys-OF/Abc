# Peanut powder

Peanut powder is a peanut-derived ingredient. Peanut flours and oilcake flours studied in food research contain protein, oil/fat, carbohydrates, and mineral components; measured composition varies with processing, including roasting and oil removal. Those findings describe the tested flour types, not the specific peanut powder used in ABC+.[1] USDA FoodData Central lists analyzed peanut foods such as raw peanuts and peanut butter, but the searched Foundation Foods results do not identify a peanut powder entry.[2]

**Customer-facing copy:** Peanut powder is a peanut-derived ingredient. Its nutrient profile depends on how it is made and used.

A powder-specific amount or effect in ABC+ cannot be inferred without the final formula and serving composition. The ingredient name alone does not establish the powder’s processing method or nutrient values, and no ABC+ health outcome should be inferred from general peanut or peanut-flour composition.

## References

[1]: https://pmc.ncbi.nlm.nih.gov/articles/PMC11406330/ "Peanut Arachis hypogaea L. flour and oilcake flour: nutritional composition and related properties"
[2]: https://fdc.nal.usda.gov/food-search?query=peanut&type=Foundation "USDA FoodData Central Food Search: peanut Foundation Foods"