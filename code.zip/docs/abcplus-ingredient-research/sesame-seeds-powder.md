# Sesame seeds powder — ingredient note

Sesame seeds are generally described as containing fat, protein, dietary fibre, and minerals. The Indian Food Composition Tables include sesame among foods analyzed in their food-composition tables, while a peer-reviewed review summarizes sesame-seed composition and identifies nutrients including protein, fat, fibre, calcium, iron, and other minerals.[1][2] These sources describe sesame seeds generally; they do not establish the nutrient amount in this powder or in ABC+.

**Customer-facing copy:** Sesame seeds powder is a sesame-derived ingredient. Sesame seeds contain protein, fat, fibre, and minerals; the amount present in this product cannot be determined from the ingredient name alone.[1][2]

**Limit:** A powder-specific amount and any effect in ABC+ cannot be inferred without the final formula and serving composition. Do not use the whole-seed composition as a quantified claim for this powder or finished product.

## References

[1]: https://www.nin.res.in/ebooks/IFCT2017.pdf "Indian Food Composition Tables 2017"
[2]: https://pmc.ncbi.nlm.nih.gov/articles/PMC9573514/ "Sesame (Sesamum indicum L.): A Comprehensive Review of Nutritional Composition, Phytochemical, and Health Benefits"
