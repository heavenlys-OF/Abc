# Apple powder

**Ingredient:** Apple powder (supplied ingredient name; exact processing and composition are unspecified).

**General nutrient context:** Whole apples are described as sources of soluble and insoluble fiber and vitamin C, and contain carbohydrate, including naturally occurring sugars. Harvard’s Nutrition Source notes that drying apples removes vitamin C; dried-apple products can also have sugar added. The USDA FoodData Central search provides records for several raw apple varieties, but the opened results do not establish a matching apple-powder entry or powder nutrient profile. [1] [2]

**Customer-facing copy:** Apple is a fruit ingredient. Whole-apple references describe apples as containing fiber and naturally occurring sugars; drying may change nutrient content, and some dried-apple products have added sugar. [1] These general facts do not establish the composition of this powder or ABC+.

**Product claim limit:** A powder/flakes-specific amount and effect in ABC+ cannot be inferred without the final formula and serving composition. No amount, proportion, nutrient contribution, or health outcome claim for ABC+ is supported by these sources.

## References
[1]: https://nutritionsource.hsph.harvard.edu/food-features/apples/ "Apples - The Nutrition Source"
[2]: https://fdc.nal.usda.gov/food-search?query=apples "USDA FoodData Central Food Search"
