# ABC+ nutrition and claim wording notes — current formula

The latest user-supplied nutrition panel for a 50 g sachet lists 9.6 g naturally occurring sugars and **0.53 g added sugar from palm sugar**. The current app reflects those supplied values instead of the superseded 0 g added-sugars entry. The recipe also contains about 0.53 g palm-sugar ingredient by normalized formula weight; this ingredient mass is not itself an independent sugar assay. The final package declaration should follow the applicable regulation and verified product data. [1]

The approved positioning “made with palm sugar; no refined sugar” is different from a “no added sugars” claim. Since palm sugar is included, do not say or imply that ABC+ has no added sugar. [2]

The latest hero’s “plant protein,” “high fibre,” “vitamins & minerals,” and “no artificial flavours or sweeteners” are user-supplied product claims. The app displays the associated approximate brand-supplied nutrient values where available and does not imply independent laboratory verification. Product-specific outcomes such as slow-release glucose response, staying full longer, improved focus, gut-health results, immunity, skin improvement or hair growth are not established by generic nutrient references; avoid outcome promises unless the brand supplies appropriate substantiation. [2]

The current app’s mechanism copy is educational: it describes general starch digestion, fibre, protein and normal nutrient functions, not a clinical trial of ABC+. This distinction is especially important because the engineering PDF describes older ingredients and process steps (including sprouted ragi and amla) that are not in the current recipe. See [engineering-mechanism.md](./engineering-mechanism.md).

## References

[1]: https://fssai.gov.in/docs/food-law/regulations/Comp_Labelling%20Display_Version%20VIII_09_09_2025.pdf "Food Safety and Standards Labelling and Display Regulations, Version VIII"
[2]: https://fssai.gov.in/docs/food-law/regulations/Compendium_Advertising_Claims_Regulations_14_12_2022.pdf "Food Safety and Standards Advertising and Claims Regulations, Version IV"