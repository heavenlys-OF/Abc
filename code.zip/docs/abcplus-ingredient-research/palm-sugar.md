# Palm sugar

Palm sugar is a sweetener made from palm sap. A peer-reviewed review describes sucrose as the largest sugar component in palm sap, with glucose and fructose also present, and reports that composition varies by palm type/species, region, and climate. These broad findings do not establish the composition of a specific palm-sugar powder or flakes ingredient. [1]

Palm sugar is a sugar-containing carbohydrate sweetener; it should not be presented as healthier than other sugars. The World Health Organization's sugars guideline addresses intake of free sugars generally, not a special health benefit of palm sugar. [2]

**Customer-facing note:** “Palm sugar is a sweetener made from palm sap and contains sugars. Its composition can vary.”

**Product limit:** A powder/flakes-specific amount and effect in ABC+ cannot be inferred without the final formula and serving composition. No quantity or nutrient contribution for ABC+ is established here; do not imply that ABC+ prevents, treats, or reduces the risk of a health outcome.

## References

[1]: https://pmc.ncbi.nlm.nih.gov/articles/PMC10073893/ "Palm sap sugar an unconventional source of sugar exploration for bioactive compounds and its role on functional food development"
[2]: https://www.who.int/publications/i/item/9789241549028 "Guideline: sugars intake for adults and children"
