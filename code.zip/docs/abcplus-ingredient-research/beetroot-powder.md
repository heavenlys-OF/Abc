Beetroot (beet) is the edible root of *Beta vulgaris*. Peer-reviewed reviews describe beetroot as containing ordinary food nutrients, including carbohydrate and dietary fibre, as well as naturally occurring nitrate and betalain pigments; betalains contribute its red-violet and yellow-orange pigments. These are general descriptions of beetroot, not a nutrient specification for every beetroot powder. [1] [2]

**Customer-facing note:** Beetroot powder is made from beetroot and may contribute beetroot’s characteristic colour and naturally occurring compounds. Its nutrient content depends on the powder and processing; no specific nutrient amount is stated here.

A powder- or flakes-specific amount, and any effect or nutrient contribution in ABC+, cannot be inferred without the final formula and serving composition. This ingredient note does not establish a health outcome for ABC+.

**References**

[1]: https://pmc.ncbi.nlm.nih.gov/articles/PMC8565237/ "A review of the latest research on the biological activities of nutritional composition in beetroot"
[2]: https://pmc.ncbi.nlm.nih.gov/articles/PMC8229785/ "Current Knowledge on Beetroot Bioactive Compounds: A Systematic Review"
