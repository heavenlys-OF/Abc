# Heavenly’s ABC+ — current formulation and evidence summary

## Current product inputs

This summary supersedes the earlier 13- and 14-ingredient versions. The latest user-confirmed batch line items total 47.57 kg; the customer sachet is 50 g. The corrected hero artwork shows seven 50 g sachets, 350 g total. The current recipe excludes peanuts and sesame.

The app uses the supplied product image unchanged. Preparation is one 50 g sachet with 200 ml warm water or warm/cold milk; stir or shake, ready in about three minutes.

## Ingredient formula

Per-100-g and per-50-g amounts below are formula weights normalized from the line-item batch, not nutrient amounts. Display figures are rounded independently to two decimals.

| Ingredient | Batch weight | Per 100 g blend | Per 50 g sachet |
|---|---:|---:|---:|
| Apple powder | 3.00 kg | 6.31 g | 3.15 g |
| Beetroot powder | 3.00 kg | 6.31 g | 3.15 g |
| Carrot powder | 3.00 kg | 6.31 g | 3.15 g |
| Bengal gram | 17.00 kg | 35.74 g | 17.87 g |
| Oats | 8.00 kg | 16.82 g | 8.41 g |
| Ragi flakes | 5.00 kg | 10.51 g | 5.26 g |
| Samai flakes | 1.50 kg | 3.15 g | 1.58 g |
| Kuthiraivali flakes | 1.50 kg | 3.15 g | 1.58 g |
| Sunflower seeds | 3.00 kg | 6.31 g | 3.15 g |
| Cocoa powder | 2.00 kg | 4.20 g | 2.10 g |
| Palm sugar | 0.50 kg | 1.05 g | 0.53 g |
| Cardamom powder | 0.07 kg | 0.15 g | 0.07 g |
| **Total, rounded** | **47.57 kg** | **100.01 g*** | **50.00 g** |

*The per-100-g display rows may sum to 100.01 g because each is independently rounded; calculations use the unrounded 47.57 kg total. Category shares are fruit/root powders 18.92%, grains/millets 33.63%, pulses 35.74%, seeds 6.31%, and natural flavour/sweetener 5.40%.

## Ingredient context

These sources describe general foods or raw ingredients. They do not establish the exact nutrient content, bioavailability or health effect of the finished ABC+ serving.

- **Apple powder:** apples generally provide fibre and naturally occurring sugars; drying can change nutrient content. [1] [2]
- **Beetroot powder:** beetroot generally contains carbohydrate, fibre, naturally occurring nitrate and betalain pigments. [3] [4]
- **Carrot powder:** a study of carrot powders reports fibre and beta-carotene, with values varying by cultivar and processing. [5] [6]
- **Bengal gram:** chickpea references describe plant protein, carbohydrate and fibre; they do not establish the processing or precise composition of this ingredient. [7] [8]
- **Oats:** oats generally contain fibre including beta-glucan, along with thiamine, phosphorus, magnesium and zinc. [9] [10]
- **Ragi flakes:** ragi is finger millet. General grain references describe carbohydrate, fibre, protein and minerals. The supplied formula says flakes, not sprouted ragi; do not transfer a germination/phytase claim. [11] [12]
- **Samai flakes:** samai is little millet; raw-grain and flakes-product sources give general ingredient context, not a laboratory measure of ABC+. [7] [13]
- **Kuthiraivali flakes:** Tamil Nadu Agricultural University identifies Kuthiraivali/Kudiraivali as barnyard millet; grain data do not measure the flaked ingredient or blend. [14] [15]
- **Sunflower seeds:** generic food references report protein, fat and fibre; the exact kernel/whole-seed form and processing are unspecified. [11] [16] [17]
- **Cocoa powder:** generic food tables list protein, fat, carbohydrate and fibre; these are not product measurements. [18]
- **Palm sugar:** provides sweetness and sugars; it should not be presented as sugar-free or inherently healthier than other sugars. [19] [20]
- **Cardamom powder:** an aromatic culinary spice; the species and colour are not specified, so no product-specific nutrient or health effect is claimed. [21]

## Brand-supplied per-50-g panel

The values below are copied from the latest user-supplied formulation artwork. They are approximate brand inputs, not independent ABC+ laboratory results.

| Nutrient | Amount | RDA shown on artwork |
|---|---:|---:|
| Energy | 219 kcal | 11% |
| Protein | 8.5 g | 16% |
| Total fat | 5.1 g | 8% |
| Saturated fat | 0.9 g | 4% |
| MUFA + PUFA | 4.0 g | — |
| Carbohydrate | 33.0 g | 11% |
| Naturally occurring sugars | 9.6 g | — |
| Added sugar (from palm sugar) | 0.53 g | 1% |
| Dietary fibre | 4.8 g | 16% |
| Sodium | 22 mg | 1% |
| Calcium | 82 mg | 8% |
| Iron | 3.2 mg | 18% |
| Magnesium | 96 mg | 23% |
| Phosphorus | 208 mg | 30% |
| Potassium | 310 mg | 9% |
| Zinc | 1.9 mg | 17% |
| Vitamin A (from beta-carotene) | 410 μg | 46% |
| Folate (B9) | 54 μg | 14% |
| Vitamin E | 3.8 mg | 25% |
| Vitamin B1 (thiamine) | 0.31 mg | 26% |
| Vitamin B3 (niacin) | 3.4 mg | 21% |
| Vitamin B6 | 0.28 mg | 20% |

RDA percentages are reproduced from the artwork, which says ICMR 2020 and an average adult 2,000-kcal diet. The app does not call this a complete regulated package declaration. The user-approved comparison panel uses approximate everyday-food analogies; the app labels these as illustrations only, not replacement foods or equal overall nutrition.

## Nutrition mechanisms and claim boundary

Grains, millets and Bengal gram supply carbohydrate including starch. Digestion breaks most starch down into glucose used for energy. Fibre is not digested like starch; fibre-rich foods and adequate liquids can support normal bowel habits. Dietary protein is digested into amino acids used to maintain and repair cells. Dietary fat supplies energy and helps the body absorb some vitamins. These are general food/nutrient roles, not a product-specific glycaemic, satiety, skin, hair, focus, heart-health or clinical result. [22] [23] [24] [25] [26]

The current panel lists nutrients with normal body roles in energy metabolism, oxygen transport, bone/muscle/nerve function, tissue and immune function. Their presence alone does not show that ABC+ improves skin, grows hair, prevents disease or treats a deficiency. [27]–[37]

The engineering PDF describes an older formula and process-specific rationales, including sprouted ragi, amla-derived iron absorption, high-temperature roasting, cryogenic milling and nitrogen flushing. The latest recipe lists ragi flakes and no amla, and does not confirm those manufacturing steps. Do not transfer these product-specific claims, a 300% iron-bioavailability figure, the PDF’s clinical/shelf-life claims, or other specific mechanisms to the current blend. See [engineering-mechanism.md](./engineering-mechanism.md).

## References

[1]: https://nutritionsource.hsph.harvard.edu/food-features/apples/ "Harvard Nutrition Source Apples"
[2]: https://fdc.nal.usda.gov/food-search?query=apples "USDA FoodData Central Apples"
[3]: https://pmc.ncbi.nlm.nih.gov/articles/PMC8565237/ "Beetroot Composition Review"
[4]: https://pmc.ncbi.nlm.nih.gov/articles/PMC8229785/ "Beetroot Bioactive Compounds Review"
[5]: https://pmc.ncbi.nlm.nih.gov/articles/PMC8535146/ "Carrot Powder Study"
[6]: https://fdc.nal.usda.gov/food-search?query=carrot "USDA FoodData Central Carrots"
[7]: https://www.nin.res.in/ebooks/IFCT2017.pdf "Indian Food Composition Tables 2017"
[8]: https://www.fao.org/pulses-2016/news/news-detail/en/c/429320/ "FAO Pulses"
[9]: https://nutritionsource.hsph.harvard.edu/food-features/oats/ "Harvard Nutrition Source Oats"
[10]: https://pubmed.ncbi.nlm.nih.gov/28067025/ "Oats and Beta-Glucan Review"
[11]: https://www.nin.res.in/ebooks/IFCT2017_16122024.pdf "Indian Food Composition Tables"
[12]: https://www.fao.org/millets-2023/about/en "FAO Millets"
[13]: https://pmc.ncbi.nlm.nih.gov/articles/PMC4554602/ "Little-Millet Flakes Study"
[14]: http://www.agritech.tnau.ac.in/agriculture/millets_kudiraivali.html "Tamil Nadu Agricultural University Kuthiraivali"
[15]: https://pmc.ncbi.nlm.nih.gov/articles/PMC10497464/ "Barnyard Millet Review"
[16]: https://fdc.nal.usda.gov/food-search?query=sunflower%20seeds "USDA FoodData Central Sunflower Seeds"
[17]: https://www.nin.res.in/ebooks/IFCT2017_16122024.pdf "Indian Food Composition Tables Sunflower Seeds"
[18]: https://www.matvaretabellen.no/en/cocoa-powder/ "Norwegian Food Composition Table Cocoa Powder"
[19]: https://pmc.ncbi.nlm.nih.gov/articles/PMC10073893/ "Palm-Sap Sugar Review"
[20]: https://www.who.int/publications/i/item/9789241549028 "WHO Sugars Guideline"
[21]: https://www.mccormickscienceinstitute.com/resources/culinary-spices/herbs-spices/cardamom "McCormick Science Institute Cardamom"
[22]: https://medlineplus.gov/ency/article/002469.htm "MedlinePlus Carbohydrates"
[23]: https://www.niddk.nih.gov/health-information/digestive-diseases/constipation/eating-diet-nutrition "NIDDK Fibre and Digestion"
[24]: https://medlineplus.gov/ency/article/002467.htm "MedlinePlus Protein in Diet"
[25]: https://medlineplus.gov/dietaryfats.html "MedlinePlus Dietary Fats"
[26]: https://nigms.nih.gov/biobeat/2024/01/what-do-fats-do-in-the-body "NIH NIGMS What Do Fats Do in the Body"
[27]: https://ods.od.nih.gov/factsheets/VitaminA-HealthProfessional/ "NIH ODS Vitamin A"
[28]: https://ods.od.nih.gov/factsheets/Zinc-HealthProfessional/ "NIH ODS Zinc"
[29]: https://ods.od.nih.gov/factsheets/Iron-HealthProfessional/ "NIH ODS Iron"
[30]: https://ods.od.nih.gov/factsheets/Thiamin-HealthProfessional/ "NIH ODS Thiamin"
[31]: https://ods.od.nih.gov/factsheets/Niacin-HealthProfessional/ "NIH ODS Niacin"
[32]: https://ods.od.nih.gov/factsheets/VitaminB6-HealthProfessional/ "NIH ODS Vitamin B6"
[33]: https://ods.od.nih.gov/factsheets/Calcium-HealthProfessional/ "NIH ODS Calcium"
[34]: https://ods.od.nih.gov/factsheets/Magnesium-HealthProfessional/ "NIH ODS Magnesium"
[35]: https://ods.od.nih.gov/factsheets/Phosphorus-HealthProfessional/ "NIH ODS Phosphorus"
[36]: https://ods.od.nih.gov/factsheets/VitaminE-HealthProfessional/ "NIH ODS Vitamin E"
[37]: https://ods.od.nih.gov/factsheets/Biotin-HealthProfessional/ "NIH ODS Biotin"
