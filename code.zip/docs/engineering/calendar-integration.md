# Calendar reminder integration — findings and limits

## Product behavior

Reminders are explicit, user-initiated calendar actions. The app pre-fills an event title, context, local date/time and event alert. The person can edit, repeat, save or cancel in the operating-system event form. The app does not create an event while the user types, opens a page or checks a habit, and it does not read or store existing calendar events. Reminder text enters the user's calendar only after the user chooses to save. On Web, the action downloads an `.ics` file for manual import.

## Expo SDK and permissions

The project is Expo SDK 57 and resolves `expo-calendar` 57.0.6. Official documentation supports native Calendar on iOS and Android but says the package is not included in Expo Go or Snack. A custom development or production build is needed for native use. The Expo Mobile README identifies Dashboard builds as the release handoff; this change has not produced a native build.

The app config selects Expo Calendar write-only access on iOS, provides an explicit purpose string and disables reminder access. The app requests that access only after the user taps a reminder. It does not request permission to read existing calendar event contents. Android uses the system event form and blocks `READ_CALENDAR` and `WRITE_CALENDAR` permissions; Expo documentation says those permissions are unnecessary when the app only presents the system calendar UI.

A previous SDK 57 report identified a write-only/default-calendar issue; the issue was closed through PR #48186. The app is configured for write-only access, but the native flow still needs a device build smoke check before it can be called runtime-verified.

## Verification

The Web `.ics` path was tapped in Preview and the downloaded file was inspected. It contained a prefilled Heavenly’s ABC+ breakfast title, recipe directions as event notes, a 30-minute event window and a display alarm. TypeScript and automated tests pass, including five tests for calendar date/payload and ICS behavior. Native event forms and permission prompts have not yet been exercised on Android or iOS.

## References

- Expo SDK 57 Calendar API: https://docs.expo.dev/versions/v57.0.0/sdk/calendar/
- Expo Calendar SDK-library migration guide: https://docs.expo.dev/guides/sdk-libraries-migration/calendar/
- SDK 57 write-only/default-calendar report: https://github.com/expo/expo/issues/48143
- Fix referenced by the issue: https://github.com/expo/expo/pull/48186
