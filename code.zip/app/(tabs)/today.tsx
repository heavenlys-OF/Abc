import React from "react";
import { Text, View } from "react-native";
import { C, Checks, Page, Section, TaskRows } from "@/components/life-os/ui";
import { AnalysisPanel } from "@/components/life-os/analysis-panel";
import { CalendarReminderAction } from "@/components/life-os/calendar-reminder-action";
import { OverviewCarousel } from "@/components/life-os/overview";
import { EntrySubmissionCard } from "@/components/life-os/submission";
import { RemindableField } from "@/components/life-os/remindable-field";
import { analyzeDaily, analyzeMonth, analyzeWeekly } from "@/lib/life-os/analysis";
import { dailyHabitNames, localDayKey, useLifeOS } from "@/lib/life-os/store";
import { suggestedReminderStartDate } from "@/lib/calendar/reminder";

export default function TodayScreen() {
  const { today, week, month, updateToday } = useLifeOS();
  const dailyAnalysis = analyzeDaily(today);
  const weeklyAnalysis = analyzeWeekly(week);
  const monthlyAnalysis = analyzeMonth(month);
  const finishedTasks = today.quickTasks.filter((task) => task.done).length;
  const finishedHabits = today.completedHabits.length;
  const progress = finishedTasks + finishedHabits;
  const dayKey = localDayKey();

  return (
    <Page
      title="Today"
      kicker={new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" }).toUpperCase()}
      subtitle="A thoughtful start, at your own pace."
    >
      <OverviewCarousel daily={dailyAnalysis} weekly={weeklyAnalysis} monthly={monthlyAnalysis} />

      <Section title="Today's focus" color={C.wash} caption="What is the one thing that would make today successful?">
        <RemindableField
          accessibilityLabel="Today's focus"
          value={today.focus}
          onChange={(focus) => updateToday({ focus })}
          placeholder="Name what matters most…"
          multiline
          reminderPrefix="Today's focus"
        />
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 9 }}>
          <Text style={{ color: C.muted, fontSize: 12 }}>Small steps count.</Text>
          <View style={{ backgroundColor: "#F7F5EF", borderRadius: 20, paddingHorizontal: 11, paddingVertical: 6 }}>
            <Text style={{ color: C.sage, fontSize: 11, fontWeight: "700" }}>{progress} small wins</Text>
          </View>
        </View>
      </Section>

      <Section title="Three priorities" caption="Keep the list kind and clear.">
        {[0, 1, 2].map((index) => (
          <RemindableField
            key={index}
            label={`PRIORITY ${index + 1}`}
            value={today.priorities[index] ?? ""}
            onChange={(value) => {
              const priorities = [...today.priorities];
              priorities[index] = value;
              updateToday({ priorities });
            }}
            placeholder="One meaningful thing"
            reminderPrefix={`Today's priority ${index + 1}`}
          />
        ))}
      </Section>

      <Section title="Quick tasks" caption="Light enough for 10–15 minutes each.">
        <TaskRows
          label="Quick task"
          items={today.quickTasks}
          placeholders={["A small next step…", "One quick win…", "A little thing to finish…", "Clear one small task…", "Make space for what matters…"]}
          onChange={(quickTasks) => updateToday({ quickTasks })}
          renderReminder={(task, index) => task.text.trim() && !task.done ? (
            <CalendarReminderAction
              title={`Quick task ${index + 1}: ${task.text.trim()}`}
              notes={`Today's quick task: ${task.text.trim()}`}
              compact
              label="Remind"
            />
          ) : null}
        />
      </Section>

      <Section title="Daily habits" caption="Build identity, one day at a time. Add a calendar reminder for any habit.">
        <Checks
          items={dailyHabitNames}
          values={today.completedHabits}
          onToggle={(habit) => {
            const completedHabits = today.completedHabits.includes(habit)
              ? today.completedHabits.filter((item) => item !== habit)
              : [...today.completedHabits, habit];
            updateToday({ completedHabits });
          }}
          renderReminder={(habit) => (
            <CalendarReminderAction
              title={`Daily habit: ${habit}`}
              notes={`A reminder for the daily ${habit.toLowerCase()} habit.`}
              defaultStartDate={suggestedReminderStartDate(1)}
              compact
              label="Remind"
            />
          )}
        />
      </Section>

      <Section title="Notes / ideas" caption="A small thought worth keeping.">
        <RemindableField
          value={today.notes}
          onChange={(notes) => updateToday({ notes })}
          placeholder="Leave a note for yourself…"
          multiline
          reminderPrefix="Today note"
        />
      </Section>

      <Section title="Gratitude" caption="Name one to three small things.">
        {today.gratitude.map((entry, index) => (
          <RemindableField
            key={index}
            accessibilityLabel={`Gratitude ${index + 1}`}
            value={entry}
            onChange={(value) => {
              const gratitude = [...today.gratitude];
              gratitude[index] = value;
              updateToday({ gratitude });
            }}
            placeholder="Something I’m grateful for…"
            reminderPrefix={`Gratitude ${index + 1}`}
          />
        ))}
      </Section>

      <Section title="Tomorrow's first step" caption="Leave yourself a kind beginning.">
        <RemindableField
          value={today.tomorrow}
          onChange={(tomorrow) => updateToday({ tomorrow })}
          placeholder="Make tomorrow a little easier…"
          reminderPrefix="Tomorrow's first step"
          defaultStartDate={suggestedReminderStartDate(1)}
        />
      </Section>

      <AnalysisPanel title="Today's response analysis" insight={dailyAnalysis} />

      <EntrySubmissionCard entry={{
        type: "daily",
        periodKey: dayKey,
        recordKey: dayKey,
        payload: {
          focus: today.focus,
          priorities: today.priorities.slice(0, 3),
          quickTasks: today.quickTasks.slice(0, 5),
          completedHabits: dailyHabitNames.filter((habit) => today.completedHabits.includes(habit)),
          notes: today.notes,
          gratitude: today.gratitude.slice(0, 3),
          tomorrow: today.tomorrow,
        },
      }} />
    </Page>
  );
}
