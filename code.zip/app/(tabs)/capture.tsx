import React, { useState } from "react";
import { Text, TouchableOpacity } from "react-native";
import { CalendarReminderAction } from "@/components/life-os/calendar-reminder-action";
import { C, Field, Page, Section } from "@/components/life-os/ui";
import { NoteArchive } from "@/components/life-os/note-archive";
import { suggestedReminderStartDate } from "@/lib/calendar/reminder";
import { useLifeOS } from "@/lib/life-os/store";

export default function CaptureScreen() {
  const [draft, setDraft] = useState("");
  const { notes, addNote, removeNote } = useLifeOS();
  const shortDraft = draft.trim().replace(/\s+/g, " ").slice(0, 72);

  return (
    <Page title="Brain dump" kicker="CLEAR YOUR MIND" subtitle="Thoughts, ideas, worries, tasks — anything can land here.">
      <Section title="Let it out" caption="No sorting needed. Save it here first; submit it when you want an account copy." color={C.lilac}>
        <Field
          accessibilityLabel="Write what's on your mind"
          value={draft}
          onChange={setDraft}
          placeholder="Start anywhere…"
          multiline
        />
        {draft.trim() ? (
          <CalendarReminderAction
            title={`Brain dump: ${shortDraft}`}
            notes={`Brain dump draft:\n${draft}`}
            defaultStartDate={suggestedReminderStartDate(1)}
            compact
          />
        ) : null}
        <TouchableOpacity
          accessibilityRole="button"
          accessibilityLabel="Save thought on this device"
          disabled={!draft.trim()}
          onPress={() => {
            addNote(draft);
            setDraft("");
          }}
          style={{ marginTop: 15, minHeight: 48, backgroundColor: draft.trim() ? C.forest : "#AAB5A9", paddingHorizontal: 18, borderRadius: 14, alignItems: "center", justifyContent: "center" }}
        >
          <Text style={{ color: "white", fontSize: 14, fontWeight: "700", letterSpacing: 0.2 }}>Save thought on this device</Text>
        </TouchableOpacity>
      </Section>

      <Section title={`Saved thoughts · ${notes.length}`} caption="Submit each thought to your account archive. Removing it here does not delete a submitted copy.">
        <NoteArchive notes={notes} onRemove={removeNote} />
      </Section>
    </Page>
  );
}
