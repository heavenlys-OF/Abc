import React from "react";
import { CalendarReminderAction } from "@/components/life-os/calendar-reminder-action";
import { RemindableField } from "@/components/life-os/remindable-field";
import { Page, Section, TaskRows } from "@/components/life-os/ui";
import { AnalysisPanel } from "@/components/life-os/analysis-panel";
import { EntrySubmissionCard } from "@/components/life-os/submission";
import { analyzeWeekly } from "@/lib/life-os/analysis";
import { localWeekKey, useLifeOS } from "@/lib/life-os/store";

function weekOfLabel() {
  const start = new Date(`${localWeekKey()}T12:00:00`);
  return `WEEK OF ${start.toLocaleDateString(undefined, { month: "long", day: "numeric" }).toUpperCase()}`;
}

export default function WeekScreen() {
  const { week, updateWeek } = useLifeOS();
  const weekKey = localWeekKey();
  const analysis = analyzeWeekly(week);

  return (
    <Page title="Weekly reset" kicker={weekOfLabel()} subtitle="Clear a little space. Find your way back to what matters.">
      <AnalysisPanel title="This week's response analysis" insight={analysis} />

      <Section title="This week's big goal" caption="One clear intention for the days ahead.">
        <RemindableField value={week.goal} onChange={(goal) => updateWeek({ goal })} placeholder="What would make this week meaningful?" multiline reminderPrefix="Weekly goal" />
      </Section>

      <Section title="Top three outcomes" caption="Progress can be quiet and still count.">
        {week.outcomes.map((outcome, index) => (
          <RemindableField
            key={index}
            label={`OUTCOME ${index + 1}`}
            value={outcome}
            onChange={(value) => {
              const outcomes = [...week.outcomes];
              outcomes[index] = value;
              updateWeek({ outcomes });
            }}
            placeholder="A clear, doable outcome"
            reminderPrefix={`Weekly outcome ${index + 1}`}
          />
        ))}
      </Section>

      <Section title="Must-do tasks" caption="Keep the essentials visible, not overwhelming.">
        <TaskRows
          label="Must-do"
          items={week.mustDos}
          placeholders={["One thing that needs doing…", "An important follow-through…", "A small essential…", "Something to make easier…", "A final must-do…"]}
          onChange={(mustDos) => updateWeek({ mustDos })}
          renderReminder={(task, index) => task.text.trim() && !task.done ? (
            <CalendarReminderAction title={`Weekly must-do ${index + 1}: ${task.text.trim()}`} notes={`Weekly must-do task: ${task.text.trim()}`} compact label="Remind" />
          ) : null}
        />
      </Section>

      <Section title="Avoiding / fixing" caption="Notice it without judgment; choose one useful next move.">
        <RemindableField label="WHAT AM I AVOIDING?" value={week.avoiding} onChange={(avoiding) => updateWeek({ avoiding })} placeholder="Name what's on your mind…" multiline reminderPrefix="Weekly reflection" />
        <RemindableField label="WHAT AM I FIXING OR ADDRESSING?" value={week.fixing} onChange={(fixing) => updateWeek({ fixing })} placeholder="One small, useful move…" multiline reminderPrefix="Weekly next step" />
      </Section>

      <Section title="Energy check" caption="Make more room for what helps you feel like yourself.">
        <RemindableField label="WHAT DRAINED ME THIS WEEK?" value={week.drained} onChange={(drained) => updateWeek({ drained })} placeholder="Notice without judgment…" multiline reminderPrefix="Weekly energy reflection" />
        <RemindableField label="WHAT GAVE ME ENERGY?" value={week.energized} onChange={(energized) => updateWeek({ energized })} placeholder="What would I like more of?" multiline reminderPrefix="Weekly energy reflection" />
      </Section>

      <EntrySubmissionCard entry={{
        type: "weekly",
        periodKey: weekKey,
        recordKey: weekKey,
        payload: {
          goal: week.goal,
          outcomes: week.outcomes.slice(0, 3),
          mustDos: week.mustDos.slice(0, 5),
          avoiding: week.avoiding,
          fixing: week.fixing,
          drained: week.drained,
          energized: week.energized,
        },
      }} />
    </Page>
  );
}
