import React from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { C, Page, Section } from "@/components/life-os/ui";
import { AnalysisPanel } from "@/components/life-os/analysis-panel";
import { EntrySubmissionCard } from "@/components/life-os/submission";
import { RemindableField } from "@/components/life-os/remindable-field";
import { suggestedReminderStartDate } from "@/lib/calendar/reminder";
import { analyzeMonth } from "@/lib/life-os/analysis";
import { daysInMonth, localMonthKey, useLifeOS } from "@/lib/life-os/store";

export default function HabitsScreen() {
  const { month, updateMonth } = useLifeOS();
  const now = new Date();
  const monthName = now.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  const currentMonth = localMonthKey();
  const days = Array.from({ length: daysInMonth(now) }, (_, index) => index + 1);
  const analysis = analyzeMonth(month, now);

  return (
    <Page title="Habit garden" kicker={monthName.toUpperCase()} subtitle="Small daily actions, consistently repeated, create a new you.">
      <AnalysisPanel title="Your month-to-date pattern" insight={analysis} />
      {analysis.habits.length ? (
        <Section title="Habit by habit" caption="Check-ins are measured from the day you added each practice.">
          {analysis.habits.map((habit) => (
            <View key={habit.name} style={{ marginVertical: 6 }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 6 }}>
                <Text style={{ color: C.ink, fontSize: 13, fontWeight: "600" }}>{habit.name}</Text>
                <Text style={{ color: C.muted, fontSize: 12 }}>{habit.complete}/{habit.possible}</Text>
              </View>
              <View style={{ height: 5, borderRadius: 3, backgroundColor: "#E9E8DF", overflow: "hidden" }}>
                <View style={{ height: "100%", width: `${Math.round((habit.progress ?? 0) * 100)}%`, borderRadius: 3, backgroundColor: C.sage }} />
              </View>
            </View>
          ))}
        </Section>
      ) : null}

      <Section title="Focus for this month" caption="What practice would make the biggest difference?" color={C.wash}>
        <RemindableField value={month.focus} onChange={(focus) => updateMonth({ focus })} placeholder="Choose a gentle intention…" multiline reminderPrefix="Monthly focus" defaultStartDate={suggestedReminderStartDate(1)} />
      </Section>

      <Section title="My habits" caption="Make them yours. You can track up to five. Add a reminder for a habit and choose repeat in your calendar.">
        {month.habits.map((habit, index) => (
          <View key={habit.id} style={{ marginBottom: 3 }}>
            <RemindableField
              label={`HABIT ${index + 1}`}
              value={habit.name}
              onChange={(name) => updateMonth({ habits: month.habits.map((item) => item.id === habit.id ? { ...item, name } : item) })}
              placeholder="A small practice to grow…"
              reminderPrefix="Monthly habit"
              defaultStartDate={suggestedReminderStartDate(1)}
            />
            <TouchableOpacity
              accessibilityRole="button"
              accessibilityLabel={`Remove habit ${index + 1}`}
              onPress={() => {
                const habits = month.habits.filter((item) => item.id !== habit.id);
                const checks = Object.fromEntries(Object.entries(month.checks).filter(([key]) => !key.startsWith(`${habit.id}-`)));
                updateMonth({ habits, checks });
              }}
              style={{ alignSelf: "flex-end", paddingHorizontal: 8, paddingVertical: 5 }}
            >
              <Text style={{ color: C.muted, fontSize: 11 }}>Remove habit</Text>
            </TouchableOpacity>
          </View>
        ))}
        {month.habits.length < 5 ? (
          <TouchableOpacity
            accessibilityRole="button"
            accessibilityLabel="Add a monthly habit"
            onPress={() => updateMonth({ habits: [...month.habits, { id: `habit-${Date.now()}`, name: "", startDay: now.getDate() }] })}
            style={{ minHeight: 42, justifyContent: "center" }}
          >
            <Text style={{ color: C.sage, fontSize: 14, fontWeight: "700" }}>＋  Add a habit</Text>
          </TouchableOpacity>
        ) : (
          <Text style={{ color: C.muted, fontSize: 12, paddingVertical: 8 }}>Your five habit spaces are full.</Text>
        )}
      </Section>

      <Section title="Day by day" caption="Swipe sideways to move through the month.">
        {month.habits.length ? (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            <View>
              <View style={{ flexDirection: "row", alignItems: "center", borderBottomWidth: 1, borderColor: C.line }}>
                <Text style={{ width: 92, color: C.muted, fontSize: 10, fontWeight: "700", letterSpacing: 0.5, paddingVertical: 10 }}>HABIT</Text>
                {days.map((day) => <Text key={day} style={{ width: 34, textAlign: "center", color: C.muted, fontSize: 10, paddingVertical: 10 }}>{day}</Text>)}
              </View>
              {month.habits.map((habit) => (
                <View key={habit.id} style={{ flexDirection: "row", alignItems: "center", minHeight: 48, borderBottomWidth: 1, borderColor: C.line }}>
                  <Text numberOfLines={1} style={{ width: 92, color: C.ink, fontSize: 12, paddingRight: 6 }}>{habit.name.trim() || "New habit"}</Text>
                  {days.map((day) => {
                    const checkKey = `${habit.id}-${day}`;
                    const checked = Boolean(month.checks[checkKey]);
                    const available = day >= habit.startDay && day <= now.getDate();
                    return (
                      <TouchableOpacity
                        key={day}
                        accessibilityRole="checkbox"
                        accessibilityLabel={`${habit.name || "New habit"}, day ${day}`}
                        accessibilityState={{ checked, disabled: !available }}
                        disabled={!available}
                        onPress={() => updateMonth({ checks: { ...month.checks, [checkKey]: !checked } })}
                        style={{ width: 34, minHeight: 46, alignItems: "center", justifyContent: "center", opacity: available ? 1 : 0.42 }}
                      >
                        <View style={{ width: 19, height: 19, borderRadius: 10, backgroundColor: checked ? C.sage : "transparent", borderWidth: 1, borderColor: checked ? C.sage : "#D3CFC4", alignItems: "center", justifyContent: "center" }}>
                          {checked ? <Text style={{ color: "white", fontSize: 10, fontWeight: "800" }}>✓</Text> : null}
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              ))}
            </View>
          </ScrollView>
        ) : (
          <Text style={{ color: C.muted, fontSize: 13, lineHeight: 20, paddingVertical: 9 }}>Add a habit above, then mark a small win whenever it happens.</Text>
        )}
        <Text style={{ color: C.muted, fontSize: 11, marginTop: 12 }}>{currentMonth}  ·  {days.length} days to tend</Text>
      </Section>

      <EntrySubmissionCard entry={{
        type: "habit_month",
        periodKey: currentMonth,
        recordKey: currentMonth,
        payload: { focus: month.focus, habits: month.habits, checks: month.checks },
      }} />
    </Page>
  );
}
