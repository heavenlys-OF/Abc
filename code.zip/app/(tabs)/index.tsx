import React from "react";
import { Image, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import type { Href } from "expo-router";
import { C, Page, Section } from "@/components/life-os/ui";
import { IngredientDetailsModal } from "@/components/abcplus/ingredient-details";
import { NutritionDetailsModal } from "@/components/abcplus/nutrition-details";
import { ABC_PLUS_INGREDIENTS, ABC_PLUS_GROUPS, type AbcPlusIngredientItem } from "@/shared/abcplus-ingredients";
import { ABC_PLUS_NUTRITION } from "@/shared/abcplus-nutrition";
import { NutritionBodyBenefits } from "@/components/abcplus/nutrition-body-benefits";

const SUPPORT_LINKS = [
  { label: "Plan today", detail: "Choose a focus and three priorities.", route: "/today" },
  { label: "Build a habit", detail: "Make a small morning routine easier to repeat.", route: "/habits" },
] as const;

function formatGrams(value: number) {
  return `${value.toFixed(2)} g`;
}

export default function AbcPlusHome() {
  const router = useRouter();
  const [selectedIngredient, setSelectedIngredient] = React.useState<AbcPlusIngredientItem | null>(null);
  const [nutritionOpen, setNutritionOpen] = React.useState(false);

  return (
    <Page
      brandName="HEAVENLY’S ABC+"
      brandMarkText="ABC+"
      title="3-Minute Breakfast"
      kicker="REAL INGREDIENTS · COMPLETE NUTRITION"
      subtitle="Nourishing you, naturally."
      footerText="ABC+  ·  GOOD FOOD  ·  BRIGHTER DAYS"
    >
      <View style={{ backgroundColor: C.card, borderRadius: 22, overflow: "hidden", marginTop: 19, borderWidth: 1, borderColor: C.line }}>
        <View style={{ width: "100%", aspectRatio: 1539 / 1022, backgroundColor: C.card }}>
          <Image
            source={require("../../assets/images/heavenlys-abcplus-hero.png")}
            accessibilityLabel="Heavenly’s ABC+ 3-Minute Breakfast artwork showing a seven-sachet 50-gram pack and warm and cold serving ideas."
            accessible
            resizeMode="contain"
            style={{ position: "absolute", top: 0, right: 0, bottom: 0, left: 0, width: "100%", height: "100%" }}
          />
        </View>
        <View style={{ paddingHorizontal: 17, paddingVertical: 15 }}>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 7 }}>
            {["7 × 50 G SACHETS", "12 INGREDIENTS", "READY IN 3 MINUTES"].map((label, index) => (
              <View key={label} style={{ backgroundColor: index === 0 ? "#F7F1E4" : C.wash, borderRadius: 15, paddingHorizontal: 10, paddingVertical: 6 }}>
                <Text style={{ color: index === 0 ? "#76694C" : C.forest, fontSize: 9, fontWeight: "800" }}>{label}</Text>
              </View>
            ))}
          </View>
          <Text style={{ color: C.ink, fontFamily: "Georgia", fontSize: 20, lineHeight: 27, marginTop: 10 }}>
            Goodness in every sachet.
          </Text>
          <Text style={{ color: C.muted, fontSize: 12, lineHeight: 18, marginTop: 5 }}>
            Fruit and root powders, grains, millets, Bengal gram, sunflower seeds, cocoa, cardamom and palm sugar—made for a simple start to the day.
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 12 }}>
            {["Plant protein · 8.5 g", "High fibre · 4.8 g", "Vitamins & minerals", "No artificial flavours or sweeteners", "No refined sugar · made with palm sugar"].map((claim) => (
              <View key={claim} style={{ paddingHorizontal: 9, paddingVertical: 6, borderRadius: 12, backgroundColor: "#FBF7EE", borderWidth: 1, borderColor: C.line }}>
                <Text style={{ color: C.forest, fontSize: 9, lineHeight: 13, fontWeight: "700" }}>{claim}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>

      <NutritionBodyBenefits />

      <Section title="How to enjoy" caption="One 50 g sachet, mixed your way. Ready in about 3 minutes." color={C.wash}>
        <View style={{ gap: 10 }}>
          {[
            ["01", "Add one 50 g sachet to a glass or cup"],
            ["02", "Use 200 ml warm water, or warm/cold milk"],
            ["03", "Stir or shake until smooth"],
            ["04", "Enjoy a wholesome breakfast in about 3 minutes"],
          ].map(([step, text]) => (
            <View key={step} style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
              <View style={{ width: 25, height: 25, borderRadius: 13, backgroundColor: C.card, alignItems: "center", justifyContent: "center" }}>
                <Text style={{ color: C.forest, fontSize: 9, fontWeight: "900" }}>{step}</Text>
              </View>
              <Text style={{ flex: 1, color: C.ink, fontSize: 12, lineHeight: 18 }}>{text}</Text>
            </View>
          ))}
        </View>
      </Section>

      <Section title="The 12 ingredients" caption="Formula weights per 100 g of blend and in one 50 g sachet. Tap a row for general food context and sources.">
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 7, marginBottom: 13 }}>
          {ABC_PLUS_GROUPS.map((group) => (
            <View key={group.id} style={{ width: "48.5%", paddingHorizontal: 9, paddingVertical: 8, borderRadius: 11, backgroundColor: C.wash }}>
              <Text style={{ color: C.muted, fontSize: 8, lineHeight: 12, fontWeight: "700" }}>{group.title.toUpperCase()}</Text>
              <Text style={{ color: C.forest, fontSize: 12, fontWeight: "900", marginTop: 2 }}>{group.sharePercent.toFixed(1)}% of blend</Text>
            </View>
          ))}
        </View>
        <View style={{ borderTopWidth: 1, borderColor: C.line }}>
          {ABC_PLUS_INGREDIENTS.map((ingredient, index) => (
            <TouchableOpacity
              key={ingredient.name}
              accessibilityRole="button"
              accessibilityLabel={`${ingredient.name}. ${formatGrams(ingredient.amountPer50g)} per 50 gram sachet and ${formatGrams(ingredient.amountPer100g)} per 100 gram blend. Tap for ingredient information and sources.`}
              onPress={() => setSelectedIngredient(ingredient)}
              style={{ flexDirection: "row", alignItems: "center", gap: 9, minHeight: 54, paddingVertical: 7, borderBottomWidth: 1, borderColor: C.line }}
            >
              <View style={{ width: 23, height: 23, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "#F7F1E4" }}>
                <Text style={{ color: "#76694C", fontSize: 8, fontWeight: "900" }}>{String(index + 1).padStart(2, "0")}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: C.ink, fontSize: 11, lineHeight: 15, fontWeight: "700" }}>{ingredient.name}</Text>
                <Text style={{ color: C.muted, fontSize: 9, lineHeight: 13, marginTop: 1 }}>Per 100 g blend: {formatGrams(ingredient.amountPer100g)}</Text>
              </View>
              <View style={{ alignItems: "flex-end", minWidth: 64 }}>
                <Text style={{ color: C.forest, fontSize: 12, fontWeight: "900" }}>{formatGrams(ingredient.amountPer50g)}</Text>
                <Text style={{ color: C.muted, fontSize: 8, marginTop: 1 }}>per sachet</Text>
              </View>
              <Text style={{ color: C.sage, fontSize: 14, fontWeight: "900" }}>›</Text>
            </TouchableOpacity>
          ))}
        </View>
        <View style={{ marginTop: 13, padding: 11, borderRadius: 12, backgroundColor: C.wash }}>
          <Text style={{ color: C.forest, fontSize: 10, lineHeight: 15, fontWeight: "700" }}>
            The latest ingredient list does not include peanuts or sesame. Check the finished pack for complete allergen and cross-contact information.
          </Text>
        </View>
        <Text style={{ color: C.muted, fontSize: 9, lineHeight: 14, marginTop: 9 }}>
          Ingredient weights are formula weights, not the nutrient weights from each ingredient. Amounts are normalized from the line-item recipe total.
        </Text>
      </Section>

      <Section title="Nutrition highlights" caption="Latest brand-supplied values per 50 g sachet; see the detail view for selected nutrients." color={C.wash}>
        <View style={{ flexDirection: "row", gap: 8 }}>
          {[
            { label: "Energy", amount: `${ABC_PLUS_NUTRITION.energyKcal} kcal` },
            { label: "Plant protein", amount: "8.5 g" },
            { label: "Dietary fibre", amount: "4.8 g" },
          ].map((item) => (
            <View key={item.label} style={{ flex: 1, minHeight: 69, padding: 9, borderRadius: 13, backgroundColor: C.card, alignItems: "center", justifyContent: "center" }}>
              <Text style={{ color: C.forest, fontSize: 14, fontWeight: "900" }}>{item.amount}</Text>
              <Text style={{ color: C.muted, fontSize: 9, fontWeight: "700", marginTop: 3 }}>{item.label.toUpperCase()}</Text>
            </View>
          ))}
        </View>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 10 }}>
          <View style={{ paddingHorizontal: 9, paddingVertical: 6, borderRadius: 12, backgroundColor: C.card }}>
            <Text style={{ color: C.forest, fontSize: 9, fontWeight: "700" }}>Palm sugar · 0.53 g per sachet</Text>
          </View>
          <View style={{ paddingHorizontal: 9, paddingVertical: 6, borderRadius: 12, backgroundColor: C.card }}>
            <Text style={{ color: C.forest, fontSize: 9, fontWeight: "700" }}>Vitamins & minerals</Text>
          </View>
        </View>
        <Text style={{ color: C.muted, fontSize: 9, lineHeight: 14, marginTop: 9 }}>
          Approximate brand-supplied values may vary with natural ingredients. Palm sugar is present; the product is not described as free of added sugar.
        </Text>
        <TouchableOpacity
          accessibilityRole="button"
          accessibilityLabel="View latest nutrition highlights and RDA values"
          onPress={() => setNutritionOpen(true)}
          style={{ minHeight: 45, marginTop: 11, paddingHorizontal: 13, borderRadius: 13, backgroundColor: C.forest, alignItems: "center", justifyContent: "center" }}
        >
          <Text style={{ color: "#FFFCF6", fontSize: 11, fontWeight: "800" }}>View nutrition details</Text>
        </TouchableOpacity>
      </Section>

      <Section title="ABC+ — holistic benefits" caption="A practical blend, flexible preparation and a small ritual you can make your own.">
        <View style={{ gap: 13 }}>
          {[
            ["01", "Ingredient variety", "Fruit and root powders, grains, millets, Bengal gram, sunflower seeds, cocoa, cardamom and palm sugar together in one sachet."],
            ["02", "Preparation that flexes", "Mix 50 g with 200 ml warm water or warm/cold milk. Stir or shake; ready in about 3 minutes."],
            ["03", "A morning routine with room to grow", "Today and Habits in Life OS can help you plan a breakfast rhythm that fits your day."],
          ].map(([step, title, detail]) => (
            <View key={step} style={{ flexDirection: "row", alignItems: "flex-start", gap: 11 }}>
              <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: C.wash, alignItems: "center", justifyContent: "center" }}>
                <Text style={{ color: C.forest, fontSize: 10, fontWeight: "800" }}>{step}</Text>
              </View>
              <View style={{ flex: 1, paddingTop: 2 }}>
                <Text style={{ color: C.ink, fontSize: 13, fontWeight: "700" }}>{title}</Text>
                <Text style={{ color: C.muted, fontSize: 11, lineHeight: 16, marginTop: 2 }}>{detail}</Text>
              </View>
            </View>
          ))}
        </View>
      </Section>

      <Section title="Life OS, in support" caption="A few practical tools around the breakfast habit—not a competing focus.">
        <View style={{ gap: 9 }}>
          {SUPPORT_LINKS.map((link) => (
            <TouchableOpacity
              key={link.route}
              accessibilityRole="button"
              accessibilityLabel={`${link.label}. ${link.detail}`}
              onPress={() => router.push(link.route as Href)}
              style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 12, minHeight: 58, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 13, backgroundColor: C.card, borderWidth: 1, borderColor: C.line }}
            >
              <View style={{ flex: 1 }}>
                <Text style={{ color: C.ink, fontSize: 13, fontWeight: "700" }}>{link.label}</Text>
                <Text style={{ color: C.muted, fontSize: 10, lineHeight: 15, marginTop: 2 }}>{link.detail}</Text>
              </View>
              <Text style={{ color: C.forest, fontSize: 17, fontWeight: "700" }}>›</Text>
            </TouchableOpacity>
          ))}
        </View>
      </Section>

      <Text style={{ color: C.muted, fontSize: 9, lineHeight: 14, textAlign: "center", marginTop: 18 }}>
        Product nutrition figures are supplied as approximate highlights. This app summary does not replace the complete nutrition declaration on the finished pack.
      </Text>

      <IngredientDetailsModal ingredient={selectedIngredient} onClose={() => setSelectedIngredient(null)} />
      <NutritionDetailsModal visible={nutritionOpen} onClose={() => setNutritionOpen(false)} />
    </Page>
  );
}
