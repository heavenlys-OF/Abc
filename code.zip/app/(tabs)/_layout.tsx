import { Feather } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";
import { LifeOSProvider } from "@/lib/life-os/store";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 8 : Math.max(insets.bottom, 8);

  return (
    <LifeOSProvider>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarButton: HapticTab,
          tabBarActiveTintColor: "#526F56",
          tabBarInactiveTintColor: "#8C9088",
          tabBarLabelStyle: { fontSize: 9, fontWeight: "600", marginTop: 1 },
          tabBarStyle: {
            height: 58 + bottomPadding,
            paddingTop: 7,
            paddingBottom: bottomPadding,
            backgroundColor: "#F4EFE5",
            borderTopColor: "#E3DCCE",
            borderTopWidth: 1,
            elevation: 0,
          },
        }}
      >
        <Tabs.Screen name="index" options={{ title: "ABC+", tabBarIcon: ({ color }) => <Feather name="coffee" size={19} color={color} /> }} />
        <Tabs.Screen name="today" options={{ title: "Today", tabBarIcon: ({ color }) => <Feather name="sun" size={19} color={color} /> }} />
        <Tabs.Screen name="week" options={{ title: "Week", tabBarIcon: ({ color }) => <Feather name="calendar" size={19} color={color} /> }} />
        <Tabs.Screen name="capture" options={{ title: "Notes", tabBarIcon: ({ color }) => <Feather name="edit-3" size={18} color={color} /> }} />
        <Tabs.Screen name="habits" options={{ title: "Habits", tabBarIcon: ({ color }) => <Feather name="check-circle" size={19} color={color} /> }} />
        <Tabs.Screen name="month" options={{ title: "Month", tabBarIcon: ({ color }) => <Feather name="refresh-cw" size={18} color={color} /> }} />
      </Tabs>
    </LifeOSProvider>
  );
}
