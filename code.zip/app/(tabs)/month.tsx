import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { CalendarReminderAction } from "@/components/life-os/calendar-reminder-action";
import { AnalysisPanel } from "@/components/life-os/analysis-panel";
import { EntrySubmissionCard } from "@/components/life-os/submission";
import { RemindableField } from "@/components/life-os/remindable-field";
import { C, Page, Section } from "@/components/life-os/ui";
import { suggestedReminderStartDate } from "@/lib/calendar/reminder";
import { analyzeMonth } from "@/lib/life-os/analysis";
import { localMonthKey, useLifeOS } from "@/lib/life-os/store";

export default function MonthScreen() {
  const { month, updateReview } = useLifeOS();
  const review = month.review;
  const monthName = new Date().toLocaleDateString(undefined, { month: "long", year: "numeric" });
  const monthKey = localMonthKey();
  const analysis = analyzeMonth(month);

  return (
    <Page title="Monthly review" kicker={monthName.toUpperCase()} subtitle="Reflect · learn · improve · grow">
      <AnalysisPanel title="This month's response analysis" insight={analysis} />

      <Section title="What went well?" caption="Celebrate your wins, big or small." color={C.wash}>
        <RemindableField value={review.well} onChange={(well) => updateReview({ well })} placeholder="Give the good its due…" multiline reminderPrefix="Monthly reflection: what went well" />
      </Section>

      <Section title="What didn't work?">
        <RemindableField value={review.notWorking} onChange={(notWorking) => updateReview({ notWorking })} placeholder="What would you like to understand better?" multiline reminderPrefix="Monthly reflection: what did not work" />
      </Section>

      <Section title="Biggest lesson">
        <RemindableField value={review.lesson} onChange={(lesson) => updateReview({ lesson })} placeholder="What are you taking with you?" multiline reminderPrefix="Monthly lesson" />
        <RemindableField label="WHAT DID I LEARN ABOUT MYSELF?" value={review.learned} onChange={(learned) => updateReview({ learned })} placeholder="Notice what helped you keep going…" multiline reminderPrefix="Monthly self-reflection" />
      </Section>

      <Section title="What will I change next month?">
        <RemindableField value={review.change} onChange={(change) => updateReview({ change })} placeholder="One gentle adjustment…" multiline reminderPrefix="Next-month change" defaultStartDate={suggestedReminderStartDate(1)} />
      </Section>

      <Section title="Next month's focus" caption="One area to give a little more attention.">
        <RemindableField value={review.nextFocus} onChange={(nextFocus) => updateReview({ nextFocus })} placeholder="An intention to carry forward…" multiline reminderPrefix="Next-month focus" defaultStartDate={suggestedReminderStartDate(1)} />
      </Section>

      <Section title="How was this month for you?" caption="A score is a snapshot, not a verdict.">
        <View style={{ flexDirection: "row", justifyContent: "space-between", paddingVertical: 8 }}>
          {[1, 2, 3, 4, 5].map((rating) => {
            const selected = review.rating === rating;
            return (
              <TouchableOpacity
                key={rating}
                accessibilityRole="radio"
                accessibilityLabel={`Rate this month ${rating} out of 5`}
                accessibilityState={{ selected }}
                onPress={() => updateReview({ rating })}
                style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: selected ? C.sage : "#F2EEE5", alignItems: "center", justifyContent: "center" }}
              >
                <Text style={{ color: selected ? "white" : C.ink, fontWeight: "700", fontSize: 17 }}>{rating}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
        <CalendarReminderAction title="Monthly review check-in" notes="Return to the monthly review, rating and gratitude prompts." defaultStartDate={suggestedReminderStartDate(30)} compact />
      </Section>

      <Section title="Three things I'm grateful for" caption="There is room here for the ordinary good.">
        {review.gratitude.map((entry, index) => (
          <RemindableField
            key={index}
            accessibilityLabel={`Monthly gratitude ${index + 1}`}
            value={entry}
            onChange={(value) => {
              const gratitude = [...review.gratitude];
              gratitude[index] = value;
              updateReview({ gratitude });
            }}
            placeholder="Something I'm grateful for…"
            reminderPrefix={`Monthly gratitude ${index + 1}`}
          />
        ))}
      </Section>

      <EntrySubmissionCard entry={{
        type: "month_review",
        periodKey: monthKey,
        recordKey: monthKey,
        payload: review,
      }} />
    </Page>
  );
}
