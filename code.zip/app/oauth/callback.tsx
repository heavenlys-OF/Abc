import { ThemedView } from "@/components/themed-view";
import { verifyNativeOAuthState } from "@/constants/oauth";
import * as Api from "@/lib/_core/api";
import * as Auth from "@/lib/_core/auth";
import { useAuth } from "@/hooks/use-auth";
import * as Linking from "expo-linking";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Text } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function OAuthCallback() {
  const router = useRouter();
  const { beginSignIn, refresh } = useAuth();
  const params = useLocalSearchParams<{ code?: string; state?: string; error?: string }>();
  const handled = useRef(false);
  const [status, setStatus] = useState<"processing" | "success" | "error">("processing");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (handled.current) return;
    handled.current = true;

    const handleCallback = async () => {
      try {
        let code = params.code ?? null;
        let state = params.state ?? null;
        let error = params.error ?? null;

        if (!code || !state) {
          const initialUrl = await Linking.getInitialURL();
          if (initialUrl) {
            const url = new URL(initialUrl);
            code = code ?? url.searchParams.get("code");
            state = state ?? url.searchParams.get("state");
            error = error ?? url.searchParams.get("error");
          }
        }

        if (error) throw new Error("Sign-in was cancelled or could not be completed.");
        if (!code || !state) throw new Error("The sign-in callback is missing its code or state.");
        if (!(await verifyNativeOAuthState(state))) {
          throw new Error("The sign-in request expired or could not be verified. Please try again.");
        }

        const result = await Api.exchangeOAuthCode(code, state);
        if (!result.sessionToken) throw new Error("No session was returned. Please try again.");
        if (!result.user?.openId || !Number.isSafeInteger(result.user.id) || result.user.id <= 0) {
          throw new Error("The returned account could not be verified. Please try signing in again.");
        }
        beginSignIn();
        await Auth.setSessionToken(result.sessionToken);

        if (result.user) {
          await Auth.setUserInfo({
            id: result.user.id,
            openId: result.user.openId,
            name: result.user.name,
            email: result.user.email,
            loginMethod: result.user.loginMethod,
            lastSignedIn: new Date(result.user.lastSignedIn || Date.now()),
          });
        }

        if (!(await refresh())) {
          throw new Error("Sign-in returned, but the session could not be verified. Check your connection and try again.");
        }

        setStatus("success");
        setTimeout(() => router.replace("/(tabs)"), 700);
      } catch (error) {
        setStatus("error");
        setErrorMessage(error instanceof Error ? error.message : "Sign-in could not be completed.");
      }
    };

    void handleCallback();
  }, [params.code, params.state, params.error, router, beginSignIn, refresh]);

  return (
    <SafeAreaView className="flex-1" edges={["top", "bottom", "left", "right"]}>
      <ThemedView className="flex-1 items-center justify-center gap-4 p-5">
        {status === "processing" && (
          <>
            <ActivityIndicator size="large" />
            <Text className="mt-4 text-base leading-6 text-center text-foreground">
              Completing sign-in securely…
            </Text>
          </>
        )}
        {status === "success" && (
          <>
            <Text className="text-base leading-6 text-center text-foreground">You’re signed in.</Text>
            <Text className="text-base leading-6 text-center text-foreground">Returning to your day…</Text>
          </>
        )}
        {status === "error" && (
          <>
            <Text className="mb-2 text-xl font-bold leading-7 text-error">Sign-in didn’t finish</Text>
            <Text className="text-base leading-6 text-center text-foreground">{errorMessage}</Text>
          </>
        )}
      </ThemedView>
    </SafeAreaView>
  );
}
