import { describe, expect, it } from "vitest";
import {
  createOAuthState,
  isAllowedNativeRedirectUri,
  nonceMatches,
  parseOAuthState,
} from "../server/_core/oauth-state";

describe("OAuth state", () => {
  it("encodes and decodes a callback URI with a high-entropy nonce", () => {
    const redirectUri = "https://3000-preview.example.test/api/oauth/callback";
    const { state, nonce } = createOAuthState(redirectUri);
    expect(parseOAuthState(state)).toEqual({ redirectUri, nonce });
    expect(nonce).toMatch(/^[a-f0-9]{64}$/);
  });

  it("rejects malformed, oversized, and incomplete state values", () => {
    expect(parseOAuthState("not-base64" )).toBeNull();
    expect(parseOAuthState(Buffer.from(JSON.stringify({ redirectUri: "https://example.test" })).toString("base64"))).toBeNull();
    expect(parseOAuthState("x".repeat(4_097))).toBeNull();
  });

  it("matches a state nonce only against the initiating one", () => {
    const nonce = "a".repeat(64);
    expect(nonceMatches(nonce, nonce)).toBe(true);
    expect(nonceMatches(undefined, nonce)).toBe(false);
    expect(nonceMatches("b".repeat(64), nonce)).toBe(false);
  });

  it("allows only this app deep link or an Expo Go callback shape", () => {
    expect(isAllowedNativeRedirectUri("manus279064181439197://oauth/callback")).toBe(true);
    expect(isAllowedNativeRedirectUri("exp://192.168.1.20:8081/--/oauth/callback")).toBe(true);
    expect(isAllowedNativeRedirectUri("https://attacker.example/callback")).toBe(false);
    expect(isAllowedNativeRedirectUri("manus279064181439197://oauth/callback?next=https://evil.test")).toBe(false);
  });
});
