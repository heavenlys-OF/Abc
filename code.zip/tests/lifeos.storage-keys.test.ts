import { describe, expect, it } from "vitest";
import { ANONYMOUS_LIFEOS_STORAGE_KEY, lifeOSStorageKey } from "../lib/life-os/storage-keys";

describe("Life OS local draft namespaces", () => {
  it("keeps each verified account separate from other accounts and anonymous drafts", () => {
    expect(lifeOSStorageKey(101)).toBe("simpleos.v2.user.101");
    expect(lifeOSStorageKey(202)).toBe("simpleos.v2.user.202");
    expect(lifeOSStorageKey(101)).not.toBe(lifeOSStorageKey(202));
    expect(lifeOSStorageKey(101)).not.toBe(ANONYMOUS_LIFEOS_STORAGE_KEY);
  });

  it("uses the anonymous namespace when there is no valid verified user id", () => {
    expect(lifeOSStorageKey(null)).toBe(ANONYMOUS_LIFEOS_STORAGE_KEY);
    expect(lifeOSStorageKey(undefined)).toBe(ANONYMOUS_LIFEOS_STORAGE_KEY);
    expect(lifeOSStorageKey(0)).toBe(ANONYMOUS_LIFEOS_STORAGE_KEY);
    expect(lifeOSStorageKey(Number.NaN)).toBe(ANONYMOUS_LIFEOS_STORAGE_KEY);
  });
});
