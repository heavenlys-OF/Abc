import { describe, expect, it } from "vitest";
import {
  buildCalendarIcs,
  escapeIcsText,
  formatIcsUtc,
  prepareCalendarReminder,
  suggestedReminderStartDate,
} from "../lib/calendar/reminder-utils";

describe("calendar reminder preparation", () => {
  it("uses a future next-hour time for a same-day suggestion", () => {
    const now = new Date(2026, 10, 9, 15, 42, 30);
    const start = suggestedReminderStartDate(now);
    expect(start.getFullYear()).toBe(2026);
    expect(start.getMonth()).toBe(10);
    expect(start.getDate()).toBe(9);
    expect(start.getHours()).toBe(16);
    expect(start.getMinutes()).toBe(0);
  });

  it("moves a late-night same-day suggestion to the next morning", () => {
    const now = new Date(2026, 10, 9, 22, 20, 0);
    const start = suggestedReminderStartDate(now);
    expect(start.getDate()).toBe(10);
    expect(start.getHours()).toBe(9);
  });

  it("prepares a 30-minute event and preserves the user's note in the calendar draft", () => {
    const start = new Date("2026-11-10T09:00:00.000Z");
    const draft = prepareCalendarReminder(
      { title: "  Morning focus  ", notes: "Review priorities", startDate: start },
      new Date("2026-11-09T12:00:00.000Z"),
    );
    expect(draft.title).toBe("Morning focus");
    expect(draft.startDate).toEqual(start);
    expect(draft.endDate.getTime() - draft.startDate.getTime()).toBe(30 * 60_000);
    expect(draft.notes).toContain("Review priorities");
  });
});

describe("calendar .ics export", () => {
  it("escapes separators and line breaks in calendar text", () => {
    expect(escapeIcsText("one,two; three\\four\nfive")).toBe("one\\,two\\; three\\\\four\\nfive");
  });

  it("includes a valid UTC event, context, and an alert at the event start", () => {
    const startDate = new Date("2026-11-10T09:00:00.000Z");
    const draft = prepareCalendarReminder({
      title: "Plan, review",
      notes: "Focus on one task; take a break.",
      startDate,
    });
    const ics = buildCalendarIcs(draft, new Date("2026-11-09T12:00:00.000Z"), "test@simple-life-os");
    expect(ics).toContain("UID:test@simple-life-os\r\n");
    expect(ics).toContain(`DTSTAMP:${formatIcsUtc(new Date("2026-11-09T12:00:00.000Z"))}`);
    expect(ics).toContain(`DTSTART:${formatIcsUtc(startDate)}`);
    expect(ics).toContain("SUMMARY:Plan\\, review");
    expect(ics).toContain("DESCRIPTION:Focus on one task\\; take a break.");
    expect(ics).toContain("TRIGGER:PT0M");
    expect(ics.endsWith("END:VCALENDAR\r\n")).toBe(true);
  });
});
