import { describe, expect, it } from "vitest";
import { analyzeDaily, analyzeMonth, analyzeWeekly } from "../lib/life-os/analysis";
import { submitProductivityEntrySchema } from "../shared/productivity";

function makeDailyEntry() {
  return {
    focus: "",
    priorities: ["", "", ""],
    quickTasks: Array.from({ length: 5 }, () => ({ text: "", done: false })),
    completedHabits: [] as string[],
    notes: "",
    gratitude: ["", "", ""],
    tomorrow: "",
  };
}
function makeWeeklyEntry() {
  return {
    goal: "",
    outcomes: ["", "", ""],
    mustDos: Array.from({ length: 5 }, () => ({ text: "", done: false })),
    avoiding: "",
    fixing: "",
    drained: "",
    energized: "",
  };
}
function makeMonthEntry() {
  return {
    focus: "",
    habits: [] as { id: string; name: string; startDay: number }[],
    checks: {} as Record<string, boolean>,
    review: {
      well: "", notWorking: "", lesson: "", learned: "", change: "", nextFocus: "",
      rating: null as number | null,
      gratitude: ["", "", ""],
    },
  };
}

describe("Simple Life OS response analysis", () => {
  it("reports daily task, habit, focus, and reflection inputs without inventing completion", () => {
    const entry = makeDailyEntry();
    entry.focus = "Finish the proposal";
    entry.priorities[0] = "Send the outline";
    entry.quickTasks[0] = { text: "Write outline", done: true };
    entry.quickTasks[1] = { text: "Send draft", done: false };
    entry.completedHabits = ["Water", "Reading", "Unlisted routine"];
    entry.gratitude[0] = "A quiet morning";
    entry.tomorrow = "Open the draft";

    const result = analyzeDaily(entry);
    expect(result.metrics.find((metric) => metric.label === "Quick tasks")).toMatchObject({ value: "1/2", progress: 0.5 });
    expect(result.metrics.find((metric) => metric.label === "Habits")).toMatchObject({ value: "2/5", progress: 0.4 });
    expect(result.metrics.find((metric) => metric.label === "Reflection")).toMatchObject({ value: "2/4", progress: 0.5 });
    expect(result.metrics.find((metric) => metric.label === "Priorities")?.value).toBe("1/3");
    expect(result.summary).toContain("Focus set · 1/3 priorities");
    expect(result.summary).toContain("2/4 reflection cues");
  });

  it("summarizes weekly outcomes, must-dos and energy responses", () => {
    const entry = makeWeeklyEntry();
    entry.goal = "Protect two focus blocks";
    entry.outcomes[0] = "Finish the draft";
    entry.mustDos[0] = { text: "Outline", done: true };
    entry.mustDos[1] = { text: "Review", done: false };
    entry.energized = "A morning walk";

    const result = analyzeWeekly(entry);
    expect(result.headline).toBe("Your week has a direction");
    expect(result.metrics.find((metric) => metric.label === "Must-dos")?.value).toBe("1/2");
    expect(result.metrics.find((metric) => metric.label === "Outcomes")?.value).toBe("1/3");
    expect(result.metrics.find((metric) => metric.label === "Energy notes")?.value).toBe("1/2");
  });

  it("measures month-to-date habit check-ins fairly from each habit's start day", () => {
    const entry = makeMonthEntry();
    entry.focus = "Move gently";
    entry.habits = [
      { id: "water", name: "Water", startDay: 1 },
      { id: "walk", name: "Walk", startDay: 3 },
      { id: "empty", name: "  ", startDay: 5 },
    ];
    entry.checks = { "water-1": true, "water-2": true, "walk-3": true };
    entry.review.rating = 4;

    const result = analyzeMonth(entry, new Date(2026, 9, 5));
    expect(result.metrics.find((metric) => metric.label === "Check-ins")).toMatchObject({ value: "3/8", progress: 3 / 8 });
    expect(result.metrics.find((metric) => metric.label === "Month rating")).toMatchObject({ value: "4/5", progress: 0.8 });
    expect(result.metrics.find((metric) => metric.label === "Monthly focus")?.value).toBe("Set");
    expect(result.habits).toHaveLength(2);
  });

  it("does not treat a blank added habit row as a started tracker", () => {
    const entry = makeMonthEntry();
    entry.habits = [{ id: "empty", name: "   ", startDay: 5 }];
    const result = analyzeMonth(entry, new Date(2026, 9, 5));
    expect(result.headline).toBe("Make room for one small habit");
    expect(result.habits).toHaveLength(0);
    expect(result.metrics.find((metric) => metric.label === "Check-ins")?.value).toBe("0/0");
  });
});

describe("productivity repository payload validation", () => {
  it("accepts a correctly keyed daily submission", () => {
    const result = submitProductivityEntrySchema.safeParse({
      type: "daily",
      periodKey: "2026-10-13",
      recordKey: "2026-10-13",
      payload: makeDailyEntry(),
    });
    expect(result.success).toBe(true);
    expect(submitProductivityEntrySchema.safeParse({
      type: "daily", periodKey: "2026-10-13", recordKey: "2026-10-13", payload: { ...makeDailyEntry(), completedHabits: ["Unlisted routine"] },
    }).success).toBe(false);
  });

  it("rejects invalid dates and oversized/extra payload fields", () => {
    const daily = makeDailyEntry();
    expect(submitProductivityEntrySchema.safeParse({
      type: "daily", periodKey: "2026-02-30", recordKey: "2026-02-30", payload: daily,
    }).success).toBe(false);
    expect(submitProductivityEntrySchema.safeParse({
      type: "daily", periodKey: "2026-10-13", recordKey: "2026-10-13", payload: { ...daily, privateOverride: true },
    }).success).toBe(false);
    expect(submitProductivityEntrySchema.safeParse({
      type: "daily", periodKey: "2026-10-13", recordKey: "2026-10-14", payload: daily,
    }).success).toBe(false);
    expect(submitProductivityEntrySchema.safeParse({
      type: "brain_dump", periodKey: "2026-11", recordKey: "note-1", payload: { text: "A note", createdAt: "2026-10-31T23:59:00.000Z", timezoneOffsetMinutes: 0 },
    }).success).toBe(false);
  });

  it("accepts a local-month-boundary note using its captured timezone offset", () => {
    expect(submitProductivityEntrySchema.safeParse({
      type: "brain_dump",
      periodKey: "2026-11",
      recordKey: "note-local-midnight",
      payload: { text: "A note", createdAt: "2026-10-31T18:45:00.000Z", timezoneOffsetMinutes: -330 },
    }).success).toBe(true);
  });

  it("accepts Monday weekly keys and rejects dates inside the week", () => {
    const payload = makeWeeklyEntry();
    expect(submitProductivityEntrySchema.safeParse({ type: "weekly", periodKey: "2026-10-12", recordKey: "2026-10-12", payload }).success).toBe(true);
    expect(submitProductivityEntrySchema.safeParse({ type: "weekly", periodKey: "2026-10-14", recordKey: "2026-10-14", payload }).success).toBe(false);
  });

  it("accepts monthly check-ins only for listed habits and valid month days after their start day", () => {
    const valid = {
      type: "habit_month",
      periodKey: "2026-02",
      recordKey: "2026-02",
      payload: {
        focus: "Read each day",
        habits: [{ id: "habit-123", name: "Reading", startDay: 2 }],
        checks: { "habit-123-2": true, "habit-123-28": false },
      },
    };
    expect(submitProductivityEntrySchema.safeParse(valid).success).toBe(true);
    expect(submitProductivityEntrySchema.safeParse({ ...valid, payload: { ...valid.payload, checks: { "other-2": true } } }).success).toBe(false);
    expect(submitProductivityEntrySchema.safeParse({ ...valid, payload: { ...valid.payload, checks: { "habit-123-1": true } } }).success).toBe(false);
    expect(submitProductivityEntrySchema.safeParse({ ...valid, payload: { ...valid.payload, checks: { "habit-123-29": true } } }).success).toBe(false);
  });
});
