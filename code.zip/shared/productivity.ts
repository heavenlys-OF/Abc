import { z } from "zod";
import { DAILY_HABIT_NAMES, monthKeyAtOffset } from "./lifeos";

export const PRODUCTIVITY_ENTRY_TYPES = [
  "daily",
  "weekly",
  "brain_dump",
  "habit_month",
  "month_review",
] as const;

export const productivityEntryTypeSchema = z.enum(PRODUCTIVITY_ENTRY_TYPES);

function isValidDayKey(value: string): boolean {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const [, year, month, day] = match.map(Number) as unknown as [number, number, number, number];
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

function daysInMonthKey(value: string): number {
  const [year, month] = value.split("-").map(Number);
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function isValidWeekKey(value: string): boolean {
  if (!isValidDayKey(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay() === 1;
}

const dayKey = z.string().refine(isValidDayKey, "Use a valid YYYY-MM-DD date.");
const weekKey = z.string().refine(isValidWeekKey, "A weekly period must start on Monday.");
const monthKey = z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Use a valid YYYY-MM month.");
const shortText = z.string().max(500);
const reflectionText = z.string().max(2_000);
const taskSchema = z.object({ text: shortText, done: z.boolean() }).strict();
const dailyHabitNameSchema = z.enum(DAILY_HABIT_NAMES);

export const dailyPayloadSchema = z.object({
  focus: z.string().max(2_000),
  priorities: z.array(shortText).length(3),
  quickTasks: z.array(taskSchema).max(5),
  completedHabits: z.array(dailyHabitNameSchema).max(5).refine((habits) => new Set(habits).size === habits.length, "Daily habits must be unique."),
  notes: z.string().max(5_000),
  gratitude: z.array(z.string().max(300)).max(3),
  tomorrow: z.string().max(1_000),
}).strict();

export const weeklyPayloadSchema = z.object({
  goal: reflectionText,
  outcomes: z.array(shortText).length(3),
  mustDos: z.array(taskSchema).max(5),
  avoiding: reflectionText,
  fixing: reflectionText,
  drained: reflectionText,
  energized: reflectionText,
}).strict();

export const brainDumpPayloadSchema = z.object({
  text: z.string().trim().min(1).max(5_000),
  createdAt: z.string().datetime(),
  /** JavaScript Date.getTimezoneOffset() value: UTC minus local time, in minutes. */
  timezoneOffsetMinutes: z.number().int().min(-840).max(840),
}).strict();

export const habitMonthPayloadSchema = z.object({
  focus: reflectionText,
  habits: z.array(z.object({
    id: z.string().min(1).max(64),
    name: z.string().max(120),
    startDay: z.number().int().min(1).max(31),
  }).strict()).max(5),
  checks: z.record(z.string().max(100), z.boolean()).refine((value) => Object.keys(value).length <= 155, "A month can contain at most 155 habit check-ins."),
}).strict();

export const monthReviewPayloadSchema = z.object({
  well: reflectionText,
  notWorking: reflectionText,
  lesson: reflectionText,
  learned: reflectionText,
  change: reflectionText,
  nextFocus: reflectionText,
  rating: z.number().int().min(1).max(5).nullable(),
  gratitude: z.array(z.string().max(300)).max(3),
}).strict();

const baseSubmitProductivityEntrySchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("daily"), periodKey: dayKey, recordKey: dayKey, payload: dailyPayloadSchema }).strict(),
  z.object({ type: z.literal("weekly"), periodKey: weekKey, recordKey: weekKey, payload: weeklyPayloadSchema }).strict(),
  z.object({ type: z.literal("brain_dump"), periodKey: monthKey, recordKey: z.string().regex(/^[A-Za-z0-9_-]{1,64}$/), payload: brainDumpPayloadSchema }).strict(),
  z.object({ type: z.literal("habit_month"), periodKey: monthKey, recordKey: monthKey, payload: habitMonthPayloadSchema }).strict(),
  z.object({ type: z.literal("month_review"), periodKey: monthKey, recordKey: monthKey, payload: monthReviewPayloadSchema }).strict(),
]);

export const submitProductivityEntrySchema = baseSubmitProductivityEntrySchema.superRefine((entry, context) => {
  if ((entry.type === "daily" || entry.type === "weekly" || entry.type === "habit_month" || entry.type === "month_review") && entry.periodKey !== entry.recordKey) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["recordKey"], message: "The record key must match its day or month period." });
  }

  if (entry.type === "brain_dump") {
    const createdAt = new Date(entry.payload.createdAt);
    const localMonth = monthKeyAtOffset(createdAt, entry.payload.timezoneOffsetMinutes);
    if (localMonth !== entry.periodKey) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["payload", "createdAt"], message: "The note timestamp and time-zone offset must match its local archive month." });
    }
    return;
  }

  if (entry.type !== "habit_month") return;

  const validDays = daysInMonthKey(entry.periodKey);
  const habitById = new Map<string, { startDay: number }>();
  entry.payload.habits.forEach((habit, index) => {
    if (habitById.has(habit.id)) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["payload", "habits", index, "id"], message: "Habit IDs must be unique within a month." });
    } else {
      habitById.set(habit.id, habit);
    }
    if (habit.startDay > validDays) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["payload", "habits", index, "startDay"], message: "The habit start day must exist in this month." });
    }
  });

  for (const checkKey of Object.keys(entry.payload.checks)) {
    const separator = checkKey.lastIndexOf("-");
    const habitId = separator > 0 ? checkKey.slice(0, separator) : "";
    const dayText = separator > 0 ? checkKey.slice(separator + 1) : "";
    const day = Number(dayText);
    const habit = habitById.get(habitId);
    if (!habit || !/^(?:[1-9]|[12]\d|3[01])$/.test(dayText)) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["payload", "checks", checkKey], message: "Each check-in must reference a listed habit and a valid day." });
      continue;
    }
    if (day > validDays || day < habit.startDay) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["payload", "checks", checkKey], message: "Each check-in must fall within the month and on or after the habit start day." });
    }
  }
});

export type ProductivityEntryType = z.infer<typeof productivityEntryTypeSchema>;
export type SubmitProductivityEntry = z.infer<typeof submitProductivityEntrySchema>;
