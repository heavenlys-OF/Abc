export type NutritionFact = {
  label: string;
  amount: string;
  rda?: string;
  indent?: boolean;
};

export const ABC_PLUS_NUTRITION = {
  servingGrams: 50,
  packSachets: 7,
  packNetWeightGrams: 350,
  energyKcal: 219,
  energyRda: "11%",
  palmSugarIngredientGrams: 0.53,
  macros: [
    { label: "Protein", amount: "8.5 g", rda: "16%" },
    { label: "Total fat", amount: "5.1 g", rda: "8%" },
    { label: "Saturated fat", amount: "0.9 g", rda: "4%", indent: true },
    { label: "MUFA + PUFA", amount: "4.0 g", rda: "—", indent: true },
    { label: "Carbohydrate", amount: "33.0 g", rda: "11%" },
    { label: "Naturally occurring sugars", amount: "9.6 g", rda: "—", indent: true },
    { label: "Added sugar (from palm sugar)", amount: "0.53 g", rda: "1%", indent: true },
    { label: "Dietary fibre", amount: "4.8 g", rda: "16%" },
    { label: "Sodium", amount: "22 mg", rda: "1%" },
  ] satisfies readonly NutritionFact[],
  vitaminsAndMinerals: [
    { label: "Calcium", amount: "82 mg", rda: "8%" },
    { label: "Iron", amount: "3.2 mg", rda: "18%" },
    { label: "Magnesium", amount: "96 mg", rda: "23%" },
    { label: "Phosphorus", amount: "208 mg", rda: "30%" },
    { label: "Potassium", amount: "310 mg", rda: "9%" },
    { label: "Zinc", amount: "1.9 mg", rda: "17%" },
    { label: "Vitamin A (from beta-carotene)", amount: "410 μg", rda: "46%" },
    { label: "Folate (B9)", amount: "54 μg", rda: "14%" },
    { label: "Vitamin E", amount: "3.8 mg", rda: "25%" },
    { label: "Vitamin B1 (Thiamine)", amount: "0.31 mg", rda: "26%" },
    { label: "Vitamin B3 (Niacin)", amount: "3.4 mg", rda: "21%" },
    { label: "Vitamin B6", amount: "0.28 mg", rda: "20%" },
  ] satisfies readonly NutritionFact[],
  note:
    "Brand-supplied approximate values per 50 g serving; natural ingredient variation may affect values. RDA percentages are as shown in the latest product poster, based on ICMR 2020 for an average adult diet of 2,000 kcal. Refer to the finished pack for the complete nutrition declaration.",
  sugarNote:
    "The latest product panel lists 9.6 g naturally occurring sugars and 0.53 g added sugar from palm sugar per 50 g sachet. Palm sugar is an ingredient, so ABC+ is not described as having no added sugar.",
} as const;
