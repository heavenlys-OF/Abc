export const DAILY_HABIT_NAMES = ["Water", "Exercise", "Reading", "Meditation", "Deep Work"] as const;

/** Convert a UTC instant to the calendar month in the timezone captured at entry time. */
export function monthKeyAtOffset(instant: Date, timezoneOffsetMinutes: number): string {
  const local = new Date(instant.getTime() - timezoneOffsetMinutes * 60_000);
  return `${local.getUTCFullYear()}-${String(local.getUTCMonth() + 1).padStart(2, "0")}`;
}
