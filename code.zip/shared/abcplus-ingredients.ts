export type IngredientSource = {
  title: string;
  url: string;
};

export type AbcPlusGroupId =
  | "fruit-roots"
  | "grains-millets"
  | "pulses"
  | "seeds"
  | "flavour-sweetener";

export type AbcPlusIngredient = {
  name: string;
  batchWeightKg: number;
  amountPer100g: number;
  amountPer50g: number;
  group: AbcPlusGroupId;
  noteTitle: string;
  generalContext: string;
  sources: readonly IngredientSource[];
  sourceContextNote?: string;
};

type IngredientSpec = Omit<AbcPlusIngredient, "amountPer100g" | "amountPer50g">;

const ingredientSpecs: readonly IngredientSpec[] = [
  {
    name: "Apple powder",
    batchWeightKg: 3.0,
    group: "fruit-roots",
    noteTitle: "Fruit ingredient",
    generalContext:
      "Whole apples provide dietary fibre and naturally occurring sugars. Drying changes moisture and can alter some nutrient levels; this powder’s composition depends on how it is made.",
    sources: [
      { title: "Harvard Nutrition Source — Apples", url: "https://nutritionsource.hsph.harvard.edu/food-features/apples/" },
      { title: "USDA FoodData Central — Apples", url: "https://fdc.nal.usda.gov/food-search?query=apples" },
    ],
  },
  {
    name: "Beetroot powder",
    batchWeightKg: 3.0,
    group: "fruit-roots",
    noteTitle: "Root-vegetable ingredient",
    generalContext:
      "Beetroot generally contains carbohydrate and dietary fibre, along with naturally occurring nitrate and betalain pigments. These are general food facts, not measurements of this powder.",
    sources: [
      { title: "Beetroot composition review", url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC8565237/" },
      { title: "Beetroot bioactive-compounds review", url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC8229785/" },
    ],
  },
  {
    name: "Carrot powder",
    batchWeightKg: 3.0,
    group: "fruit-roots",
    noteTitle: "Root-vegetable ingredient",
    generalContext:
      "Studies of particular whole-carrot powders report dietary fibre, naturally occurring sugars and beta-carotene. Amounts vary with variety, growing conditions, storage and processing; those studies do not measure this ABC+ powder.",
    sources: [
      { title: "Nutrient-Dense Shelf-Stable Vegetable Powders", url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC8535146/" },
      { title: "USDA FoodData Central — Carrots", url: "https://fdc.nal.usda.gov/food-search?query=carrot" },
    ],
  },
  {
    name: "Bengal gram",
    batchWeightKg: 17.0,
    group: "pulses",
    noteTitle: "Pulse ingredient",
    generalContext:
      "Bengal gram is chickpea-based. General chickpea references describe plant protein, carbohydrate and dietary fibre. They do not establish the exact form or nutrient contribution of this ingredient in the finished blend.",
    sources: [
      { title: "Indian Food Composition Tables 2017", url: "https://www.nin.res.in/ebooks/IFCT2017.pdf" },
      { title: "FAO — Pulses and their nutritional benefits", url: "https://www.fao.org/pulses-2016/news/news-detail/en/c/429320/" },
    ],
  },
  {
    name: "Oats",
    batchWeightKg: 8.0,
    group: "grains-millets",
    noteTitle: "Grain ingredient",
    generalContext:
      "Oats generally contain dietary fibre, including beta-glucan, and nutrients such as thiamine, phosphorus, magnesium and zinc. The oat form and processing in this blend are not specified, so these references do not give amounts for this ingredient.",
    sources: [
      { title: "Harvard Nutrition Source — Oats", url: "https://nutritionsource.hsph.harvard.edu/food-features/oats/" },
      { title: "Whole-grain oats review", url: "https://pubmed.ncbi.nlm.nih.gov/28067025/" },
      { title: "USDA FoodData Central — Oats", url: "https://fdc.nal.usda.gov/food-search/?query=oats" },
    ],
  },
  {
    name: "Ragi flakes",
    batchWeightKg: 5.0,
    group: "grains-millets",
    noteTitle: "Millet ingredient",
    generalContext:
      "Ragi is finger millet. General grain references describe carbohydrate, dietary fibre, protein and minerals, but they do not establish the composition of these flakes or of the finished blend.",
    sources: [
      { title: "Indian Food Composition Tables 2017", url: "https://www.nin.res.in/ebooks/IFCT2017_16122024.pdf" },
      { title: "FAO — About millets", url: "https://www.fao.org/millets-2023/about/en" },
    ],
    sourceContextNote:
      "The latest formulation says ragi flakes; it does not say sprouted ragi. No germination or phytase-activation benefit is inferred.",
  },
  {
    name: "Samai flakes",
    batchWeightKg: 1.5,
    group: "grains-millets",
    noteTitle: "Millet ingredient",
    generalContext:
      "Samai is little millet. Raw-grain tables and a study of one ready-to-cook flakes product provide general context about carbohydrate, protein and dietary fibre; their values do not measure these flakes or ABC+.",
    sources: [
      { title: "Indian Food Composition Tables 2017", url: "https://www.nin.res.in/ebooks/IFCT2017.pdf" },
      { title: "Little-millet flakes study", url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC4554602/" },
    ],
  },
  {
    name: "Kuthiraivali flakes",
    batchWeightKg: 1.5,
    group: "grains-millets",
    noteTitle: "Barnyard millet ingredient",
    generalContext:
      "Tamil Nadu Agricultural University identifies Kuthiraivali, also transliterated Kudiraivali, as barnyard millet. Barnyard millet grain generally provides carbohydrate and dietary fibre, along with protein; these references do not test the flaked form or this blend.",
    sources: [
      { title: "Tamil Nadu Agricultural University — Kudiraivali", url: "http://www.agritech.tnau.ac.in/agriculture/millets_kudiraivali.html" },
      { title: "Barnyard millet nutrition and processing review", url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC10497464/" },
    ],
    sourceContextNote:
      "The sources confirm the grain-name correspondence, not the specific flaking process or nutrient composition of this ABC+ ingredient.",
  },
  {
    name: "Sunflower seeds",
    batchWeightKg: 3.0,
    group: "seeds",
    noteTitle: "Seed ingredient",
    generalContext:
      "Sunflower seeds generally provide plant protein and contain fat and dietary fibre. Their composition varies with the seed form and preparation, and general food tables do not measure the contribution of this blend’s ingredient.",
    sources: [
      { title: "Indian Food Composition Tables 2017", url: "https://www.nin.res.in/ebooks/IFCT2017_16122024.pdf" },
      { title: "USDA FoodData Central — Sunflower seeds", url: "https://fdc.nal.usda.gov/food-search?query=sunflower%20seeds" },
    ],
    sourceContextNote:
      "The formulation does not specify whether the ingredient is whole seed or kernel, or whether it is raw, roasted or salted.",
  },
  {
    name: "Cocoa powder",
    batchWeightKg: 2.0,
    group: "flavour-sweetener",
    noteTitle: "Cocoa ingredient",
    generalContext:
      "A generic food-composition entry for cocoa powder lists protein, fat, carbohydrate and dietary fibre. It is not a measurement of the cocoa powder used in ABC+.",
    sources: [
      { title: "Matvaretabellen — Cocoa powder", url: "https://www.matvaretabellen.no/en/cocoa-powder/" },
    ],
  },
  {
    name: "Palm sugar",
    batchWeightKg: 0.5,
    group: "flavour-sweetener",
    noteTitle: "Sweetener ingredient",
    generalContext:
      "Palm sugar adds sweetness and is a source of sugars. Its use does not mean that the blend is free of added sugars, and it should not be described as healthier than other sugars.",
    sources: [
      { title: "Palm-sap sugar review", url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC10073893/" },
      { title: "WHO guideline — Sugars intake", url: "https://www.who.int/publications/i/item/9789241549028" },
    ],
    sourceContextNote:
      "The latest formula contributes about 0.53 g of palm-sugar ingredient per 50 g sachet. Refer to the brand-supplied nutrition panel for its separate sugar entries.",
  },
  {
    name: "Cardamom powder",
    batchWeightKg: 0.07,
    group: "flavour-sweetener",
    noteTitle: "Culinary spice",
    generalContext:
      "Cardamom is an aromatic culinary spice used to flavour foods and drinks. The species and colour are not specified, so no product-specific nutrient amount or health effect is claimed.",
    sources: [
      { title: "McCormick Science Institute — Cardamom", url: "https://www.mccormickscienceinstitute.com/resources/culinary-spices/herbs-spices/cardamom" },
      { title: "USDA FoodData Central — Food search", url: "https://fdc.nal.usda.gov/food-search" },
    ],
    sourceContextNote:
      "The formulation specifies powder but not whether it is green or black cardamom.",
  },
];

export const ABC_PLUS_BATCH_TOTAL_KG = ingredientSpecs.reduce(
  (sum, ingredient) => sum + ingredient.batchWeightKg,
  0,
);

export const ABC_PLUS_INGREDIENTS: readonly AbcPlusIngredient[] = ingredientSpecs.map(
  (ingredient) => ({
    ...ingredient,
    amountPer100g: (ingredient.batchWeightKg / ABC_PLUS_BATCH_TOTAL_KG) * 100,
    amountPer50g: (ingredient.batchWeightKg / ABC_PLUS_BATCH_TOTAL_KG) * 50,
  }),
);

const groupTitles: ReadonlyArray<{ id: AbcPlusGroupId; title: string }> = [
  { id: "fruit-roots", title: "Fruit & root powders" },
  { id: "grains-millets", title: "Grains & millets" },
  { id: "pulses", title: "Pulses" },
  { id: "seeds", title: "Seeds" },
  { id: "flavour-sweetener", title: "Natural flavour & sweetener" },
];

export const ABC_PLUS_GROUPS = groupTitles.map((group) => {
  const batchWeightKg = ingredientSpecs
    .filter((ingredient) => ingredient.group === group.id)
    .reduce((sum, ingredient) => sum + ingredient.batchWeightKg, 0);
  return {
    ...group,
    batchWeightKg,
    sharePercent: (batchWeightKg / ABC_PLUS_BATCH_TOTAL_KG) * 100,
  };
});

export type AbcPlusIngredientItem = (typeof ABC_PLUS_INGREDIENTS)[number];
