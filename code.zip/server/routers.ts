import {
  clearPreviousSessionCookie,
  getSessionCookieName,
  getSessionCookieOptions,
} from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { findProductivityEntry, listProductivityEntries, saveProductivityEntry } from "./db";
import { productivityEntryTypeSchema, submitProductivityEntrySchema } from "../shared/productivity";
import { TRPCError } from "@trpc/server";
import { z } from "zod";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(getSessionCookieName(ctx.req), {
        ...cookieOptions,
        maxAge: -1,
      });
      clearPreviousSessionCookie(ctx.req, ctx.res);
      return {
        success: true,
      } as const;
    }),
  }),
  productivity: router({
    submit: protectedProcedure.input(submitProductivityEntrySchema).mutation(async ({ ctx, input }) => {
      if (input.type !== "brain_dump" && input.periodKey !== input.recordKey) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "The record key must match its period." });
      }
      if (Buffer.byteLength(JSON.stringify(input.payload), "utf8") > 50_000) {
        throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "This entry is too large to submit." });
      }
      return saveProductivityEntry(ctx.user.id, input);
    }),
    getOne: protectedProcedure.input(z.object({
      accountId: z.number().int().positive(),
      type: productivityEntryTypeSchema,
      recordKey: z.string().min(1).max(64),
    }).strict()).query(({ ctx, input }) => {
      if (input.accountId !== ctx.user.id) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "The active account changed. Refresh before loading repository entries." });
      }
      return findProductivityEntry(ctx.user.id, input.type, input.recordKey);
    }),
    listMine: protectedProcedure.input(z.object({
      accountId: z.number().int().positive(),
      type: productivityEntryTypeSchema.optional(),
      limit: z.number().int().min(1).max(200).default(100),
    }).strict()).query(({ ctx, input }) => {
      if (input.accountId !== ctx.user.id) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "The active account changed. Refresh before loading repository entries." });
      }
      return listProductivityEntries(ctx.user.id, { entryType: input.type, limit: input.limit });
    }),
  }),
});

export type AppRouter = typeof appRouter;
