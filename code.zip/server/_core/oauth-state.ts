import { randomBytes, timingSafeEqual } from "node:crypto";
import { SESSION_COOKIE_SUFFIX } from "../../shared/const.js";

export const OAUTH_STATE_COOKIE_NAME = "simpleos_oauth_state";
export const OAUTH_STATE_TTL_MS = 10 * 60 * 1000;

export type OAuthStatePayload = { redirectUri: string; nonce: string };

export function createOAuthState(redirectUri: string): { state: string; nonce: string } {
  const nonce = randomBytes(32).toString("hex");
  const state = Buffer.from(JSON.stringify({ redirectUri, nonce }), "utf8").toString("base64");
  return { state, nonce };
}

export function parseOAuthState(state: string): OAuthStatePayload | null {
  if (!state || state.length > 4_096 || !/^[A-Za-z0-9+/]+={0,2}$/.test(state)) return null;
  try {
    const value: unknown = JSON.parse(Buffer.from(state, "base64").toString("utf8"));
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const record = value as Record<string, unknown>;
    if (Object.keys(record).sort().join(",") !== "nonce,redirectUri") return null;
    if (typeof record.redirectUri !== "string" || record.redirectUri.length > 2_048) return null;
    if (typeof record.nonce !== "string" || !/^[a-f0-9]{64}$/.test(record.nonce)) return null;
    return { redirectUri: record.redirectUri, nonce: record.nonce };
  } catch {
    return null;
  }
}

export function nonceMatches(expected: string | undefined, actual: string): boolean {
  if (!expected) return false;
  const expectedBytes = Buffer.from(expected, "utf8");
  const actualBytes = Buffer.from(actual, "utf8");
  return expectedBytes.length === actualBytes.length && timingSafeEqual(expectedBytes, actualBytes);
}

/** Derive public API origin only from platform/app configuration, never the request Host header. */
export function getTrustedPublicApiOrigin(): string | null {
  const explicit = process.env.EXPO_PUBLIC_API_BASE_URL?.trim();
  if (explicit) {
    try {
      const url = new URL(explicit);
      if ((url.protocol === "https:" || url.protocol === "http:") && !url.username && !url.password) return url.origin;
    } catch {
      return null;
    }
  }

  for (const value of [process.env.EXPO_PACKAGER_PROXY_URL, process.env.EXPO_WEB_PREVIEW_URL]) {
    if (!value) continue;
    try {
      const url = new URL(value);
      if ((url.protocol !== "https:" && url.protocol !== "http:") || url.username || url.password) continue;
      const previousHostname = url.hostname;
      const previousPort = url.port;
      url.hostname = url.hostname.replace(/^8081-/, "3000-");
      if (url.port === "8081") url.port = "3000";
      if (url.hostname !== previousHostname || url.port !== previousPort) return url.origin;
    } catch {
      // Ignore malformed optional platform addresses and try the next configured one.
    }
  }
  return null;
}

export function isAllowedNativeRedirectUri(value: string): boolean {
  try {
    const url = new URL(value);
    if (url.username || url.password || url.search || url.hash) return false;
    const projectScheme = `manus${SESSION_COOKIE_SUFFIX}:`;
    const customScheme = url.protocol === projectScheme &&
      (url.hostname === "oauth" || url.hostname === "") &&
      (url.pathname === "/callback" || url.pathname === "/oauth/callback");
    const expoGoScheme = url.protocol === "exp:" &&
      /^[A-Za-z0-9.-]+$/.test(url.hostname) &&
      /^\/(?:--\/)?oauth\/callback$/.test(url.pathname);
    return customScheme || expoGoScheme;
  } catch {
    return false;
  }
}
