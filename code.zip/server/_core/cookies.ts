import { parse as parseCookieHeader } from "cookie";
import type { CookieOptions, Request, Response } from "express";
import { SESSION_COOKIE_SUFFIX } from "../../shared/const.js";

const PREVIEW_SESSION_COOKIE_NAME = "webdev_app_session";

function isSecureRequest(req: Request): boolean {
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}

export function getSessionCookieOptions(
  req: Request,
): Pick<CookieOptions, "httpOnly" | "path" | "sameSite" | "secure"> {
  const secure = isSecureRequest(req);
  return {
    httpOnly: true,
    path: "/",
    sameSite: secure ? "none" : "lax",
    secure,
  };
}

export function getPreviousSessionCookieName(req: Request): string {
  return isSecureRequest(req)
    ? `__Host-manus_session_${SESSION_COOKIE_SUFFIX}`
    : `manus_local_session_${SESSION_COOKIE_SUFFIX}`;
}

export function getSessionCookieName(_req: Request): string {
  return PREVIEW_SESSION_COOKIE_NAME;
}

export function clearPreviousSessionCookie(req: Request, res: Response): void {
  res.clearCookie(getPreviousSessionCookieName(req), {
    ...getSessionCookieOptions(req),
    maxAge: -1,
  });
}

export function currentSessionCookie(req: Request): string | undefined {
  if (!req.headers.cookie) return undefined;
  const cookies = parseCookieHeader(req.headers.cookie);
  return cookies[getSessionCookieName(req)] ?? cookies[getPreviousSessionCookieName(req)];
}
