import { parse as parseCookieHeader } from "cookie";
import { ONE_YEAR_MS } from "../../shared/const.js";
import type { Express, Request, Response } from "express";
import { getUserByOpenId, upsertUser } from "../db";
import { clearPreviousSessionCookie, currentSessionCookie, getSessionCookieName, getSessionCookieOptions } from "./cookies";
import {
  createOAuthState,
  getTrustedPublicApiOrigin,
  isAllowedNativeRedirectUri,
  nonceMatches,
  OAUTH_STATE_COOKIE_NAME,
  OAUTH_STATE_TTL_MS,
  parseOAuthState,
} from "./oauth-state";
import { ENV } from "./env";
import { sdk } from "./sdk";

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

function clearOAuthStateCookie(req: Request, res: Response) {
  res.clearCookie(OAUTH_STATE_COOKIE_NAME, {
    ...getSessionCookieOptions(req),
    maxAge: -1,
  });
}

function getOAuthPortalUrl(): string | null {
  const value = process.env.MANUS_OAUTH_PORTAL_URL ??
    process.env.VITE_OAUTH_PORTAL_URL ??
    process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL;
  if (!value) return null;
  try {
    const url = new URL(value);
    if ((url.protocol !== "https:" && url.protocol !== "http:") || url.username || url.password) return null;
    return url.origin;
  } catch {
    return null;
  }
}

function buildAuthorizationUrl(redirectUri: string, state: string): string {
  const portal = getOAuthPortalUrl();
  if (!portal || !ENV.appId) throw new Error("OAuth configuration is unavailable");
  const url = new URL("/app-auth", portal);
  url.searchParams.set("appId", ENV.appId);
  url.searchParams.set("redirectUri", redirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("responseType", "code");
  url.searchParams.set("type", "signIn");
  return url.toString();
}

async function syncUser(userInfo: {
  openId?: string | null;
  name?: string | null;
  email?: string | null;
  loginMethod?: string | null;
  platform?: string | null;
}) {
  if (!userInfo.openId) {
    throw new Error("openId missing from user info");
  }

  const lastSignedIn = new Date();
  await upsertUser({
    openId: userInfo.openId,
    name: userInfo.name || null,
    email: userInfo.email ?? null,
    loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
    lastSignedIn,
  });
  const saved = await getUserByOpenId(userInfo.openId);
  return (
    saved ?? {
      openId: userInfo.openId,
      name: userInfo.name,
      email: userInfo.email,
      loginMethod: userInfo.loginMethod ?? null,
      lastSignedIn,
    }
  );
}

function buildUserResponse(
  user:
    | Awaited<ReturnType<typeof getUserByOpenId>>
    | {
        openId: string;
        name?: string | null;
        email?: string | null;
        loginMethod?: string | null;
        lastSignedIn?: Date | null;
      },
) {
  return {
    id: (user as any)?.id ?? null,
    openId: user?.openId ?? null,
    name: user?.name ?? null,
    email: user?.email ?? null,
    loginMethod: user?.loginMethod ?? null,
    lastSignedIn: (user?.lastSignedIn ?? new Date()).toISOString(),
  };
}

export function registerOAuthRoutes(app: Express) {
  app.get("/api/oauth/start", (req: Request, res: Response) => {
    const platform = getQueryParam(req, "platform");
    if (platform !== "web" && platform !== "native") {
      res.status(400).json({ error: "A supported sign-in platform is required." });
      return;
    }

    let redirectUri: string;
    if (platform === "web") {
      const apiOrigin = getTrustedPublicApiOrigin();
      if (!apiOrigin) {
        res.status(503).json({ error: "The public sign-in address is unavailable." });
        return;
      }
      redirectUri = `${apiOrigin}/api/oauth/callback`;
    } else {
      redirectUri = getQueryParam(req, "redirectUri") ?? "";
      if (!redirectUri || !isAllowedNativeRedirectUri(redirectUri)) {
        res.status(400).json({ error: "The native sign-in callback is not allowed." });
        return;
      }
    }

    try {
      const { state, nonce } = createOAuthState(redirectUri);
      const authorizationUrl = buildAuthorizationUrl(redirectUri, state);
      res.setHeader("Cache-Control", "no-store");
      if (platform === "web") {
        res.cookie(OAUTH_STATE_COOKIE_NAME, nonce, {
          ...getSessionCookieOptions(req),
          maxAge: OAUTH_STATE_TTL_MS,
        });
        res.json({ authorizationUrl });
      } else {
        res.json({ authorizationUrl, nonce });
      }
    } catch {
      console.error("[OAuth] Sign-in initialization failed");
      res.status(503).json({ error: "Manus sign-in could not be started." });
    }
  });

  app.get("/api/oauth/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");

    if (!code || !state) {
      clearOAuthStateCookie(req, res);
      res.status(400).json({ error: "code and state are required" });
      return;
    }

    const parsedState = parseOAuthState(state);
    const nonceCookie = parseCookieHeader(req.headers.cookie ?? "")[OAUTH_STATE_COOKIE_NAME];
    const expectedApiOrigin = getTrustedPublicApiOrigin();
    const expectedRedirect = expectedApiOrigin ? `${expectedApiOrigin}/api/oauth/callback` : null;
    if (
      !parsedState ||
      !nonceMatches(nonceCookie, parsedState.nonce) ||
      parsedState.redirectUri !== expectedRedirect
    ) {
      clearOAuthStateCookie(req, res);
      res.status(400).json({ error: "OAuth state verification failed. Please try signing in again." });
      return;
    }

    // Consume the short-lived, HTTP-only state cookie before exchanging the one-use code.
    clearOAuthStateCookie(req, res);
    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      await syncUser(userInfo);
      const sessionToken = await sdk.createSessionToken(userInfo.openId!, {
        name: userInfo.name?.trim() || "Manus user",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(getSessionCookieName(req), sessionToken, {
        ...cookieOptions,
        maxAge: ONE_YEAR_MS,
      });

      // Redirect only to the configured Expo web origin; never to a callback-supplied URL.
      const frontendUrl =
        process.env.EXPO_WEB_PREVIEW_URL ||
        process.env.EXPO_PACKAGER_PROXY_URL ||
        "http://localhost:8081";
      res.redirect(302, frontendUrl);
    } catch {
      console.error("[OAuth] Callback failed");
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });

  app.get("/api/oauth/mobile", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");

    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }
    const parsedState = parseOAuthState(state);
    if (!parsedState || !isAllowedNativeRedirectUri(parsedState.redirectUri)) {
      res.status(400).json({ error: "Native OAuth state is invalid. Please start sign-in again." });
      return;
    }

    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      const user = await syncUser(userInfo);

      const sessionToken = await sdk.createSessionToken(userInfo.openId!, {
        name: userInfo.name?.trim() || "Manus user",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(getSessionCookieName(req), sessionToken, {
        ...cookieOptions,
        maxAge: ONE_YEAR_MS,
      });

      res.json({
        app_session_id: sessionToken,
        user: buildUserResponse(user),
      });
    } catch {
      console.error("[OAuth] Mobile exchange failed");
      res.status(500).json({ error: "OAuth mobile exchange failed" });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    const cookieOptions = getSessionCookieOptions(req);
    res.clearCookie(getSessionCookieName(req), {
      ...cookieOptions,
      maxAge: -1,
    });
    clearPreviousSessionCookie(req, res);
    res.json({ success: true });
  });

  app.get("/api/auth/me", async (req: Request, res: Response) => {
    try {
      const user = await sdk.authenticateRequest(req);
      res.json({ user: buildUserResponse(user) });
    } catch {
      if (req.headers.authorization || currentSessionCookie(req)) {
        console.error("[Auth] /api/auth/me failed with supplied credentials");
      }
      res.status(401).json({ error: "Not authenticated", user: null });
    }
  });

  app.post("/api/auth/session", async (req: Request, res: Response) => {
    try {
      const user = await sdk.authenticateRequest(req);
      const authHeader = req.headers.authorization || req.headers.Authorization;
      if (typeof authHeader !== "string" || !authHeader.startsWith("Bearer ")) {
        res.status(400).json({ error: "Bearer token required" });
        return;
      }
      const token = authHeader.slice("Bearer ".length).trim();
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(getSessionCookieName(req), token, {
        ...cookieOptions,
        maxAge: ONE_YEAR_MS,
      });
      res.json({ success: true, user: buildUserResponse(user) });
    } catch {
      console.error("[Auth] /api/auth/session failed");
      res.status(401).json({ error: "Invalid token" });
    }
  });
}
