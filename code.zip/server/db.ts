import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, productivityEntries, users } from "../drizzle/schema";
import { ENV } from "./_core/env";
import type { ProductivityEntryType, SubmitProductivityEntry } from "../shared/productivity";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch {
      console.warn("[Database] Failed to connect");
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user");
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function saveProductivityEntry(userId: number, input: SubmitProductivityEntry) {
  const db = await getDb();
  if (!db) throw new Error("The productivity repository is currently unavailable.");

  await db.insert(productivityEntries).values({
    userId,
    entryType: input.type,
    recordKey: input.recordKey,
    periodKey: input.periodKey,
    payload: input.payload as Record<string, unknown>,
  }).onDuplicateKeyUpdate({
    set: {
      periodKey: input.periodKey,
      payload: input.payload as Record<string, unknown>,
      updatedAt: new Date(),
    },
  });

  const saved = await db.select({
    id: productivityEntries.id,
    entryType: productivityEntries.entryType,
    recordKey: productivityEntries.recordKey,
    periodKey: productivityEntries.periodKey,
    createdAt: productivityEntries.createdAt,
    updatedAt: productivityEntries.updatedAt,
  }).from(productivityEntries).where(and(
    eq(productivityEntries.userId, userId),
    eq(productivityEntries.entryType, input.type),
    eq(productivityEntries.recordKey, input.recordKey),
  )).limit(1);

  if (!saved[0]) throw new Error("The submitted entry could not be confirmed.");
  return saved[0];
}

export async function findProductivityEntry(userId: number, entryType: ProductivityEntryType, recordKey: string) {
  const db = await getDb();
  if (!db) throw new Error("The productivity repository is currently unavailable.");
  const result = await db.select({
    id: productivityEntries.id,
    entryType: productivityEntries.entryType,
    recordKey: productivityEntries.recordKey,
    periodKey: productivityEntries.periodKey,
    createdAt: productivityEntries.createdAt,
    updatedAt: productivityEntries.updatedAt,
  }).from(productivityEntries).where(and(
    eq(productivityEntries.userId, userId),
    eq(productivityEntries.entryType, entryType),
    eq(productivityEntries.recordKey, recordKey),
  )).limit(1);
  return result[0] ?? null;
}

export async function listProductivityEntries(userId: number, options: {
  entryType?: ProductivityEntryType;
  limit: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("The productivity repository is currently unavailable.");
  const where = options.entryType
    ? and(eq(productivityEntries.userId, userId), eq(productivityEntries.entryType, options.entryType))
    : eq(productivityEntries.userId, userId);
  return db.select({
    entryType: productivityEntries.entryType,
    recordKey: productivityEntries.recordKey,
    periodKey: productivityEntries.periodKey,
    createdAt: productivityEntries.createdAt,
    updatedAt: productivityEntries.updatedAt,
  }).from(productivityEntries).where(where).orderBy(desc(productivityEntries.updatedAt)).limit(options.limit);
}
