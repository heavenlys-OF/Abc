import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Platform } from "react-native";
import * as Api from "@/lib/_core/api";
import * as Auth from "@/lib/_core/auth";

type AuthContextValue = {
  user: Auth.User | null;
  loading: boolean;
  checking: boolean;
  error: Error | null;
  isAuthenticated: boolean;
  refresh: () => Promise<Auth.User | null>;
  beginSignIn: () => void;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();
  const [user, setUser] = useState<Auth.User | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const generation = useRef(0);
  const currentUserId = useRef<number | null | undefined>(undefined);

  const setVerifiedUser = useCallback((next: Auth.User | null) => {
    const nextId = next?.id ?? null;
    if (currentUserId.current !== nextId) {
      queryClient.clear();
      currentUserId.current = nextId;
    }
    setUser(next);
  }, [queryClient]);

  const refresh = useCallback(async (): Promise<Auth.User | null> => {
    const requestGeneration = ++generation.current;
    setChecking(true);
    setError(null);

    try {
      if (Platform.OS !== "web") {
        const sessionToken = await Auth.getSessionToken();
        if (!sessionToken) {
          if (requestGeneration !== generation.current) return null;
          setVerifiedUser(null);
          await Auth.clearUserInfo();
          return null;
        }
      }

      const apiUser = await Api.getMe();
      if (requestGeneration !== generation.current) return null;
      if (!apiUser) {
        setVerifiedUser(null);
        if (Platform.OS !== "web") await Auth.removeSessionToken();
        await Auth.clearUserInfo();
        return null;
      }
      if (!apiUser.openId || !Number.isSafeInteger(apiUser.id) || apiUser.id <= 0) {
        throw new Error("The signed-in account could not be verified. Please try again.");
      }

      const verifiedUser: Auth.User = {
        id: apiUser.id,
        openId: apiUser.openId,
        name: apiUser.name,
        email: apiUser.email,
        loginMethod: apiUser.loginMethod,
        lastSignedIn: new Date(apiUser.lastSignedIn),
      };
      if (requestGeneration !== generation.current) return null;
      setVerifiedUser(verifiedUser);
      await Auth.setUserInfo(verifiedUser);
      return verifiedUser;
    } catch (err) {
      const nextError = err instanceof Error ? err : new Error("The account could not be verified.");
      if (requestGeneration === generation.current) {
        setVerifiedUser(null);
        setError(nextError);
      }
      return null;
    } finally {
      if (requestGeneration === generation.current) {
        setInitialized(true);
        setChecking(false);
      }
    }
  }, [setVerifiedUser]);

  const beginSignIn = useCallback(() => {
    generation.current += 1;
    setVerifiedUser(null);
    setError(null);
    setInitialized(true);
    setChecking(false);
  }, [setVerifiedUser]);

  const logout = useCallback(async () => {
    generation.current += 1;
    setVerifiedUser(null);
    setError(null);
    setInitialized(true);
    setChecking(false);
    try {
      await Api.logout();
    } catch {
      // Clear local access even when a network logout cannot complete.
    } finally {
      await Auth.removeSessionToken();
      await Auth.clearUserInfo();
    }
  }, [setVerifiedUser]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const value = useMemo<AuthContextValue>(() => ({
    user,
    loading: !initialized,
    checking,
    error,
    isAuthenticated: Boolean(user && !error),
    refresh,
    beginSignIn,
    logout,
  }), [user, initialized, checking, error, refresh, beginSignIn, logout]);

  return React.createElement(AuthContext.Provider, { value }, children);
}

/** All consumers share the one server-validated identity; options remain accepted for starter compatibility. */
export function useAuth(_options?: { autoFetch?: boolean }): AuthContextValue {
  const value = useContext(AuthContext);
  if (!value) throw new Error("useAuth must be used inside AuthProvider");
  return value;
}
